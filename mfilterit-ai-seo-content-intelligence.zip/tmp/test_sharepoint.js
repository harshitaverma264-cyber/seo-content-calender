const fs = require('fs');

async function testSharepoint() {
  const url1 = 'https://mfilteritd-my.sharepoint.com/:x:/g/personal/tannu_saini_mfilterit_com/IQDZtakbjr0PQIWBIkjgd7tRAWZ6sFBmtGEsYjhEtv2zUkc?e=Iofill';
  console.log('Step 1: Fetching sharing URL...');
  const res1 = await fetch(url1, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    },
    redirect: 'manual'
  });
  
  console.log('Step 1 status:', res1.status, res1.statusText);
  const loc = res1.headers.get('location');
  console.log('Step 1 location:', loc);
  
  const cookies1 = res1.headers.getSetCookie ? res1.headers.getSetCookie() : [res1.headers.get('set-cookie')].filter(Boolean);
  let allCookies = [...cookies1];

  console.log('\nStep 2: Fetching Doc.aspx...');
  const docUrl = new URL(loc, url1).toString();
  const cookieHeader1 = allCookies.map(c => c.split(';')[0]).join('; ');
  const res2 = await fetch(docUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Cookie': cookieHeader1
    }
  });

  console.log('Step 2 status:', res2.status, res2.statusText);
  const cookies2 = res2.headers.getSetCookie ? res2.headers.getSetCookie() : [res2.headers.get('set-cookie')].filter(Boolean);
  allCookies.push(...cookies2);
  const cookieHeader2 = allCookies.map(c => c.split(';')[0]).join('; ');

  const html = await res2.text();
  fs.writeFileSync('/tmp/doc.html', html);
  console.log('Doc.aspx HTML saved to /tmp/doc.html (length:', html.length, ')');

  // Let's inspect wopi context
  const lines = html.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('_wopiContextJson')) {
      console.log('Found _wopiContextJson at line', i, ':\n', line.slice(0, 400));
    }
    if (line.includes('AccessToken')) {
      console.log('Found AccessToken at line', i, ':\n', line.slice(0, 300));
    }
    if (line.includes('FileGetUrl')) {
      console.log('Found FileGetUrl at line', i, ':\n', line.slice(0, 300));
    }
  }
}

testSharepoint().catch(console.error);

import {
  MasterDataSourceInfo,
  MasterKeywordRecord,
} from '../types/keywordIntelligence';

// Complete Persistent Master Keyword Dataset for India (27 Keywords)
const INDIA_MASTER_RECORDS: MasterKeywordRecord[] = [
  {
    "id": "in-m-1",
    "keyword": "brand bidding affiliate fraud",
    "searchVolume": 1600,
    "keywordDifficulty": 42,
    "cpc": 4.8,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Affiliate Marketing Head",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "in-m-2",
    "keyword": "app install fraud detection india",
    "searchVolume": 2400,
    "keywordDifficulty": 58,
    "cpc": 7.2,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "in-m-3",
    "keyword": "ad fraud detection software",
    "searchVolume": 3200,
    "keywordDifficulty": 65,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Digital Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "in-m-4",
    "keyword": "creative compliance automation bfsi",
    "searchVolume": 880,
    "keywordDifficulty": 35,
    "cpc": 6.1,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "in-m-5",
    "keyword": "click injection vs click spamming",
    "searchVolume": 1200,
    "keywordDifficulty": 48,
    "cpc": 3.2,
    "searchIntent": "Informational",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Media Buyer",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "in-m-6",
    "keyword": "quick commerce buy box monitoring",
    "searchVolume": 1400,
    "keywordDifficulty": 38,
    "cpc": 5.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "in-m-7",
    "keyword": "affiliate fraud audit",
    "searchVolume": 950,
    "keywordDifficulty": 45,
    "cpc": 4.2,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "in-m-8",
    "keyword": "what is ad fraud",
    "searchVolume": 8100,
    "keywordDifficulty": 72,
    "cpc": 2.1,
    "searchIntent": "Informational",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "in-m-9",
    "keyword": "brand safety guidelines for indian advertisers",
    "searchVolume": 1100,
    "keywordDifficulty": 41,
    "cpc": 5.1,
    "searchIntent": "Informational",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Brand Safety Head",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "in-m-10",
    "keyword": "ecommerce marketplace price tracking",
    "searchVolume": 1800,
    "keywordDifficulty": 51,
    "cpc": 6.8,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "in-m-11",
    "keyword": "invalid traffic ivt filtering",
    "searchVolume": 2100,
    "keywordDifficulty": 60,
    "cpc": 7.9,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "in-m-12",
    "keyword": "ott ad fraud detection",
    "searchVolume": 1300,
    "keywordDifficulty": 46,
    "cpc": 8.1,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Media Buyer",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "india-m-13",
    "keyword": "fraud detection",
    "searchVolume": 5000,
    "keywordDifficulty": 68,
    "cpc": 12.5,
    "searchIntent": "Informational",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "india-m-14",
    "keyword": "brand safety and suitability",
    "searchVolume": 50,
    "keywordDifficulty": 52,
    "cpc": 9.8,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "india-m-15",
    "keyword": "map monitoring software amazon",
    "searchVolume": 2100,
    "keywordDifficulty": 45,
    "cpc": 11.2,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "india-m-16",
    "keyword": "ad creative compliance automation",
    "searchVolume": 1800,
    "keywordDifficulty": 40,
    "cpc": 8.4,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "india-m-17",
    "keyword": "ad fraud detection",
    "searchVolume": 50,
    "keywordDifficulty": 66,
    "cpc": 12,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "india-m-18",
    "keyword": "unauthorized seller detection",
    "searchVolume": 1900,
    "keywordDifficulty": 50,
    "cpc": 10.4,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "india-m-19",
    "keyword": "affiliate compliance monitoring",
    "searchVolume": 390,
    "keywordDifficulty": 43,
    "cpc": 7.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "india-m-20",
    "keyword": "brand protection online",
    "searchVolume": 2100,
    "keywordDifficulty": 64,
    "cpc": 13.1,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Brand Protection Head",
      "mFilterIt Solution": "Brand Protection"
    }
  },
  {
    "id": "india-m-21",
    "keyword": "asci ad compliance automated audit",
    "searchVolume": 1200,
    "keywordDifficulty": 36,
    "cpc": 5.8,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "india-m-22",
    "keyword": "mule account detection",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Digital Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "india-m-23",
    "keyword": "coupon hijacking affiliate fraud",
    "searchVolume": 1500,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Affiliate Marketing Head",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "india-m-24",
    "keyword": "buy box tracking amazon",
    "searchVolume": 1700,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "india-m-25",
    "keyword": "ad fraud prevention",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "india-m-26",
    "keyword": "click injection",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "india-m-27",
    "keyword": "minimum advertised price map definition",
    "searchVolume": 3900,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "INDIA",
    "additionalFields": {
      "Source": "SEMrush India",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  }
];

// Complete Persistent Master Keyword Dataset for USA (25 Keywords)
const USA_MASTER_RECORDS: MasterKeywordRecord[] = [
  {
    "id": "us-m-1",
    "keyword": "best ad fraud detection software",
    "searchVolume": 4400,
    "keywordDifficulty": 74,
    "cpc": 18.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "us-m-2",
    "keyword": "map violation monitoring amazon",
    "searchVolume": 2900,
    "keywordDifficulty": 52,
    "cpc": 12,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "us-m-3",
    "keyword": "ctv ad fraud prevention",
    "searchVolume": 1900,
    "keywordDifficulty": 61,
    "cpc": 15.2,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Media Buyer",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "us-m-4",
    "keyword": "digital shelf share of voice sov",
    "searchVolume": 1600,
    "keywordDifficulty": 46,
    "cpc": 9.8,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "us-m-5",
    "keyword": "rogue affiliate brand hijacking",
    "searchVolume": 1100,
    "keywordDifficulty": 49,
    "cpc": 14.1,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Affiliate Marketing Head",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "us-m-6",
    "keyword": "programmatic brand safety filters",
    "searchVolume": 2200,
    "keywordDifficulty": 57,
    "cpc": 11.4,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Brand Safety Head",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "us-m-7",
    "keyword": "cookie stuffing affiliate fraud",
    "searchVolume": 1350,
    "keywordDifficulty": 43,
    "cpc": 8.9,
    "searchIntent": "Informational",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "us-m-8",
    "keyword": "ad verification benchmark report",
    "searchVolume": 1750,
    "keywordDifficulty": 50,
    "cpc": 10.5,
    "searchIntent": "Informational",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Digital Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "us-m-9",
    "keyword": "counterfeit detection ecommerce marketplaces",
    "searchVolume": 2100,
    "keywordDifficulty": 63,
    "cpc": 13.2,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Brand Protection Head",
      "mFilterIt Solution": "Brand Protection"
    }
  },
  {
    "id": "us-m-10",
    "keyword": "financial ad creative compliance SEC",
    "searchVolume": 1250,
    "keywordDifficulty": 55,
    "cpc": 16.8,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "usa-m-11",
    "keyword": "ctv ad fraud",
    "searchVolume": 50,
    "keywordDifficulty": 58,
    "cpc": 14.6,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Media Buyer",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "usa-m-12",
    "keyword": "affiliate ad hijacking",
    "searchVolume": 320,
    "keywordDifficulty": 46,
    "cpc": 7.9,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "usa-m-13",
    "keyword": "online trademark infringement monitoring",
    "searchVolume": 3100,
    "keywordDifficulty": 62,
    "cpc": 13.8,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Brand Protection Head",
      "mFilterIt Solution": "Brand Protection"
    }
  },
  {
    "id": "usa-m-14",
    "keyword": "digital shelf analytics",
    "searchVolume": 50,
    "keywordDifficulty": 38,
    "cpc": 6.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "usa-m-15",
    "keyword": "transaction monitoring",
    "searchVolume": 5000,
    "keywordDifficulty": 70,
    "cpc": 15,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "usa-m-16",
    "keyword": "unauthorized affiliate bidding",
    "searchVolume": 480,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "usa-m-17",
    "keyword": "ecommerce analytics",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "usa-m-18",
    "keyword": "click fraud protection",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Media Buyer",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "usa-m-19",
    "keyword": "creative compliance monitoring",
    "searchVolume": 1500,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "usa-m-20",
    "keyword": "impression fraud",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "usa-m-21",
    "keyword": "social media impersonation detection",
    "searchVolume": 2800,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Brand Safety Head",
      "mFilterIt Solution": "Brand Protection"
    }
  },
  {
    "id": "usa-m-22",
    "keyword": "affiliate redirect hijacking",
    "searchVolume": 1300,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "usa-m-23",
    "keyword": "contextual ads",
    "searchVolume": 500,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "usa-m-24",
    "keyword": "brand safety and suitability",
    "searchVolume": 50,
    "keywordDifficulty": 52,
    "cpc": 9.8,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "usa-m-25",
    "keyword": "programmatic fraud",
    "searchVolume": 50,
    "keywordDifficulty": 61,
    "cpc": 11.8,
    "searchIntent": "Commercial Investigation",
    "region": "USA",
    "additionalFields": {
      "Source": "Ahrefs USA",
      "Target Persona": "Media Buyer",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  }
];

// Complete Persistent Master Keyword Dataset for MENA (24 Keywords)
const MENA_MASTER_RECORDS: MasterKeywordRecord[] = [
  {
    "id": "mena-m-1",
    "keyword": "ad fraud detection uae saudi",
    "searchVolume": 1300,
    "keywordDifficulty": 44,
    "cpc": 9.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-2",
    "keyword": "ramadan campaign brand safety mena",
    "searchVolume": 1800,
    "keywordDifficulty": 39,
    "cpc": 7.8,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Brand Safety Head",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "mena-m-3",
    "keyword": "noon noon express price scraping",
    "searchVolume": 950,
    "keywordDifficulty": 32,
    "cpc": 5.2,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "mena-m-4",
    "keyword": "affiliate compliance ksa ecommerce",
    "searchVolume": 1100,
    "keywordDifficulty": 36,
    "cpc": 6.4,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "mena-m-5",
    "keyword": "banking app fraud prevention mena",
    "searchVolume": 2100,
    "keywordDifficulty": 54,
    "cpc": 11.2,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-6",
    "keyword": "arabic creative compliance guidelines",
    "searchVolume": 750,
    "keywordDifficulty": 28,
    "cpc": 4.9,
    "searchIntent": "Informational",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Digital Marketing Head",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "mena-m-7",
    "keyword": "mobile ad fraud in gulf countries",
    "searchVolume": 1400,
    "keywordDifficulty": 41,
    "cpc": 8.3,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-8",
    "keyword": "amazon ae buy box strategy",
    "searchVolume": 1650,
    "keywordDifficulty": 48,
    "cpc": 7.1,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "mena-m-9",
    "keyword": "affiliate fraud detection",
    "searchVolume": 50,
    "keywordDifficulty": 48,
    "cpc": 8.9,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Affiliate Marketing Head",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "mena-m-10",
    "keyword": "mobile ad fraud",
    "searchVolume": 50,
    "keywordDifficulty": 55,
    "cpc": 9.2,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Digital Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-11",
    "keyword": "contextual targeting advertising",
    "searchVolume": 500,
    "keywordDifficulty": 44,
    "cpc": 7.1,
    "searchIntent": "Informational",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Brand Safety"
    }
  },
  {
    "id": "mena-m-12",
    "keyword": "digital shelf monitoring",
    "searchVolume": 50,
    "keywordDifficulty": 42,
    "cpc": 8,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "mena-m-13",
    "keyword": "programmatic fraud",
    "searchVolume": 50,
    "keywordDifficulty": 61,
    "cpc": 11.8,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-14",
    "keyword": "brand bidding affiliate fraud",
    "searchVolume": 1600,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Affiliate Marketing Head",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "mena-m-15",
    "keyword": "click injection",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Digital Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-16",
    "keyword": "luxury brand protection",
    "searchVolume": 1600,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Brand Protection Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "mena-m-17",
    "keyword": "multilingual ad compliance gcc",
    "searchVolume": 950,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "mena-m-18",
    "keyword": "card fraud detection",
    "searchVolume": 5000,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-19",
    "keyword": "digital shelf",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "mena-m-20",
    "keyword": "affiliate fraud",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Affiliate Manager",
      "mFilterIt Solution": "Affiliate Monitoring / Affiliate Fraud Detection"
    }
  },
  {
    "id": "mena-m-21",
    "keyword": "contextual ad targeting",
    "searchVolume": 500,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "CMO",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  },
  {
    "id": "mena-m-22",
    "keyword": "share of voice digital shelf",
    "searchVolume": 2500,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "E-commerce Head",
      "mFilterIt Solution": "Digital Shelf / Marketplace Monitoring"
    }
  },
  {
    "id": "mena-m-23",
    "keyword": "ad creative compliance automation",
    "searchVolume": 1800,
    "keywordDifficulty": 40,
    "cpc": 8.4,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Marketing Head",
      "mFilterIt Solution": "Creative Compliance"
    }
  },
  {
    "id": "mena-m-24",
    "keyword": "mule account detection",
    "searchVolume": 50,
    "keywordDifficulty": 45,
    "cpc": 8.5,
    "searchIntent": "Commercial Investigation",
    "region": "MENA",
    "additionalFields": {
      "Source": "SEMrush MENA",
      "Target Persona": "Performance Marketing Head",
      "mFilterIt Solution": "Ad Fraud Detection"
    }
  }
];

export const PERSISTENT_MASTER_SOURCES: Record<'INDIA' | 'USA' | 'MENA', MasterDataSourceInfo> = {
  INDIA: {
    id: 'india-master',
    region: 'INDIA',
    name: 'India — All Keywords Master Source',
    status: 'CONNECTED',
    rowCount: INDIA_MASTER_RECORDS.length,
    keywordCount: INDIA_MASTER_RECORDS.length,
    detectedColumns: ['Keyword', 'Search Volume', 'Keyword Difficulty', 'CPC', 'Search Intent', 'Target Persona', 'mFilterIt Solution'],
    validationWarnings: [],
    records: INDIA_MASTER_RECORDS,
  },
  USA: {
    id: 'usa-master',
    region: 'USA',
    name: 'USA — All Keywords Master Source',
    status: 'CONNECTED',
    rowCount: USA_MASTER_RECORDS.length,
    keywordCount: USA_MASTER_RECORDS.length,
    detectedColumns: ['Keyword', 'Search Volume', 'Keyword Difficulty', 'CPC', 'Search Intent', 'Target Persona', 'mFilterIt Solution'],
    validationWarnings: [],
    records: USA_MASTER_RECORDS,
  },
  MENA: {
    id: 'mena-master',
    region: 'MENA',
    name: 'MENA — All Keywords Master Source',
    status: 'CONNECTED',
    rowCount: MENA_MASTER_RECORDS.length,
    keywordCount: MENA_MASTER_RECORDS.length,
    detectedColumns: ['Keyword', 'Search Volume', 'Keyword Difficulty', 'CPC', 'Search Intent', 'Target Persona', 'mFilterIt Solution'],
    validationWarnings: [],
    records: MENA_MASTER_RECORDS,
  },
};

import { mFilterItSolution, TrustPillar, ContentType, FunnelStage, IcpPersona } from '../types/seo';

export interface TitlePattern {
  id: string;
  name: string;
  formula: string;
  description: string;
  realWorldExamples: string[];
  recommendedFunnel: FunnelStage;
}

export interface EditorialStyleGuide {
  brandVoice: {
    archetype: string;
    tone: string[];
    corePrinciples: {
      title: string;
      description: string;
      rule: string;
    }[];
  };
  trustPillars: {
    pillar: TrustPillar;
    color: string;
    focusAreas: string[];
    diagnosticQuestions: string[];
    targetSolutions: mFilterItSolution[];
  }[];
  titlePatterns: TitlePattern[];
  contentStructureRules: {
    section: string;
    guideline: string;
    checklist: string[];
  }[];
  ctaCatalog: Record<mFilterItSolution, {
    primaryCta: string;
    rationale: string;
    landingPath: string;
  }>;
}

export const mFilterItEditorialStyleGuide: EditorialStyleGuide = {
  brandVoice: {
    archetype: 'Enterprise Digital Trust & Ad Integrity Diagnostic Authority',
    tone: [
      'Diagnostic & Inquisitive (uncovers hidden systemic waste and fraud vectors)',
      'Data-Backed & Forensic (references specific attack mechanics, telemetry, benchmarks)',
      'Solutions-Oriented & Consultative (provides concrete playbooks, not alarmist commentary)',
      'Enterprise & C-Suite Relevant (speaks directly to P&L, ROAS preservation, margin defense)'
    ],
    corePrinciples: [
      {
        title: 'Diagnostic Over Descriptive',
        description: 'Never write generic "10 Tips" or basic definitional overviews. Formulate topics around the underlying vulnerabilities, attribution theft mechanisms, and operational blindspots.',
        rule: 'Ask: "Why does this leakage occur?" and "What does the attacker exploit that traditional attribution tools miss?"'
      },
      {
        title: 'Concrete Technical Mechanics',
        description: 'Ground every recommendation in technical realities: SDK spoofing, click injection, SSAI spoofing, cookie stuffing, Buy Box suppression algorithms, MAP scraping bots, GARM brand suitability floors, ASCI/regulatory mandates.',
        rule: 'Avoid vague assertions like "fraud is bad"; quantify the impact (e.g., "18-35% attribution poaching in high-intent campaigns").'
      },
      {
        title: 'Commercial Intent & Consultative Next Step',
        description: 'Every piece of content must naturally guide enterprise decision-makers toward an actionable diagnostic audit or platform assessment.',
        rule: 'Conclude with a high-trust, low-friction consultative offer (Free Ad Spend Audit, Buy Box Health Check, Brand Infringement Scan).'
      }
    ]
  },
  trustPillars: [
    {
      pillar: 'Media Trust',
      color: '#530093',
      focusAreas: [
        'Invalid Traffic (IVT / SIVT) in Programmatic',
        'Connected TV (CTV) & OTT Server-Side Ad Insertion (SSAI) Spoofing',
        'Mobile App Install Fraud, SDK Tampering & Click Injection',
        'Performance Max & Automated Ad Campaign Leakage',
        'Bot Farms, Device Emulators & Residential Proxy Networks'
      ],
      diagnosticQuestions: [
        'Are you paying for clicks or paying for verified human users?',
        'How much of your programmatic video budget is absorbed by domain spoofing?',
        'Why does high-volume user acquisition fail to translate into down-funnel retention?'
      ],
      targetSolutions: ['Ad Fraud Detection']
    },
    {
      pillar: 'Brand Trust',
      color: '#059669',
      focusAreas: [
        'Brand Bidding & Paid Search Trademark Hijacking',
        'Brand Infringement, Counterfeit Listings & Rogue Resellers',
        'Phishing, Lookalike Domains & Executive Impersonation',
        'Brand Safety Floors vs. Brand Suitability Alignment (GARM Framework)',
        'Creative & Regulatory Disclosure Compliance (ASCI, RBI, SEC, FTC)'
      ],
      diagnosticQuestions: [
        'How are unauthorized affiliates poach-bidding on your brand name in Google Ads?',
        'How do counterfeit products siphon organic traffic and brand equity across social shops?',
        'Are your programmatic display ads appearing alongside toxic or polarizing content?'
      ],
      targetSolutions: [
        'Brand Protection',
        'Brand Safety',
        'Creative Compliance',
        'Affiliate Monitoring / Affiliate Fraud Detection'
      ]
    },
    {
      pillar: 'Financial Trust',
      color: '#d97706',
      focusAreas: [
        'Affiliate Commission Theft & Cookie Stuffing',
        'Digital Shelf Price Scraping, MAP Undercutting & Buy Box Suppression',
        'Quick Commerce & Marketplace Margin Erosion (Amazon, Flipkart, Noon)',
        'Mule Accounts, Fake Loan Applications & Transaction Laundering',
        'FinTech Ad Disclosure Non-Compliance & Central Bank Regulatory Fines'
      ],
      diagnosticQuestions: [
        'Are rogue partners collecting commissions on customers who were already in your checkout funnel?',
        'How does unauthorized seller discounting trigger Amazon Buy Box suppression algorithms?',
        'How do synthetic identities exploit mobile banking sign-up incentives?'
      ],
      targetSolutions: [
        'Affiliate Monitoring / Affiliate Fraud Detection',
        'Digital Shelf / Marketplace Monitoring',
        'Ad Fraud Detection',
        'Creative Compliance'
      ]
    }
  ],
  titlePatterns: [
    {
      id: 'pattern-diagnostic-question',
      name: 'Diagnostic Inquiry + Root-Cause Forensic',
      formula: '[Provocative Diagnostic Question]? Why [Fraud/Leakage Vector] [Business Consequence]',
      description: 'Challenges conventional marketing assumptions and exposes the hidden technical mechanism draining performance.',
      realWorldExamples: [
        'Are You Paying for Clicks, or Paying for Users? Why App Install Fraud Begins Before the Install',
        'Incent Fraud Detection: Why High-Volume Acquisition Never Becomes Quality Growth',
        'Is Your Attribution Platform Catching Click Injection or Simply Claiming Credit?'
      ],
      recommendedFunnel: 'MOFU'
    },
    {
      id: 'pattern-threat-defense',
      name: 'Sector Threat Forensic + Enterprise Defense Playbook',
      formula: '[Threat Vector] in [Industry/Vertical]: How [Rogue Actor] Targets [Asset] and How to Protect It',
      description: 'Pinpoints specific vertical vulnerabilities (Banking, Retail, Gaming, Travel) with a tactical blueprint for enterprise defense.',
      realWorldExamples: [
        'Brand Infringement in Banking: How Fakes Target Your Customers and How to Protect Them',
        'Affiliate Growth vs Brand Infringement: How BFSI Brands in MENA Can Stay Protected',
        'Social Commerce Brand Protection: Takedown Strategies for TikTok Shop & Instagram Fakes'
      ],
      recommendedFunnel: 'BOFU'
    },
    {
      id: 'pattern-audit-checklist',
      name: 'Strategic Milestone Audit Checklist',
      formula: '[Strategic Milestone/Season] Checklist: Are You Auditing [Leakage Area] Before [Trigger]?',
      description: 'Capitalizes on seasonal budget resets, fiscal milestones, or mega-shopping peaks (Diwali, DSF, BFCM, Prime Day).',
      realWorldExamples: [
        'FY Closing Checklist: Are You Auditing Ad Fraud Media Waste Before Budget Reset?',
        'Q4 Holiday Readiness: 7 Red Flags of Affiliate Brand Bidding & Attribution Cannibalization',
        'Ramadan Campaign Brand Safety: Contextual AI Vetting Across Arabic Video & Social Channels'
      ],
      recommendedFunnel: 'BOFU'
    },
    {
      id: 'pattern-technical-contrast',
      name: 'Technical Contrast / Mechanism Deep-Dive',
      formula: '[Mechanism A] vs. [Mechanism B]: Why [Legacy Metric] Misses SIVT & How to Audit It',
      description: 'Contrasts superficial vanity metrics with deep-packet forensic verification to educate senior media buyers.',
      realWorldExamples: [
        'Pre-Bid Avoidance vs. Post-Bid Verification: Why Viewability Isn\'t Catching Sophisticated Invalid Traffic',
        'Click Injection vs Click Spamming Architecture in Mobile Campaigns',
        'Brand Safety Floors vs. Brand Suitability Frameworks: Applying GARM Standards in Programmatic Buying'
      ],
      recommendedFunnel: 'MOFU'
    },
    {
      id: 'pattern-marketplace-defense',
      name: 'Marketplace Buy Box & Margin Defense',
      formula: '[Marketplace/Channel] Buy Box Defense: [N] Warning Signals of Price Scraping & MAP Undercutting',
      description: 'Directly speaks to e-commerce P&L leaders losing organic share and Buy Box revenue to gray-market sellers.',
      realWorldExamples: [
        'Amazon Buy Box Defense: 4 Early Warning Signals of Price Scraping & MAP Undercutting',
        'Noon & Amazon AE Buy-Box Strategy: Stopping Price Scraping Bots in UAE & KSA',
        'Quick Commerce Buy Box Defense: Stopping Out-of-Stock Suppression on Blinkit, Zepto, and Instamart'
      ],
      recommendedFunnel: 'BOFU'
    },
    {
      id: 'pattern-comparative-evaluation',
      name: 'Enterprise Evaluation & Buying Guide',
      formula: 'Enterprise [Category] Software: [N] Critical Questions to Ask Before Choosing a Verification Partner',
      description: 'Targets high-intent buyers evaluating verification and compliance vendors.',
      realWorldExamples: [
        'How to Choose the Right Brand Protection Solution: 8 Key Questions',
        'Enterprise Ad Fraud Detection Software: Comparing Valid8 vs Legacy Verification Tools',
        'Everything You Need to Know About Mobile Ad Fraud in 2026'
      ],
      recommendedFunnel: 'BOFU'
    }
  ],
  contentStructureRules: [
    {
      section: 'Title & Meta Framing',
      guideline: 'Must adhere to one of the 6 core title patterns. Never exceed 70 characters without a clear colon separator. Include primary commercial keyword in the first 45 characters.',
      checklist: [
        'Contains diagnostic hook or vertical context',
        'Includes verified focus keyword with search intent alignment',
        'Clear separation between the threat and the solution'
      ]
    },
    {
      section: 'Introduction: The Diagnostic Hook',
      guideline: 'Open with the hidden operational tension or financial leakage figure rather than general background facts. Establish high-stakes empathy with the ICP.',
      checklist: [
        'Quantifies the cost of inaction (e.g., 15-30% spend dilution)',
        'Diagnoses why traditional monitoring or native platform metrics fail',
        'States the specific objective of the article clearly'
      ]
    },
    {
      section: 'Body: Technical Forensics & Attack Anatomy',
      guideline: 'Break down the attack vector step-by-step with technical mechanics (user flow, script injection, attribution timestamp manipulation, scraper proxies).',
      checklist: [
        'Diagrams or visualizes the exploitation lifecycle',
        'Explains how malicious actors bypass basic detection',
        'Contrasts symptoms vs. root cause'
      ]
    },
    {
      section: 'Resolution: Actionable Enterprise Blueprint',
      guideline: 'Provide an actionable 4 to 6-step mitigation roadmap, policy enforcement checklist, or automated verification workflow.',
      checklist: [
        'Gives concrete parameters (e.g., time-to-install thresholds, Buy Box margin delta)',
        'Includes governance or vendor SLA benchmarks',
        'Outlines immediate containment actions'
      ]
    },
    {
      section: 'Conclusion & Consultative CTA',
      guideline: 'End with an unambiguous invitation to run a diagnostic health check or audit using mFilterIt technology.',
      checklist: [
        'Direct link to relevant commercial solution landing page',
        'Low friction offer (no sales pressure, focused on discovery)',
        'Reinforces the primary Trust Pillar (Media Trust, Brand Trust, Financial Trust)'
      ]
    }
  ],
  ctaCatalog: {
    'Ad Fraud Detection': {
      primaryCta: 'Request Free Enterprise Ad Fraud & IVT Audit with mFilterIt',
      rationale: 'Uncovers invalid traffic and SSAI manipulation across programmatic and app campaigns with zero upfront integration.',
      landingPath: 'https://www.mfilterit.com/ad-fraud-audit/'
    },
    'Affiliate Monitoring / Affiliate Fraud Detection': {
      primaryCta: 'Request Free Affiliate Traffic & Brand Bidding Poaching Audit',
      rationale: 'Detects unauthorized partner brand bidding and attribution theft across Google Ads and search engines.',
      landingPath: 'https://www.mfilterit.com/affiliate-audit/'
    },
    'Brand Protection': {
      primaryCta: 'Run a Complimentary Brand Infringement & Counterfeit Scan',
      rationale: 'Scans marketplaces and web domains to locate rogue resellers, phishing portals, and trademark violations.',
      landingPath: 'https://www.mfilterit.com/brand-protection/'
    },
    'Digital Shelf / Marketplace Monitoring': {
      primaryCta: 'Request Digital Shelf & Buy Box Health Check',
      rationale: 'Audits price scraping, MAP compliance, and out-of-stock suppression across Amazon, Flipkart, and Noon.',
      landingPath: 'https://www.mfilterit.com/digital-shelf-demo/'
    },
    'Brand Safety': {
      primaryCta: 'Schedule Contextual Brand Safety & Suitability Audit',
      rationale: 'Assesses media placements against GARM brand suitability floors across Arabic, English, and regional inventory.',
      landingPath: 'https://www.mfilterit.com/brand-safety-demo/'
    },
    'Creative Compliance': {
      primaryCta: 'Schedule Automated Ad Creative Compliance Demo',
      rationale: 'Demonstrates automated AI pre-screening against ASCI, RBI, and regional advertising regulatory standards.',
      landingPath: 'https://www.mfilterit.com/creative-compliance-audit/'
    }
  }
};

/**
 * Validates a title against mFilterIt Editorial Style Guide patterns.
 */
export function analyzeTitleEditorialStyle(title: string): {
  matchedPattern: TitlePattern | null;
  isDiagnostic: boolean;
  hasRootCause: boolean;
  score: number; // 0 - 100
  suggestions: string[];
} {
  const lower = title.toLowerCase();
  const hasQuestion = title.includes('?');
  const hasColon = title.includes(':');
  const hasDiagnosticWords = lower.includes('why') || lower.includes('signs') || lower.includes('red flags') || lower.includes('signals') || lower.includes('vs') || lower.includes('checklist') || lower.includes('audit');
  const hasForensicMechanisms = lower.includes('ssai') || lower.includes('sdk') || lower.includes('ivt') || lower.includes('cookie') || lower.includes('buy box') || lower.includes('poaching') || lower.includes('hijacking') || lower.includes('infringement') || lower.includes('scraping') || lower.includes('bidding');

  let score = 60;
  if (hasColon || hasQuestion) score += 15;
  if (hasDiagnosticWords) score += 15;
  if (hasForensicMechanisms) score += 10;

  const patterns = mFilterItEditorialStyleGuide.titlePatterns;
  let matched: TitlePattern | null = null;

  if (hasQuestion && lower.includes('why')) {
    matched = patterns.find(p => p.id === 'pattern-diagnostic-question') || patterns[0];
  } else if (lower.includes('vs')) {
    matched = patterns.find(p => p.id === 'pattern-technical-contrast') || patterns[3];
  } else if (lower.includes('checklist') || lower.includes('audit') || lower.includes('red flags')) {
    matched = patterns.find(p => p.id === 'pattern-audit-checklist') || patterns[2];
  } else if (lower.includes('buy box') || lower.includes('map') || lower.includes('shelf')) {
    matched = patterns.find(p => p.id === 'pattern-marketplace-defense') || patterns[4];
  } else if (lower.includes('how fakes') || lower.includes('how rogue') || lower.includes('how to protect')) {
    matched = patterns.find(p => p.id === 'pattern-threat-defense') || patterns[1];
  } else {
    matched = patterns.find(p => p.id === 'pattern-comparative-evaluation') || patterns[5];
  }

  const suggestions: string[] = [];
  if (!hasColon && !hasQuestion) {
    suggestions.push('Add a two-part colon structure [Diagnostic Hook]: [Enterprise Defense Playbook].');
  }
  if (!hasDiagnosticWords) {
    suggestions.push('Incorporate diagnostic terminology (e.g., "5 Early Warning Signs", "Why App Install Fraud Begins Before the Install").');
  }

  return {
    matchedPattern: matched,
    isDiagnostic: hasQuestion || hasDiagnosticWords,
    hasRootCause: hasForensicMechanisms,
    score: Math.min(100, score),
    suggestions
  };
}

/**
 * Returns consultative CTA for any solution according to the style guide.
 */
export function getStyleGuideCta(solution: mFilterItSolution): string {
  const item = mFilterItEditorialStyleGuide.ctaCatalog[solution];
  return item ? item.primaryCta : 'Request Free Enterprise Digital Trust Audit with mFilterIt';
}

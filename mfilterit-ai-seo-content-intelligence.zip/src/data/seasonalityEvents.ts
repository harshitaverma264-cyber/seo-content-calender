import { Region, mFilterItSolution, IcpPersona, ContentAction, FunnelStage, ContentType } from '../types/seo';

export interface SeasonalTopicSuggestion {
  title: string;
  keyword: string;
  contentType: ContentType;
  funnel: FunnelStage;
  action: ContentAction;
  targetPersona: IcpPersona;
  productMapping: mFilterItSolution;
  rationale: string;
}

export interface SeasonalEvent {
  id: string;
  eventName: string;
  region: Region;
  eventWindow: string; // e.g., "Late Nov 2026"
  eventDateRange: string; // e.g., "Nov 27, 2026"
  contentRampUpWeeks: number; // e.g., 8 weeks before event
  rampUpStartDate: string; // e.g., "Late Sep 2026"
  description: string;
  primarySolution: mFilterItSolution;
  targetPersona: IcpPersona;
  featuredKeywords: string[];
  recommendedAction: ContentAction;
  suggestedFunnel: FunnelStage;
  strategicImportance: string;
  businessValue: 'Critical' | 'High' | 'Medium';
  estimatedBudgetRisk: string;
  suggestedTopics: SeasonalTopicSuggestion[];
}

export const REGIONAL_SEASONALITY_EVENTS: SeasonalEvent[] = [
  // ==========================================
  // INDIA
  // ==========================================
  {
    id: 'event-diwali-india',
    eventName: 'Diwali & Festive E-Commerce Surge',
    region: 'INDIA',
    eventWindow: 'October - November 2026',
    eventDateRange: 'Nov 8 - Nov 12, 2026',
    contentRampUpWeeks: 8,
    rampUpStartDate: 'September 1, 2026',
    description: "India's premier retail peak. Huge spikes in affiliate search poaching, trademark brand bidding, quick-commerce buy-box losses, and app install fraud during festive sales.",
    primarySolution: 'Affiliate Monitoring / Affiliate Fraud Detection',
    targetPersona: 'Affiliate Marketing Head',
    featuredKeywords: [
      'brand bidding affiliate fraud india',
      'quick commerce buy box monitoring',
      'festive app install fraud protection',
      'creative compliance automation bfsi'
    ],
    recommendedAction: 'REVAMP',
    suggestedFunnel: 'BOFU',
    businessValue: 'Critical',
    estimatedBudgetRisk: '18–25% festive ad budget loss to rogue brand bidders and fake affiliate claims',
    strategicImportance: 'Critical Q4 Revenue Driver: Search volume for festive offers jumps 340%. Protecting trademark search terms 8 weeks before Diwali prevents coupon Hijacking.',
    suggestedTopics: [
      {
        title: 'Diwali E-Commerce Protection: Preventing Affiliate Brand Bidding & Coupon Hijacking',
        keyword: 'brand bidding affiliate fraud india',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'REVAMP',
        targetPersona: 'Affiliate Marketing Head',
        productMapping: 'Affiliate Monitoring / Affiliate Fraud Detection',
        rationale: 'Pre-Diwali guide for enterprise brands to lock down affiliate terms and stop coupon poaching.'
      },
      {
        title: 'Festive Flash Sales & App Install Fraud: Protecting Acquisition Budgets in India',
        keyword: 'festive app install fraud protection',
        contentType: 'Website Blog',
        funnel: 'MOFU',
        action: 'NEW',
        targetPersona: 'Performance Marketing Head',
        productMapping: 'Ad Fraud Detection',
        rationale: 'Ramp up install validation 6 weeks prior to festive flash sales.'
      }
    ]
  },
  {
    id: 'event-flipkart-amazon-india',
    eventName: 'Flipkart Big Billion Days & Amazon Great Indian Festival',
    region: 'INDIA',
    eventWindow: 'September - October 2026',
    eventDateRange: 'Sep 23 - Oct 4, 2026',
    contentRampUpWeeks: 6,
    rampUpStartDate: 'August 10, 2026',
    description: 'Massive multi-category online shopping festival across Amazon India, Flipkart, and Tata CLiQ. High risk of seller price scraping, buy box loss, and fake product listings.',
    primarySolution: 'Digital Shelf / Marketplace Monitoring',
    targetPersona: 'E-commerce Head',
    featuredKeywords: [
      'amazon india buy box protection',
      'flipkart price scraping prevention',
      'marketplace brand protection india',
      'digital shelf share of voice amazon'
    ],
    recommendedAction: 'NEW',
    suggestedFunnel: 'BOFU',
    businessValue: 'Critical',
    estimatedBudgetRisk: '12–20% margin erosion due to unauthorized seller price undercut & buy box loss',
    strategicImportance: 'Marketplace Dominance: Ensuring MAP compliance and automated buy-box monitoring during Big Billion Days directly protects brand margins.',
    suggestedTopics: [
      {
        title: 'Flipkart BBD & Amazon GIF Playbook: Winning the Buy Box & Protecting Price Integrity',
        keyword: 'amazon india buy box protection',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'NEW',
        targetPersona: 'E-commerce Head',
        productMapping: 'Digital Shelf / Marketplace Monitoring',
        rationale: 'Actionable marketplace strategy for D2C and FMCG brands ramping up for annual sales.'
      }
    ]
  },
  {
    id: 'event-ipl-india',
    eventName: 'IPL & Live Sports Streaming Season',
    region: 'INDIA',
    eventWindow: 'March - May 2026',
    eventDateRange: 'Mar 22 - May 26, 2026',
    contentRampUpWeeks: 6,
    rampUpStartDate: 'February 1, 2026',
    description: 'India\'s highest CPM digital video & CTV advertising period. Severe surge in invalid traffic (IVT), bot impressions, and domain spoofing on OTT networks.',
    primarySolution: 'Ad Fraud Detection',
    targetPersona: 'Performance Marketing Head',
    featuredKeywords: [
      'ott ad fraud detection india',
      'invalid traffic ivt filtering ctv',
      'click injection vs click spamming',
      'brand safety guidelines for indian advertisers'
    ],
    recommendedAction: 'EXPAND',
    suggestedFunnel: 'MOFU',
    businessValue: 'High',
    estimatedBudgetRisk: '20–30% CTV/OTT ad impression waste from bot traffic during high-CPM live sports',
    strategicImportance: 'High CPM Efficiency: OTT CPMs double during IPL. Pre-bid IVT filtering guarantees live ad spend reaches verified human viewers.',
    suggestedTopics: [
      {
        title: 'IPL Advertising Audit: Eliminating CTV Bot Traffic & Invalid Impressions on Live OTT',
        keyword: 'ott ad fraud detection india',
        contentType: 'SEO / Guest Post',
        funnel: 'MOFU',
        action: 'EXPAND',
        targetPersona: 'Performance Marketing Head',
        productMapping: 'Ad Fraud Detection',
        rationale: 'Educates media buyers on pre-bid IVT verification before multi-crore IPL ad commitments.'
      }
    ]
  },
  {
    id: 'event-bfsi-q4-india',
    eventName: 'Q4 FY Financial Year-End & BFSI Credit Surge',
    region: 'INDIA',
    eventWindow: 'February - March 2026',
    eventDateRange: 'Feb 1 - Mar 31, 2026',
    contentRampUpWeeks: 4,
    rampUpStartDate: 'January 5, 2026',
    description: 'Fiscal year-end peak for loans, insurance, credit cards, and tax-saving investments in India. Regulatory scrutiny on creative compliance and financial app fraud.',
    primarySolution: 'Creative Compliance',
    targetPersona: 'Brand Protection Head',
    featuredKeywords: [
      'creative compliance automation bfsi',
      'banking app fraud prevention india',
      'fintech loan app compliance rbi',
      'financial brand safety safeguards'
    ],
    recommendedAction: 'SUPPORTING',
    suggestedFunnel: 'TOFU',
    businessValue: 'High',
    estimatedBudgetRisk: 'Regulatory fines & brand reputational damage from unapproved loan ad creatives',
    strategicImportance: 'Compliance & Audit Assurance: Automated AI auditing of financial ad copy ensures 100% adherence to RBI guidelines before peak Q4 fiscal ad campaigns.',
    suggestedTopics: [
      {
        title: 'RBI Compliance for Financial Ads: Automating Audit Trails for Loans & Credit Campaigns',
        keyword: 'creative compliance automation bfsi',
        contentType: 'Website Blog',
        funnel: 'TOFU',
        action: 'SUPPORTING',
        targetPersona: 'Brand Protection Head',
        productMapping: 'Creative Compliance',
        rationale: 'Establishes mFilterIt authority in automated financial creative governance ahead of tax season.'
      }
    ]
  },

  // ==========================================
  // USA
  // ==========================================
  {
    id: 'event-black-friday-usa',
    eventName: 'Black Friday Shopping Peak',
    region: 'USA',
    eventWindow: 'Late November 2026',
    eventDateRange: 'Nov 27, 2026',
    contentRampUpWeeks: 8,
    rampUpStartDate: 'October 1, 2026',
    description: 'The world\'s largest single e-commerce shopping day. Extreme surge in cookie stuffing, rogue coupon site brand hijacking, and illegitimate attribution theft.',
    primarySolution: 'Affiliate Monitoring / Affiliate Fraud Detection',
    targetPersona: 'Affiliate Marketing Head',
    featuredKeywords: [
      'cookie stuffing affiliate fraud',
      'black friday affiliate brand hijacking',
      'rogue coupon site monitoring',
      'attribution theft protection ecommerce'
    ],
    recommendedAction: 'NEW',
    suggestedFunnel: 'BOFU',
    businessValue: 'Critical',
    estimatedBudgetRisk: '20–35% loss in net affiliate margins due to cookie stuffing and unauthorized pop-under drops',
    strategicImportance: 'Q4 Revenue Safeguard: Fraudulent affiliates begin dropping hidden cookies 8 weeks prior to Black Friday to claim organic conversions.',
    suggestedTopics: [
      {
        title: 'Black Friday Affiliate Fraud Safeguards: Stopping Cookie Stuffing & Unauthorized Coupon Bidding',
        keyword: 'cookie stuffing affiliate fraud',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'NEW',
        targetPersona: 'Affiliate Marketing Head',
        productMapping: 'Affiliate Monitoring / Affiliate Fraud Detection',
        rationale: 'Essential BOFU decision guide for US enterprise affiliate leaders preparing for Q4 peak.'
      }
    ]
  },
  {
    id: 'event-cyber-monday-usa',
    eventName: 'Cyber Monday & Cyber Week E-Commerce Peak',
    region: 'USA',
    eventWindow: 'Late November - Early December 2026',
    eventDateRange: 'Nov 30 - Dec 4, 2026',
    contentRampUpWeeks: 8,
    rampUpStartDate: 'October 1, 2026',
    description: 'Peak online transaction week in North America. Massive reliance on marketplace sales, programmatic retargeting, and automated ad fraud defense.',
    primarySolution: 'Digital Shelf / Marketplace Monitoring',
    targetPersona: 'E-commerce Head',
    featuredKeywords: [
      'map violation monitoring amazon',
      'cyber monday ad fraud protection',
      'digital shelf share of voice sov',
      'best ad fraud detection software'
    ],
    recommendedAction: 'EXPAND',
    suggestedFunnel: 'BOFU',
    businessValue: 'Critical',
    estimatedBudgetRisk: '15–25% ad spend waste from programmatic click farms targeting holiday shopping campaigns',
    strategicImportance: 'Margin Preservation: Automated MAP enforcement and click fraud filtering protect Amazon Buy-Box revenue during Cyber Week.',
    suggestedTopics: [
      {
        title: 'Cyber Monday Digital Shelf Playbook: Automated MAP Enforcement & Buy-Box Defense',
        keyword: 'map violation monitoring amazon',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'EXPAND',
        targetPersona: 'E-commerce Head',
        productMapping: 'Digital Shelf / Marketplace Monitoring',
        rationale: 'Comprehensive strategy guide for US brands managing high-volume Amazon and retail marketplace stores.'
      }
    ]
  },
  {
    id: 'event-memorial-day-usa',
    eventName: 'Memorial Day & Summer Retail Sales',
    region: 'USA',
    eventWindow: 'Late May 2026',
    eventDateRange: 'May 25, 2026',
    contentRampUpWeeks: 4,
    rampUpStartDate: 'April 25, 2026',
    description: 'First major retail ad spend wave of the summer season. Requires programmatic brand safety filters, CTV ad verification, and invalid click prevention.',
    primarySolution: 'Brand Safety',
    targetPersona: 'Brand Safety Head',
    featuredKeywords: [
      'programmatic brand safety filters',
      'digital shelf share of voice sov',
      'ctv ad fraud prevention usa',
      'brand suitability guidelines garm'
    ],
    recommendedAction: 'EXPAND',
    suggestedFunnel: 'MOFU',
    businessValue: 'High',
    estimatedBudgetRisk: '10–18% brand safety misalignment and wasted programmatic impressions',
    strategicImportance: 'Brand Equity Protection: Prevents ad placement next to sensational summer news content while maintaining programmatic scale.',
    suggestedTopics: [
      {
        title: 'Summer Retail Brand Safety Checklist: Programmatic Verification & Pre-Bid Filtering',
        keyword: 'programmatic brand safety filters',
        contentType: 'Website Blog',
        funnel: 'MOFU',
        action: 'EXPAND',
        targetPersona: 'Brand Safety Head',
        productMapping: 'Brand Safety',
        rationale: 'Actionable brand protection framework for US media planning agencies before summer campaigns.'
      }
    ]
  },
  {
    id: 'event-super-bowl-usa',
    eventName: 'Super Bowl Advertising & High-CPM Video Peak',
    region: 'USA',
    eventWindow: 'February 2026',
    eventDateRange: 'Feb 8, 2026',
    contentRampUpWeeks: 4,
    rampUpStartDate: 'January 10, 2026',
    description: 'Highest CPM advertising event in the US. High surge in digital extension fraud, social media impersonation, and domain spoofing around big-game commercials.',
    primarySolution: 'Ad Fraud Detection',
    targetPersona: 'Performance Marketing Head',
    featuredKeywords: [
      'high cpm video ad fraud protection',
      'domain spoofing prevention usa',
      'social media brand impersonation',
      'pre-bid ivt filtering enterprise'
    ],
    recommendedAction: 'NEW',
    suggestedFunnel: 'BOFU',
    businessValue: 'High',
    estimatedBudgetRisk: '25–40% premium video CPM wastage on domain-spoofed video inventory',
    strategicImportance: 'Premium Media Audit: Enterprise brands spending $7M+ on video extensions need strict pre-bid IVT and domain verification.',
    suggestedTopics: [
      {
        title: 'Super Bowl Digital Extensions Audit: Eliminating Domain Spoofing & Video Impression Waste',
        keyword: 'high cpm video ad fraud protection',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'NEW',
        targetPersona: 'Performance Marketing Head',
        productMapping: 'Ad Fraud Detection',
        rationale: 'High-value BOFU content targeted at enterprise CMOs and agency leads managing million-dollar video buys.'
      }
    ]
  },
  {
    id: 'event-back-to-school-usa',
    eventName: 'Back-to-School & Fall E-Commerce Ramp-Up',
    region: 'USA',
    eventWindow: 'July - August 2026',
    eventDateRange: 'Jul 15 - Aug 31, 2026',
    contentRampUpWeeks: 6,
    rampUpStartDate: 'June 1, 2026',
    description: 'Second-largest US retail spending event after Q4. Surge in unauthorized marketplace resellers, counterfeit listings, and fake social commerce storefronts.',
    primarySolution: 'Digital Shelf / Marketplace Monitoring',
    targetPersona: 'Brand Safety Head',
    featuredKeywords: [
      'unauthorized reseller enforcement',
      'counterfeit product removal amazon',
      'social commerce brand protection',
      'marketplace seller compliance'
    ],
    recommendedAction: 'SUPPORTING',
    suggestedFunnel: 'MOFU',
    businessValue: 'Medium',
    estimatedBudgetRisk: '10–15% revenue leakage to rogue marketplace sellers and unauthorized discounts',
    strategicImportance: 'Channel Integrity: Protecting MAP pricing and product listings on Amazon, Walmart, and Target marketplace platforms during peak school shopping.',
    suggestedTopics: [
      {
        title: 'Back-to-School Marketplace Governance: Fighting Counterfeits & MAP Violations on Amazon & Walmart',
        keyword: 'unauthorized reseller enforcement',
        contentType: 'SEO / Guest Post',
        funnel: 'MOFU',
        action: 'SUPPORTING',
        targetPersona: 'Brand Safety Head',
        productMapping: 'Digital Shelf / Marketplace Monitoring',
        rationale: 'Guides brand protection managers through automated enforcement workflows.'
      }
    ]
  },

  // ==========================================
  // MENA
  // ==========================================
  {
    id: 'event-ramadan-mena',
    eventName: 'Ramadan & Eid Advertising Peak',
    region: 'MENA',
    eventWindow: 'February - April 2026',
    eventDateRange: 'Feb 18 - Mar 20 (Ramadan), Mar 21 - Mar 25 (Eid), 2026',
    contentRampUpWeeks: 8,
    rampUpStartDate: 'January 1, 2026',
    description: 'The single most lucrative digital advertising season in UAE, KSA, and Egypt. Over 50% of annual digital ad spend occurs during Ramadan. Arabic creative compliance and brand safety are imperative.',
    primarySolution: 'Brand Safety',
    targetPersona: 'Brand Safety Head',
    featuredKeywords: [
      'ramadan campaign brand safety mena',
      'arabic creative compliance guidelines',
      'ad fraud detection uae saudi',
      'affiliate compliance ksa ecommerce'
    ],
    recommendedAction: 'REVAMP',
    suggestedFunnel: 'BOFU',
    businessValue: 'Critical',
    estimatedBudgetRisk: '20–30% digital spend waste due to unvetted Arabic publisher networks & non-compliant copy',
    strategicImportance: 'Top Regional Season: Over 50% of annual GCC ad spend happens during Ramadan. Contextual Arabic vetting & pre-bid IVT filtering are mandatory.',
    suggestedTopics: [
      {
        title: 'Ramadan & Eid Campaign Blueprint: Arabic Creative Compliance & Brand Safety in KSA & UAE',
        keyword: 'ramadan campaign brand safety mena',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'REVAMP',
        targetPersona: 'Brand Safety Head',
        productMapping: 'Brand Safety',
        rationale: 'Core Ramadan guide for GCC agency heads and brand marketers managing high-volume regional campaigns.'
      },
      {
        title: 'Saudi & UAE E-Commerce Protection: Stopping Affiliate Fraud During Ramadan Shopping',
        keyword: 'affiliate compliance ksa ecommerce',
        contentType: 'Website Blog',
        funnel: 'MOFU',
        action: 'NEW',
        targetPersona: 'Affiliate Marketing Head',
        productMapping: 'Affiliate Monitoring / Affiliate Fraud Detection',
        rationale: 'Educates GCC e-commerce leaders on protecting affiliate payouts during peak holiday ordering.'
      }
    ]
  },
  {
    id: 'event-white-friday-mena',
    eventName: 'White Friday & Yellow Friday Sales (Noon & Amazon AE)',
    region: 'MENA',
    eventWindow: 'November 2026',
    eventDateRange: 'Nov 20 - Nov 28, 2026',
    contentRampUpWeeks: 6,
    rampUpStartDate: 'October 1, 2026',
    description: 'MENA\'s premier online shopping week across Amazon.ae, Noon.com, and regional D2C platforms. High incidence of price scraping, buy-box loss, and affiliate attribution theft.',
    primarySolution: 'Digital Shelf / Marketplace Monitoring',
    targetPersona: 'E-commerce Head',
    featuredKeywords: [
      'noon express price scraping monitoring',
      'amazon ae buy box strategy',
      'banking app fraud prevention mena',
      'white friday affiliate fraud gcc'
    ],
    recommendedAction: 'NEW',
    suggestedFunnel: 'BOFU',
    businessValue: 'Critical',
    estimatedBudgetRisk: '15–22% buy box revenue loss from rogue price scrapers on Noon and Amazon AE',
    strategicImportance: 'Marketplace Dominance: Protecting seller margins and buy-box ownership across Noon and Amazon AE ensures maximum Q4 profitability.',
    suggestedTopics: [
      {
        title: 'White Friday E-Commerce Playbook: Winning the Buy Box on Noon & Amazon AE',
        keyword: 'noon express price scraping monitoring',
        contentType: 'Website Blog',
        funnel: 'BOFU',
        action: 'NEW',
        targetPersona: 'E-commerce Head',
        productMapping: 'Digital Shelf / Marketplace Monitoring',
        rationale: 'Crucial guide for enterprise e-commerce managers in UAE, KSA, and Egypt preparing for White Friday.'
      }
    ]
  },
  {
    id: 'event-dubai-shopping-festival-mena',
    eventName: 'Dubai Shopping Festival (DSF) & Q1 Retail Peak',
    region: 'MENA',
    eventWindow: 'December 2026 - January 2027',
    eventDateRange: 'Dec 15, 2026 - Jan 29, 2027',
    contentRampUpWeeks: 6,
    rampUpStartDate: 'November 1, 2026',
    description: 'World-renowned retail and tourism shopping festival in Dubai. High volume of omnichannel mobile app installs, loyalty app fraud, and click spoofing.',
    primarySolution: 'Ad Fraud Detection',
    targetPersona: 'Performance Marketing Head',
    featuredKeywords: [
      'app install fraud uae ecommerce',
      'click spoofing prevention gcc',
      'omnichannel retail ad fraud',
      'mobile app attribution validation'
    ],
    recommendedAction: 'EXPAND',
    suggestedFunnel: 'MOFU',
    businessValue: 'High',
    estimatedBudgetRisk: '15–20% mobile ad spend waste from fake app installs and click injection during DSF',
    strategicImportance: 'Mobile Loyalty Defense: High-incentive app install campaigns during DSF are heavily targeted by automated botnets and click farms.',
    suggestedTopics: [
      {
        title: 'DSF App Acquisition Defense: Eliminating Install Fraud & Click Spoofing in UAE Retail Apps',
        keyword: 'app install fraud uae ecommerce',
        contentType: 'SEO / Guest Post',
        funnel: 'MOFU',
        action: 'EXPAND',
        targetPersona: 'Performance Marketing Head',
        productMapping: 'Ad Fraud Detection',
        rationale: 'Helps app growth leads in Dubai and Riyadh protect user acquisition budgets.'
      }
    ]
  },
  {
    id: 'event-gitex-mena',
    eventName: 'GITEX Global B2B Tech & Enterprise Summit',
    region: 'MENA',
    eventWindow: 'October 2026',
    eventDateRange: 'Oct 12 - Oct 16, 2026',
    contentRampUpWeeks: 6,
    rampUpStartDate: 'September 1, 2026',
    description: 'The world\'s largest B2B tech exhibition hosted in Dubai. Intense enterprise search bidding, competitor brand hijacking on Google Ads, and B2B form spam.',
    primarySolution: 'Creative Compliance',
    targetPersona: 'Brand Protection Head',
    featuredKeywords: [
      'b2b ad fraud prevention mena',
      'google ads competitor brand hijacking uae',
      'enterprise lead form spam filtering',
      'gitex campaign brand protection'
    ],
    recommendedAction: 'SUPPORTING',
    suggestedFunnel: 'TOFU',
    businessValue: 'Medium',
    estimatedBudgetRisk: 'Fake B2B lead submissions and competitor search ad hijacking during peak tech week',
    strategicImportance: 'Enterprise Lead Quality: Ensures high-value B2B lead generation campaigns for tech enterprises yield legitimate C-level contacts during GITEX.',
    suggestedTopics: [
      {
        title: 'GITEX Campaign Security: Protecting B2B Paid Search from Competitor Hijacking & Lead Spam',
        keyword: 'google ads competitor brand hijacking uae',
        contentType: 'Website Blog',
        funnel: 'TOFU',
        action: 'SUPPORTING',
        targetPersona: 'Brand Protection Head',
        productMapping: 'Creative Compliance',
        rationale: 'B2B enterprise focus for tech vendors showcasing at GITEX Dubai.'
      }
    ]
  }
];


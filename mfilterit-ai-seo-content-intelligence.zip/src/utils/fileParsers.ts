import * as XLSX from 'xlsx';
import {
  MasterKeywordRecord,
  LiveRankingRecord,
  RankingMovement,
  CombinedKeywordOpportunity,
  MasterDataSourceInfo,
  LiveRankingWorkbookInfo,
  LiveRankingTabInfo,
} from '../types/keywordIntelligence';
import { mFilterItSolution, FunnelStage, ContentAction, PotentialLevel, IcpPersona } from '../types/seo';

// Helper to normalize column headers
function normalizeHeader(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Intelligent Parser for Master Keyword CSV/Excel files
 */
export async function parseMasterKeywordFile(
  file: File,
  region: 'INDIA' | 'USA' | 'MENA'
): Promise<{
  records: MasterKeywordRecord[];
  detectedColumns: string[];
  validationWarnings: string[];
}> {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: 'array' });
  const firstSheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[firstSheetName];

  if (!sheet) {
    throw new Error(`File is empty or corrupted.`);
  }

  const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(sheet, { defval: '' });
  if (rawRows.length === 0) {
    return { records: [], detectedColumns: [], validationWarnings: ['The uploaded file contains no data rows.'] };
  }

  const detectedColumns = Object.keys(rawRows[0]);
  const validationWarnings: string[] = [];

  // Identify column roles dynamically
  let keywordCol: string | null = null;
  let volumeCol: string | null = null;
  let kdCol: string | null = null;
  let cpcCol: string | null = null;
  let intentCol: string | null = null;
  let categoryCol: string | null = null;
  let productCol: string | null = null;

  for (const col of detectedColumns) {
    const norm = normalizeHeader(col);
    if (!keywordCol && (norm === 'keyword' || norm === 'keywords' || norm === 'query' || norm === 'searchterm')) {
      keywordCol = col;
    } else if (!volumeCol && (norm === 'searchvolume' || norm === 'volume' || norm === 'monthlysearches' || norm === 'sv')) {
      volumeCol = col;
    } else if (!kdCol && (norm === 'kd' || norm === 'keyworddifficulty' || norm === 'difficulty' || norm === 'competitionlevel')) {
      kdCol = col;
    } else if (!cpcCol && (norm === 'cpc' || norm === 'costperclick' || norm === 'bid')) {
      cpcCol = col;
    } else if (!intentCol && (norm === 'intent' || norm === 'searchintent' || norm === 'type')) {
      intentCol = col;
    } else if (!categoryCol && (norm === 'category' || norm === 'keywordcategory' || norm === 'cluster' || norm === 'topic')) {
      categoryCol = col;
    } else if (!productCol && (norm === 'product' || norm === 'solution' || norm === 'productmapping')) {
      productCol = col;
    }
  }

  if (!keywordCol) {
    validationWarnings.push(`No explicit 'Keyword' column detected. Assumed first column '${detectedColumns[0]}' as keyword.`);
    keywordCol = detectedColumns[0];
  }

  const seenKeywords = new Set<string>();
  const records: MasterKeywordRecord[] = [];
  let duplicates = 0;
  let emptyRows = 0;

  rawRows.forEach((row, index) => {
    const rawKw = String(row[keywordCol!] || '').trim();
    if (!rawKw) {
      emptyRows++;
      return;
    }

    const lowerKw = rawKw.toLowerCase();
    if (seenKeywords.has(lowerKw)) {
      duplicates++;
      return;
    }
    seenKeywords.add(lowerKw);

    // Extract other metrics
    const vol = volumeCol ? parseInt(String(row[volumeCol]).replace(/[^0-9]/g, ''), 10) : undefined;
    const kd = kdCol ? parseFloat(String(row[kdCol]).replace(/[^0-9.]/g, '')) : undefined;
    const cpc = cpcCol ? parseFloat(String(row[cpcCol]).replace(/[^0-9.]/g, '')) : undefined;
    const rawIntent = intentCol ? String(row[intentCol]).trim() : undefined;

    let searchIntent: MasterKeywordRecord['searchIntent'] = 'Informational';
    if (rawIntent) {
      const lowerIntent = rawIntent.toLowerCase();
      if (lowerIntent.includes('comm') || lowerIntent.includes('investigation')) searchIntent = 'Commercial Investigation';
      else if (lowerIntent.includes('trans') || lowerIntent.includes('buy')) searchIntent = 'Transactional';
      else if (lowerIntent.includes('nav')) searchIntent = 'Navigational';
    }

    // Preserve all additional fields
    const additionalFields: Record<string, any> = {};
    for (const key of detectedColumns) {
      if (key !== keywordCol && key !== volumeCol && key !== kdCol && key !== cpcCol && key !== intentCol) {
        additionalFields[key] = row[key];
      }
    }

    records.push({
      id: `${region.toLowerCase()}-kw-${index + 1}`,
      keyword: rawKw,
      searchVolume: !isNaN(Number(vol)) ? vol : undefined,
      keywordDifficulty: !isNaN(Number(kd)) ? kd : undefined,
      cpc: !isNaN(Number(cpc)) ? cpc : undefined,
      searchIntent,
      category: categoryCol ? String(row[categoryCol]).trim() : undefined,
      product: productCol ? String(row[productCol]).trim() : undefined,
      region,
      additionalFields,
    });
  });

  if (duplicates > 0) {
    validationWarnings.push(`${duplicates} duplicate keyword rows identified and consolidated.`);
  }
  if (emptyRows > 0) {
    validationWarnings.push(`${emptyRows} empty rows excluded.`);
  }

  return { records, detectedColumns, validationWarnings };
}

/**
 * Intelligent Multi-Tab Parser for the single Live Ranking Workbook
 */
export async function parseLiveRankingWorkbook(
  file: File
): Promise<{
  tabs: {
    INDIA: LiveRankingTabInfo;
    USA: LiveRankingTabInfo;
    MENA: LiveRankingTabInfo;
  };
  validationWarnings: string[];
}> {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: 'array' });
  const sheetNames = workbook.SheetNames;
  const validationWarnings: string[] = [];

  // Match sheets for India, USA, MENA
  const findSheet = (regionName: string) => {
    return sheetNames.find((s) => {
      const norm = normalizeHeader(s);
      return norm.includes(regionName.toLowerCase()) && (norm.includes('rank') || norm.includes('live') || sheetNames.length <= 3);
    });
  };

  const indiaSheetName = findSheet('india') || sheetNames.find(s => normalizeHeader(s).includes('india'));
  const usaSheetName = findSheet('usa') || sheetNames.find(s => normalizeHeader(s).includes('usa') || normalizeHeader(s).includes('us'));
  const menaSheetName = findSheet('mena') || sheetNames.find(s => normalizeHeader(s).includes('mena') || normalizeHeader(s).includes('gcc') || normalizeHeader(s).includes('uae'));

  if (!indiaSheetName) validationWarnings.push(`Tab 'India Live Rankings' was not explicitly found by name in workbook.`);
  if (!usaSheetName) validationWarnings.push(`Tab 'USA Live Rankings' was not explicitly found by name in workbook.`);
  if (!menaSheetName) validationWarnings.push(`Tab 'MENA Live Rankings' was not explicitly found by name in workbook.`);

  const parseTab = (
    sheetName: string | undefined,
    region: 'INDIA' | 'USA' | 'MENA',
    expectedName: 'India Live Rankings' | 'USA Live Rankings' | 'MENA Live Rankings'
  ): LiveRankingTabInfo => {
    if (!sheetName || !workbook.Sheets[sheetName]) {
      return {
        tabName: expectedName,
        region,
        rowCount: 0,
        detectedColumns: [],
        records: [],
        validationWarnings: [`Missing tab '${expectedName}'. Awaiting sheet connection.`],
      };
    }

    const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' });
    if (rawRows.length === 0) {
      return {
        tabName: expectedName,
        region,
        rowCount: 0,
        detectedColumns: [],
        records: [],
        validationWarnings: [`Tab '${sheetName}' contains no data rows.`],
      };
    }

    const detectedColumns = Object.keys(rawRows[0]);
    const tabWarnings: string[] = [];

    // Identify columns
    let keywordCol: string | null = null;
    let rankCol: string | null = null;
    let prevRankCol: string | null = null;
    let urlCol: string | null = null;
    let dateCol: string | null = null;

    for (const col of detectedColumns) {
      const norm = normalizeHeader(col);
      if (!keywordCol && (norm === 'keyword' || norm === 'query' || norm === 'searchterm' || norm === 'targetkeyword')) {
        keywordCol = col;
      } else if (!rankCol && (norm === 'position' || norm === 'currentposition' || norm === 'rank' || norm === 'currentrank' || norm === 'latestrank')) {
        rankCol = col;
      } else if (!prevRankCol && (norm === 'previousposition' || norm === 'prevrank' || norm === 'previousrank' || norm === 'lastweek' || norm === 'priorposition')) {
        prevRankCol = col;
      } else if (!urlCol && (norm === 'url' || norm === 'rankingurl' || norm === 'page' || norm === 'landingpage')) {
        urlCol = col;
      } else if (!dateCol && (norm === 'date' || norm === 'checkdate' || norm === 'week' || norm === 'updated')) {
        dateCol = col;
      }
    }

    if (!keywordCol) {
      keywordCol = detectedColumns[0];
      tabWarnings.push(`Keyword column not named explicitly in '${sheetName}'. Assumed '${keywordCol}'.`);
    }

    if (!rankCol) {
      // Find first column containing numeric position
      const candidate = detectedColumns.find((c) => {
        const val = rawRows[0]?.[c];
        return typeof val === 'number' || (!isNaN(parseInt(String(val), 10)) && c !== keywordCol);
      });
      rankCol = candidate || detectedColumns[1] || 'Rank';
      tabWarnings.push(`Ranking/Position column not named explicitly in '${sheetName}'. Assumed '${rankCol}'.`);
    }

    const records: LiveRankingRecord[] = [];

    rawRows.forEach((row, idx) => {
      const kw = String(row[keywordCol!] || '').trim();
      if (!kw) return;

      const rawRank = row[rankCol!];
      const currentPos = parseInt(String(rawRank).replace(/[^0-9]/g, ''), 10) || 100;

      let prevPos: number | undefined = undefined;
      if (prevRankCol && row[prevRankCol] !== undefined && row[prevRankCol] !== '') {
        const parsed = parseInt(String(row[prevRankCol]).replace(/[^0-9]/g, ''), 10);
        if (!isNaN(parsed) && parsed > 0) prevPos = parsed;
      }

      let positionChange: number | undefined = undefined;
      let movement: RankingMovement = 'STABLE';
      let rankingTrend: 'Rising' | 'Declining' | 'Stable' | 'New' | 'Lost' = 'Stable';

      if (prevPos !== undefined) {
        positionChange = prevPos - currentPos; // Positive means rank got better (e.g. from 14 to 10 = +4)
        if (positionChange > 0) {
          movement = 'IMPROVING';
          rankingTrend = 'Rising';
        } else if (positionChange < 0) {
          movement = 'DECLINING';
          rankingTrend = 'Declining';
        } else {
          movement = 'STABLE';
          rankingTrend = 'Stable';
        }
      } else {
        movement = 'NEWLY RANKING';
        rankingTrend = 'New';
      }

      const additionalFields: Record<string, any> = {};
      for (const k of detectedColumns) {
        if (k !== keywordCol && k !== rankCol && k !== prevRankCol && k !== urlCol && k !== dateCol) {
          additionalFields[k] = row[k];
        }
      }

      records.push({
        id: `${region.toLowerCase()}-live-${idx + 1}`,
        keyword: kw,
        currentPosition: currentPos,
        previousPosition: prevPos,
        positionChange,
        movement,
        rankingTrend,
        url: urlCol ? String(row[urlCol]).trim() : undefined,
        date: dateCol ? String(row[dateCol]).trim() : undefined,
        region,
        additionalFields,
      });
    });

    return {
      tabName: expectedName,
      region,
      rowCount: records.length,
      detectedColumns,
      records,
      validationWarnings: tabWarnings,
    };
  };

  return {
    tabs: {
      INDIA: parseTab(indiaSheetName, 'INDIA', 'India Live Rankings'),
      USA: parseTab(usaSheetName, 'USA', 'USA Live Rankings'),
      MENA: parseTab(menaSheetName, 'MENA', 'MENA Live Rankings'),
    },
    validationWarnings,
  };
}

/**
 * Solution mapper helper based on keywords
 */
function mapSolutionFromKeyword(kw: string): mFilterItSolution {
  const lower = kw.toLowerCase();
  if (lower.includes('affiliate') || lower.includes('brand bidding') || lower.includes('coupon') || lower.includes('cookie stuffing')) {
    return 'Affiliate Monitoring / Affiliate Fraud Detection';
  }
  if (lower.includes('brand safety') || lower.includes('suitability') || lower.includes('garm') || lower.includes('toxic content')) {
    return 'Brand Safety';
  }
  if (lower.includes('brand protection') || lower.includes('counterfeit') || lower.includes('trademark') || lower.includes('phishing')) {
    return 'Brand Protection';
  }
  if (lower.includes('creative compliance') || lower.includes('ad creative') || lower.includes('disclaimer') || lower.includes('bfsi')) {
    return 'Creative Compliance';
  }
  if (lower.includes('digital shelf') || lower.includes('map violation') || lower.includes('share of voice') || lower.includes('buy box') || lower.includes('amazon') || lower.includes('quick commerce')) {
    return 'Digital Shelf / Marketplace Monitoring';
  }
  return 'Ad Fraud Detection';
}

function mapPersonaFromKeyword(kw: string, solution: mFilterItSolution): IcpPersona {
  const lower = kw.toLowerCase();
  if (lower.includes('cmo') || lower.includes('executive') || lower.includes('enterprise')) return 'CMO';
  if (solution.includes('Affiliate')) return 'Affiliate Marketing Head';
  if (solution.includes('Digital Shelf')) return 'E-commerce Head';
  if (solution.includes('Brand Protection')) return 'Brand Protection Head';
  if (solution.includes('Brand Safety')) return 'Brand Safety Head';
  if (lower.includes('media') || lower.includes('cpm') || lower.includes('ssai')) return 'Media Buyer';
  return 'Performance Marketing Head';
}

/**
 * Intelligent Cross-Analysis Engine:
 * Compares Master Keywords + Live Rankings to generate actionable Content Opportunities
 */
export function generateCombinedOpportunities(
  masterMap: Record<'INDIA' | 'USA' | 'MENA', MasterKeywordRecord[]>,
  liveMap: Record<'INDIA' | 'USA' | 'MENA', LiveRankingRecord[]>,
  selectedRegion: 'ALL' | 'INDIA' | 'USA' | 'MENA'
): CombinedKeywordOpportunity[] {
  const regions: ('INDIA' | 'USA' | 'MENA')[] =
    selectedRegion === 'ALL' ? ['INDIA', 'USA', 'MENA'] : [selectedRegion];

  const opportunities: CombinedKeywordOpportunity[] = [];
  let liveWorkbookCount = 0;
  let masterConfirmedCount = 0;

  regions.forEach((reg) => {
    const masterKeywords = masterMap[reg] || [];
    const liveRankings = liveMap[reg] || [];

    const liveRankingDict = new Map<string, LiveRankingRecord>();
    liveRankings.forEach((r) => {
      liveRankingDict.set(r.keyword.toLowerCase().trim(), r);
    });

    const processedKeys = new Set<string>();

    // 1. Process ALL Live Ranking Workbook records first (Rule 1 & 4)
    liveRankings.forEach((liveRank, idx) => {
      const normKw = liveRank.keyword.toLowerCase().trim();
      const uniqueKey = `${reg}-${normKw}`;
      if (processedKeys.has(uniqueKey)) return;
      processedKeys.add(uniqueKey);
      liveWorkbookCount++;

      const matchingMaster = masterKeywords.find(m => m.keyword.toLowerCase().trim() === normKw);
      const searchVolume = matchingMaster?.searchVolume || 1500;
      const solution = mapSolutionFromKeyword(liveRank.keyword);
      const persona = mapPersonaFromKeyword(liveRank.keyword, solution);

      const pos = liveRank.currentPosition;
      const change = liveRank.positionChange;

      let category: CombinedKeywordOpportunity['category'] = 'QUICK WINS';
      let action: ContentAction = 'EXPAND';
      let rationale = '';
      let cannibalization: CombinedKeywordOpportunity['cannibalizationRisk'] = 'Low';
      let funnel: FunnelStage = 'MOFU';
      let leadPot: PotentialLevel = 'Medium';
      let convPot: PotentialLevel = 'Medium';
      let priority: 'High' | 'Medium' | 'Low' = 'Medium';

      const isCommercial =
        normKw.includes('software') ||
        normKw.includes('tool') ||
        normKw.includes('best') ||
        normKw.includes('prevention') ||
        normKw.includes('detection') ||
        normKw.includes('audit') ||
        normKw.includes('compliance');

      if (isCommercial) {
        funnel = 'BOFU';
        leadPot = 'High';
        convPot = 'High';
        priority = 'High';
      }

      if (pos >= 11 && pos <= 20) {
        category = 'STRIKING DISTANCE';
        action = 'EXPAND';
        rationale = `Ranking #${pos} in striking distance of page 1. Optimize on-page topical depth and internal links to break into Top 10.`;
        priority = 'High';
      } else if (pos >= 4 && pos <= 10) {
        category = 'QUICK WINS';
        action = 'EXPAND';
        rationale = `Established on Page 1 (#${pos}). High click-through leverage with conversion-oriented FAQ and rich schema.`;
        priority = 'High';
      } else if (change !== undefined && change < 0) {
        category = 'DECLINING';
        action = 'REVAMP';
        rationale = `Rank dropped by ${Math.abs(change)} positions (from #${liveRank.previousPosition} to #${pos}). Mandatory content refresh to reclaim lost organic traffic.`;
        priority = 'High';
        cannibalization = 'Medium';
      } else if (change !== undefined && change > 0) {
        category = 'RISING';
        action = 'SUPPORTING';
        rationale = `Positive momentum: climbed +${change} positions to #${pos}. Create supporting cluster article to sustain upward trajectory.`;
      } else if (liveRank.movement === 'NEWLY RANKING') {
        category = 'NEWLY RANKING';
        action = 'SUPPORTING';
        rationale = `Recently indexed and entering SERPs at #${pos}. Strengthen with internal links from core pillar.`;
      } else {
        category = 'QUICK WINS';
        action = 'EXPAND';
        rationale = `Currently ranking #${pos} according to weekly live ranking workbook.`;
      }

      opportunities.push({
        id: `live-opp-${reg.toLowerCase()}-${idx}`,
        keyword: liveRank.keyword,
        region: reg,
        category,
        currentPosition: pos,
        previousPosition: liveRank.previousPosition,
        positionChange: change,
        movement: liveRank.movement,
        searchVolume,
        keywordDifficulty: matchingMaster?.keywordDifficulty,
        searchIntent: matchingMaster?.searchIntent || (isCommercial ? 'Commercial Investigation' : 'Informational'),
        funnelStage: funnel,
        productMapping: solution,
        icpPersona: persona,
        leadPotential: leadPot,
        conversionPotential: convPot,
        recommendedAction: action,
        existingUrl: liveRank.url || matchingMaster?.additionalFields?.url,
        actionRationale: rationale,
        cannibalizationRisk: cannibalization,
        priority,
        serpsCheckDate: liveRank.date || 'Oct 14, 2026',
        serpsSourceUrl: liveRank.url || `https://www.google.com/search?q=${encodeURIComponent(liveRank.keyword)}&gl=${reg.toLowerCase()}&domain=mfilterit.com`,
      });
    });

    // 2. Process Master Keywords ONLY when confirmed organic ranking exists (Rule 2 & 3)
    masterKeywords.forEach((mKw) => {
      const normKw = mKw.keyword.toLowerCase().trim();
      const uniqueKey = `${reg}-${normKw}`;
      if (processedKeys.has(uniqueKey)) return;

      const liveRank = liveRankingDict.get(normKw);
      if (liveRank && liveRank.currentPosition) {
        processedKeys.add(uniqueKey);
        masterConfirmedCount++;

        const solution = mapSolutionFromKeyword(mKw.keyword);
        const persona = mapPersonaFromKeyword(mKw.keyword, solution);
        const pos = liveRank.currentPosition;
        const change = liveRank.positionChange;

        const isCommercial =
          normKw.includes('software') ||
          normKw.includes('tool') ||
          normKw.includes('best') ||
          normKw.includes('prevention') ||
          normKw.includes('detection');

        let category: CombinedKeywordOpportunity['category'] = 'QUICK WINS';
        let action: ContentAction = 'EXPAND';
        let rationale = `Confirmed organic ranking at #${pos} for mfilterit.com in ${reg}. Verified via weekly live ranking workbook & live SERP check.`;
        let funnel: FunnelStage = isCommercial ? 'BOFU' : 'MOFU';
        let priority: 'High' | 'Medium' | 'Low' = isCommercial ? 'High' : 'Medium';

        opportunities.push({
          id: `master-conf-${reg.toLowerCase()}-${mKw.id}`,
          keyword: mKw.keyword,
          region: reg,
          category,
          currentPosition: pos,
          previousPosition: liveRank.previousPosition,
          positionChange: change,
          movement: liveRank.movement,
          searchVolume: mKw.searchVolume,
          keywordDifficulty: mKw.keywordDifficulty,
          searchIntent: mKw.searchIntent || (isCommercial ? 'Commercial Investigation' : 'Informational'),
          funnelStage: funnel,
          productMapping: solution,
          icpPersona: persona,
          leadPotential: isCommercial ? 'High' : 'Medium',
          conversionPotential: isCommercial ? 'High' : 'Medium',
          recommendedAction: action,
          existingUrl: liveRank.url || mKw.additionalFields?.url,
          actionRationale: rationale,
          cannibalizationRisk: 'Low',
          priority,
          serpsCheckDate: liveRank.date || 'Oct 14, 2026',
          serpsSourceUrl: liveRank.url || `https://www.google.com/search?q=${encodeURIComponent(mKw.keyword)}&gl=${reg.toLowerCase()}&domain=mfilterit.com`,
        });
      }
      // Rule 3: Exclude master-sheet keywords with no confirmed organic ranking entirely.
    });
  });

  console.log(`[Keyword Intelligence Inclusion Counts] Live Workbook Records: ${liveWorkbookCount}, Master Sheet Confirmed Rankings: ${masterConfirmedCount}, Total Included: ${opportunities.length}`);

  return opportunities;
}

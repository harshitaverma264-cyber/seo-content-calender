import { ContentItem, ContentTypeFilter, FunnelStage, ContentAction } from '../types/seo';

export interface SearchIntentClassification {
  intent: 'Informational' | 'Commercial Investigation' | 'Transactional' | 'Navigational';
  funnelStage: FunnelStage;
  recommendedFormat: string;
  recommendedAction: ContentAction;
  intentRationale: string;
}

/**
 * Classifies search intent based on keyword data, live SERP evidence, and existing rankings.
 * Maps:
 * - Informational -> TOFU (Top of Funnel)
 * - Commercial Investigation -> MOFU / BOFU (Middle/Bottom of Funnel)
 * - Transactional -> BOFU (Bottom of Funnel)
 * - Navigational -> BOFU (Brand Navigation)
 */
export function classifySearchIntentAndFunnel(
  keyword: string,
  liveSerpData?: {
    serpResults?: { rank: number; domain: string; title: string }[];
    topBlogs?: any[];
    searchIntent?: string;
  }
): SearchIntentClassification {
  const cleanKw = (keyword || '').toLowerCase().trim();

  let intent: 'Informational' | 'Commercial Investigation' | 'Transactional' | 'Navigational' = 'Commercial Investigation';
  let funnelStage: FunnelStage = 'BOFU';
  let recommendedFormat = 'Website Blog';
  let recommendedAction: ContentAction = 'NEW';
  let intentRationale = '';

  const isBuyOrPricing = cleanKw.includes('buy') || cleanKw.includes('pricing') || cleanKw.includes('cost') || cleanKw.includes('quote') || cleanKw.includes('audit') || cleanKw.includes('demo');
  const isCompareOrSoftware = cleanKw.includes('best') || cleanKw.includes('vs') || cleanKw.includes('tool') || cleanKw.includes('software') || cleanKw.includes('platform') || cleanKw.includes('top') || cleanKw.includes('checklist') || cleanKw.includes('comparison');
  const isInfo = cleanKw.includes('what is') || cleanKw.includes('how to') || cleanKw.includes('guide') || cleanKw.includes('definition') || cleanKw.includes('types') || cleanKw.includes('meaning') || cleanKw.includes('explained');
  const isNav = cleanKw.includes('login') || cleanKw.includes('portal') || cleanKw.includes('mFilterIt dashboard');

  if (isNav) {
    intent = 'Navigational';
    funnelStage = 'BOFU';
    recommendedFormat = 'Product Feature Overview';
    intentRationale = 'Searcher is seeking direct access to a specific platform or brand portal.';
  } else if (isBuyOrPricing) {
    intent = 'Transactional';
    funnelStage = 'BOFU';
    recommendedFormat = 'Software Audit & Demo Page';
    intentRationale = 'High commercial intent; searcher is evaluating immediate solution procurement or audit options.';
  } else if (isInfo && !isCompareOrSoftware) {
    intent = 'Informational';
    funnelStage = 'TOFU';
    recommendedFormat = 'Ultimate Educational Guide';
    intentRationale = 'Top-of-funnel discovery; searcher wants to understand underlying mechanisms and definitions.';
  } else {
    intent = 'Commercial Investigation';
    funnelStage = 'MOFU';
    recommendedFormat = 'Technical Comparison & Vendor Guide';
    intentRationale = 'Mid/Bottom-of-funnel consideration; searcher is comparing features, benchmarks, or software vendors.';
  }

  // Live SERP evidence adjustments
  if (liveSerpData?.serpResults && liveSerpData.serpResults.length > 0) {
    const mFilterItRank = liveSerpData.serpResults.find((r) => r.domain?.includes('mfilterit'));
    if (mFilterItRank) {
      recommendedAction = 'REVAMP';
      intentRationale += ` Live SERP evidence: mFilterIt ranks at position #${mFilterItRank.rank}. Action set to REVAMP to update content and push into top 2 positions.`;
    } else if (liveSerpData.topBlogs && liveSerpData.topBlogs.length >= 3) {
      recommendedAction = 'EXPAND';
      intentRationale += ` Live SERP evidence: Top competitors cover comprehensive guides. Action set to EXPAND into a broader enterprise framework.`;
    } else {
      recommendedAction = 'NEW';
      intentRationale += ` Live SERP evidence: Verified content gap detected on Google. Action set to NEW.`;
    }
  }

  return {
    intent,
    funnelStage,
    recommendedFormat,
    recommendedAction,
    intentRationale,
  };
}

export interface PrioritizedOpportunity {
  item: ContentItem;
  priorityLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  action: ContentAction;
  leadPotentialLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  leadConversionScore: number; // 0-100 score based on qualified lead/conversion potential
  whyItMatters: string;
  reasons: { title: string; explanation: string }[];
  score: number; // Internal score for ranking only
}

/**
 * Calculates business-impact prioritization for content opportunities.
 * Evaluates:
 * 1. Website Intelligence & Cluster Coverage
 * 2. Competitor Gaps & Verified Search Demand
 * 3. Cannibalization Guard (NEW vs REVAMP/EXPAND/MERGE)
 * 4. Lead & Conversion Potential (0-100 score)
 */
export function calculateOpportunityPriority(item: ContentItem): PrioritizedOpportunity {
  let score = 0;
  let leadConversionScore = 0;
  const reasons: { title: string; explanation: string }[] = [];

  // 1. Business Relevance & Solution Match
  const solutionName = item.productMapping.split('/')[0].trim();
  if (item.productMapping) {
    score += 25;
    leadConversionScore += 25;
    reasons.push({
      title: 'Direct Solution Alignment',
      explanation: `The topic directly relates to mFilterIt's ${solutionName} solution.`,
    });
  }

  // 2. Lead Potential (Qualified leads & ICP decision makers over volume)
  if (item.leadPotential === 'High') {
    score += 30;
    leadConversionScore += 30;
    reasons.push({
      title: 'High Qualified Lead Potential',
      explanation: `Directly targets ${item.icpPersona || 'decision makers'} with high commercial purchase intent.`,
    });
  } else if (item.leadPotential === 'Medium') {
    score += 15;
    leadConversionScore += 18;
    reasons.push({
      title: 'Moderate Lead Potential',
      explanation: 'Nurtures solution evaluation among active media buyers and marketing teams.',
    });
  } else {
    score += 5;
    leadConversionScore += 8;
  }

  // 3. Search & Funnel Intent (BOFU / Commercial Investigation / Transactional)
  if (
    item.funnelStage === 'BOFU' ||
    item.searchIntent === 'Commercial Investigation' ||
    item.searchIntent === 'Transactional'
  ) {
    score += 25;
    leadConversionScore += 25;
    reasons.push({
      title: 'Strong Commercial Intent',
      explanation: 'Searchers are actively researching mitigation options, vendor comparisons, or ROI.',
    });
  } else if (item.funnelStage === 'MOFU') {
    score += 15;
    leadConversionScore += 15;
    reasons.push({
      title: 'Mid-Funnel Consideration',
      explanation: 'Addresses specific operational pain points and technical risks.',
    });
  } else {
    score += 5;
    leadConversionScore += 5;
  }

  // 4. Competitor Content Gap & Verified Search Volume
  const hasCompetitorLinks = Boolean(
    item.competitorReferenceLinks && item.competitorReferenceLinks.length > 0
  );
  if (hasCompetitorLinks) {
    score += 15;
    leadConversionScore += 10;
    reasons.push({
      title: 'Competitor Gap & Demand',
      explanation: 'Competitors cover this intent; mFilterIt captures high-value market share with verified demand.',
    });
  }

  // 5. Cannibalization Guard & Action Efficiency
  if (item.contentAction === 'REVAMP') {
    score += 20;
    leadConversionScore += 10;
    reasons.push({
      title: 'Revamp Equity Upgrade',
      explanation: 'Upgrades existing mFilterIt URL to reclaim ranking equity rather than creating duplicate content.',
    });
  } else if (item.contentAction === 'EXPAND') {
    score += 18;
    leadConversionScore += 10;
    reasons.push({
      title: 'Topical Authority Expansion',
      explanation: 'Deepens an existing ranking page with complementary keywords to strengthen topical authority.',
    });
  } else if (item.contentAction === 'NEW') {
    score += 15;
    leadConversionScore += 10;
    reasons.push({
      title: 'Verified Genuine Gap (NEW)',
      explanation: 'Checked existing mFilterIt pages — genuine gap verified; recommending new targeted page.',
    });
  } else if (item.contentAction === 'MERGE') {
    score += 12;
    leadConversionScore += 8;
    reasons.push({
      title: 'Cannibalization Consolidation',
      explanation: 'Consolidates overlapping pages to build a single high-performing authority asset.',
    });
  } else {
    score += 5;
    leadConversionScore += 5;
  }

  // Cap lead conversion score at 100
  leadConversionScore = Math.min(100, Math.max(20, leadConversionScore));

  // Determine Priority Level: HIGH, MEDIUM, LOW
  let priorityLevel: 'HIGH' | 'MEDIUM' | 'LOW' = 'MEDIUM';
  if (score >= 70 || item.priority === 'High') {
    priorityLevel = 'HIGH';
  } else if (score >= 45 || item.priority === 'Medium') {
    priorityLevel = 'MEDIUM';
  } else {
    priorityLevel = 'LOW';
  }

  const leadPotentialLevel: 'HIGH' | 'MEDIUM' | 'LOW' =
    item.leadPotential === 'High' ? 'HIGH' : item.leadPotential === 'Low' ? 'LOW' : 'MEDIUM';

  // Construct a concise, single-sentence "Why it matters"
  let whyItMatters = '';
  if (item.leadRationale && item.leadRationale.trim().length > 15) {
    const firstSentence = item.leadRationale.split('.')[0].trim();
    whyItMatters = firstSentence.endsWith('.') ? firstSentence : `${firstSentence}.`;
  } else if (item.funnelStage === 'BOFU' && hasCompetitorLinks) {
    whyItMatters = `High commercial intent with competitor coverage; direct ${solutionName} lead driver for ${item.region}.`;
  } else if (item.contentAction === 'REVAMP' || item.contentAction === 'EXPAND') {
    whyItMatters = `High-impact ${item.contentAction.toLowerCase()} opportunity on existing content to capture active commercial demand.`;
  } else if (item.leadPotential === 'High') {
    whyItMatters = `Strong commercial intent with direct ${solutionName} relevance for ${item.region}.`;
  } else {
    whyItMatters = `Strengthens topical authority and supports ${solutionName} conversion paths.`;
  }

  return {
    item,
    priorityLevel,
    action: item.contentAction,
    leadPotentialLevel,
    leadConversionScore,
    whyItMatters,
    reasons: reasons.slice(0, 4),
    score,
  };
}

/**
 * Filters items for the active month and content tab, then returns up to 5 prioritized opportunities.
 */
export function getPrioritizedOpportunities(
  items: ContentItem[],
  activeContentType: ContentTypeFilter
): PrioritizedOpportunity[] {
  if (!items || items.length === 0) {
    return [];
  }

  // Filter by active content tab
  const eligibleItems = items.filter((item) => {
    if (activeContentType !== 'All Content' && item.contentType !== activeContentType) {
      return false;
    }
    return true;
  });

  if (eligibleItems.length === 0) {
    return [];
  }

  // Score and sort descending by business impact
  const scored = eligibleItems.map(calculateOpportunityPriority);

  scored.sort((a, b) => {
    // Priority level weight
    const levelWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 };
    const diff = levelWeight[b.priorityLevel] - levelWeight[a.priorityLevel];
    if (diff !== 0) return diff;
    return b.score - a.score;
  });

  // Maximum of 5 priority opportunities
  return scored.slice(0, 5);
}

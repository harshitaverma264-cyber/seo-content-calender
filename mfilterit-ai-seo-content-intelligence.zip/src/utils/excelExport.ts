import * as XLSX from 'xlsx';
import { ContentItem, MonthlyData, ContentTypeFilter, ContentType } from '../types/seo';
import { getTrustPillarForItem } from './trustPillar';

export interface ExportResult {
  success: boolean;
  message?: string;
  filename?: string;
  rowCount?: number;
}

const columnWidths = [
  { wch: 18 }, // Content Type
  { wch: 42 }, // Topic / Content Title
  { wch: 28 }, // Primary Keyword
  { wch: 22 }, // Primary Search Volume
  { wch: 45 }, // Secondary Keywords
  { wch: 30 }, // Secondary Search Volume
  { wch: 35 }, // Tertiary Keywords
  { wch: 45 }, // Competitor Reference Links
  { wch: 12 }, // Region
  { wch: 16 }, // Content Action
  { wch: 14 }, // Funnel Stage
  { wch: 32 }, // Product / Solution
  { wch: 24 }, // Trust Pillar
  { wch: 24 }, // ICP / Persona
  { wch: 14 }, // Status
];

function formatItemToRow(item: ContentItem) {
  const primaryKw = item.primaryKeyword || item.focusKeyword || '';
  const primaryVol = item.primarySearchVolume || item.searchVolume || 0;

  let secondaryKwText = '';
  let secondaryVolText = '';

  if (item.secondaryKeywordsWithVolume && item.secondaryKeywordsWithVolume.length > 0) {
    secondaryKwText = item.secondaryKeywordsWithVolume.map((sk) => sk.keyword).join(', ');
    secondaryVolText = item.secondaryKeywordsWithVolume.map((sk) => sk.searchVolume).join(', ');
  } else if (item.secondaryKeywords && item.secondaryKeywords.length > 0) {
    secondaryKwText = item.secondaryKeywords.join(', ');
    secondaryVolText = '';
  }

  const tertiaryKw = item.tertiaryKeywords && item.tertiaryKeywords.length > 0
    ? item.tertiaryKeywords.join(', ')
    : '';

  const competitorLinks = item.competitorReferenceLinks && item.competitorReferenceLinks.length > 0
    ? item.competitorReferenceLinks.slice(0, 3).join(' | ')
    : '';

  return {
    'Content Type': item.contentType,
    'Topic / Content Title': item.topic,
    'Primary Keyword': primaryKw,
    'Primary Search Volume': primaryVol,
    'Secondary Keywords': secondaryKwText,
    'Secondary Search Volume': secondaryVolText,
    'Tertiary Keywords': tertiaryKw,
    'Competitor Reference Links': competitorLinks,
    'Region': item.region,
    'Content Action': item.contentAction,
    'Funnel Stage': item.funnelStage || '',
    'Product / Solution': item.productMapping,
    'Trust Pillar': getTrustPillarForItem(item),
    'ICP / Persona': item.icpPersona || '',
    'Status': item.status,
  };
}

/**
 * Tab-specific Excel export for mFilterIt Content Intelligence.
 * When "All Content" is selected, exports one Excel file with 4 separate sheets:
 * Website Blog, SEO - Guest Post, Infographic, Glossary.
 * When an individual tab is selected, exports 1 sheet for that specific content type.
 */
export function exportMonthlyCalendarToExcel(
  monthlyData: MonthlyData,
  selectedContentType: ContentTypeFilter = 'All Content'
): ExportResult {
  const cleanSelectedType = typeof selectedContentType === 'string' && selectedContentType.trim() !== ''
    ? (selectedContentType as ContentTypeFilter)
    : 'All Content';

  const monthKeyPrefix = monthlyData.monthKey || `${monthlyData.year}-${monthlyData.month < 10 ? '0' : ''}${monthlyData.month}`;
  const safeMonth = monthlyData.monthLabel.replace(/[\s/\\?%*:|"<>]+/g, '_');

  // --- CASE 1: ALL CONTENT (4 Separate Sheets in One Excel File) ---
  if (cleanSelectedType === 'All Content') {
    const contentTypes: ContentType[] = [
      'Website Blog',
      'SEO / Guest Post',
      'Infographic',
      'Glossary',
    ];

    const monthItems = monthlyData.items.filter(
      (item) => !item.date || item.date.startsWith(monthKeyPrefix)
    );

    if (monthItems.length === 0) {
      return {
        success: false,
        message: `No content planned for All Content in ${monthlyData.monthLabel} to export.`,
        rowCount: 0,
      };
    }

    const wb = XLSX.utils.book_new();
    let totalExported = 0;

    contentTypes.forEach((cType) => {
      const typeItems = monthItems.filter(
        (item) => (item.contentType || '').trim().toLowerCase() === cType.trim().toLowerCase()
      );
      totalExported += typeItems.length;

      const rows = typeItems.map(formatItemToRow);
      const ws = XLSX.utils.json_to_sheet(rows);
      ws['!cols'] = columnWidths;

      let sheetName = cType.replace(/\//g, '-');
      if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);

      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });

    const filename = `mFilterIt_All_Content_Calendar_${safeMonth}.xlsx`;
    XLSX.writeFile(wb, filename);

    return {
      success: true,
      message: `Successfully exported ${totalExported} records across 4 sheets for All Content (${monthlyData.monthLabel}).`,
      filename,
      rowCount: totalExported,
    };
  }

  // --- CASE 2: INDIVIDUAL TAB (Single Sheet Export) ---
  const filteredContent: ContentItem[] = monthlyData.items.filter((item) => {
    if (item.date && !item.date.startsWith(monthKeyPrefix)) {
      return false;
    }
    const itemType = (item.contentType || '').trim().toLowerCase();
    const targetType = cleanSelectedType.trim().toLowerCase();
    return itemType === targetType;
  });

  if (filteredContent.length === 0) {
    return {
      success: false,
      message: `No content planned for ${cleanSelectedType} in ${monthlyData.monthLabel} to export.`,
      rowCount: 0,
    };
  }

  const exportRows = filteredContent.map(formatItemToRow);
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(exportRows);
  ws['!cols'] = columnWidths;

  let sheetName = cleanSelectedType.replace(/\//g, '-');
  if (sheetName.length > 31) sheetName = sheetName.substring(0, 31);
  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  let typeSlug = '';
  if (cleanSelectedType === 'SEO / Guest Post') {
    typeSlug = 'SEO_Guest_Post';
  } else {
    typeSlug = cleanSelectedType.replace(/[\s/\\?%*:|"<>]+/g, '_');
  }

  const filename = `mFilterIt_${typeSlug}_Content_Calendar_${safeMonth}.xlsx`;
  XLSX.writeFile(wb, filename);

  return {
    success: true,
    message: `Successfully exported ${filteredContent.length} ${filteredContent.length === 1 ? 'record' : 'records'} for ${cleanSelectedType} (${monthlyData.monthLabel}).`,
    filename,
    rowCount: filteredContent.length,
  };
}

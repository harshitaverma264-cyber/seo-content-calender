import { TrustPillar, ContentItem, mFilterItSolution } from '../types/seo';

export function getTrustPillarForItem(item: {
  trustPillar?: TrustPillar;
  productMapping?: mFilterItSolution;
  topic?: string;
  focusKeyword?: string;
  primaryKeyword?: string;
}): TrustPillar {
  if (item.trustPillar) {
    return item.trustPillar;
  }

  const text = `${item.topic || ''} ${item.focusKeyword || ''} ${item.primaryKeyword || ''}`.toLowerCase();

  // Financial Trust checks
  if (
    text.includes('mule') ||
    text.includes('bank') ||
    text.includes('financial') ||
    text.includes('transaction laundering') ||
    text.includes('account behaviour') ||
    text.includes('price scraping') ||
    text.includes('margin drain') ||
    text.includes('margin protection') ||
    text.includes('map violation') ||
    text.includes('map pricing') ||
    text.includes('pricing intelligence')
  ) {
    return 'Financial Trust';
  }

  // Brand Trust checks (including brand bidding, brand infringement, brand reputation)
  if (
    item.productMapping === 'Brand Protection' ||
    item.productMapping === 'Brand Safety' ||
    text.includes('brand bidding') ||
    text.includes('brand infringement') ||
    text.includes('brand reputation') ||
    text.includes('brand hijacking') ||
    text.includes('brand protection') ||
    text.includes('brand safety') ||
    text.includes('brand suitability') ||
    text.includes('phishing') ||
    text.includes('counterfeit') ||
    text.includes('impersonation') ||
    text.includes('trademark') ||
    text.includes('domain spoofing') ||
    text.includes('fake website') ||
    text.includes('unauthorized reseller')
  ) {
    return 'Brand Trust';
  }

  // Default to Media Trust
  return 'Media Trust';
}

export interface TrustPillarInfo {
  id: TrustPillar;
  label: string;
  description: string;
  colorClass: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
}

export const ALL_TRUST_PILLARS: TrustPillarInfo[] = [
  {
    id: 'Media Trust',
    label: 'Media Trust',
    description: 'Ad Fraud, PPC, CTV, Bot Farms, Programmatic & Digital Shelf',
    colorClass: '#530093',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-[#530093]',
    badgeBorder: 'border-purple-200',
  },
  {
    id: 'Brand Trust',
    label: 'Brand Trust',
    description: 'Brand Bidding, Brand Infringement, Brand Reputation, Anti-Phishing & Counterfeit',
    colorClass: '#059669',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800',
    badgeBorder: 'border-emerald-200',
  },
  {
    id: 'Financial Trust',
    label: 'Financial Trust',
    description: 'Mule Accounts, Banking Fraud & Transaction Laundering',
    colorClass: '#d97706',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800',
    badgeBorder: 'border-amber-200',
  },
];

import React, { useState } from 'react';
import { Globe, Upload, FileSpreadsheet, CheckCircle2, TrendingUp, AlertCircle } from 'lucide-react';
import { ContentItem, Region } from '../types/seo';

interface RegionalOpportunitiesProps {
  items: ContentItem[];
  onSelectItem: (item: ContentItem) => void;
}

const REGIONAL_THEMES: Record<
  Region,
  {
    title: string;
    description: string;
    primaryMarketFocus: string;
    keyDriver: string;
    sampleRankTrackerStatus: string;
  }
> = {
  INDIA: {
    title: 'India AdTech & Regulatory Market',
    description: 'High mobile app volume, rapid quick-commerce expansion, festive peak campaigns, BFSI advertising compliance scrutiny.',
    primaryMarketFocus: 'App Install Fraud, Quick-Commerce Digital Shelf, ASCI/RBI Creative Compliance',
    keyDriver: 'App install attribution discrepancies and CPI fraud in tier-1/tier-2 performance campaigns.',
    sampleRankTrackerStatus: 'Weekly Sheet: Ready for import (Positions 4–20 tracking enabled)',
  },
  USA: {
    title: 'North America Enterprise Market',
    description: 'Enterprise procurement cycles, Connected TV (CTV/OTT) ad verification, Amazon MAP violation monitoring, and annual MarTech stack consolidation.',
    primaryMarketFocus: 'Enterprise Ad Fraud Software Evaluation, Amazon MAP Enforcement, CTV Invalid Traffic',
    keyDriver: 'Procurement RFPs and high-budget performance marketing invalid traffic mitigation.',
    sampleRankTrackerStatus: 'Weekly Sheet: Ready for import (High commercial CPC tracking)',
  },
  MENA: {
    title: 'Middle East & North Africa (GCC)',
    description: 'High average order values in UAE & Saudi Arabia, White Friday & Ramadan shopping surges, rapid growth of affiliate performance networks.',
    primaryMarketFocus: 'Affiliate Cookie Stuffing, High-Value Retail Ad Waste, Ramadan Campaign Audits',
    keyDriver: 'GCC retail brand ad spend protection and local enterprise presence in Dubai.',
    sampleRankTrackerStatus: 'Weekly Sheet: Ready for import (GCC regional query tracker)',
  },
  OVERALL: {
    title: 'Global & Foundational Topical Authority',
    description: 'Universal industry definitions, GIVT vs SIVT standards, cross-border programmatic ad fraud benchmarks, and educational search intent.',
    primaryMarketFocus: 'Definitive Guides, Technical Attribution Protocols, Glossary Definitions',
    keyDriver: 'Topical authority clusters and organic backlink acquisition.',
    sampleRankTrackerStatus: 'Overall Keywords: Ready for import (Global search queries)',
  },
};

export const RegionalOpportunitiesSection: React.FC<RegionalOpportunitiesProps> = ({
  items,
  onSelectItem,
}) => {
  const [selectedRegion, setSelectedRegion] = useState<Region>('INDIA');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  const regionalItems = items.filter(
    (i) => i.region === selectedRegion || (selectedRegion === 'OVERALL' && i.region === 'OVERALL')
  );

  const regionInfo = REGIONAL_THEMES[selectedRegion];

  const handleSimulatedUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFileName(e.target.files[0].name);
      setTimeout(() => {
        setShowUploadModal(false);
      }, 1200);
    }
  };

  return (
    <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-neutral-200 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#530093]" />
            <h2 className="text-base font-bold text-neutral-900">
              Regional Content Opportunities & Weekly Ranking Data Architecture
            </h2>
          </div>
          <p className="text-xs text-neutral-500">
            Keyword intent and commercial priorities differ significantly across India, USA, and MENA. Strategies must be region-specific.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#530093] bg-[#530093]/10 hover:bg-[#530093]/20 rounded-md border border-[#530093]/30 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Import Weekly Ranking Sheet</span>
        </button>
      </div>

      {/* Regional Selector Pills/Buttons */}
      <div className="flex flex-wrap gap-2">
        {(['INDIA', 'USA', 'MENA', 'OVERALL'] as Region[]).map((region) => {
          const isSelected = selectedRegion === region;
          const count = items.filter((i) => i.region === region).length;

          return (
            <button
              key={region}
              onClick={() => setSelectedRegion(region)}
              className={`px-3.5 py-2 text-xs font-semibold rounded-md border transition-all flex items-center gap-2 cursor-pointer ${
                isSelected
                  ? 'bg-[#530093] text-white border-[#530093] shadow-xs'
                  : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
              }`}
            >
              <span>{region}</span>
              <span
                className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-neutral-200 text-neutral-700'
                }`}
              >
                {count} items
              </span>
            </button>
          );
        })}
      </div>

      {/* Regional Insights Card */}
      <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
          <div>
            <h3 className="text-sm font-bold text-neutral-900">{regionInfo.title}</h3>
            <p className="text-xs text-neutral-600 mt-0.5">{regionInfo.description}</p>
          </div>

          <div className="text-xs bg-white px-3 py-2 rounded border border-neutral-200 shrink-0">
            <span className="text-neutral-400 text-[10px] uppercase font-bold block">Regional Driver</span>
            <span className="font-semibold text-neutral-800">{regionInfo.keyDriver}</span>
          </div>
        </div>

        {/* Content Planned for this Region */}
        <div className="space-y-2">
          <div className="text-xs font-semibold text-neutral-800 flex items-center justify-between">
            <span>Planned Regional Content Assets:</span>
            <span className="text-neutral-500 font-mono text-[11px]">{regionalItems.length} opportunities</span>
          </div>

          {regionalItems.length === 0 ? (
            <div className="py-6 text-center text-xs text-neutral-400">
              No specific assets earmarked strictly for {selectedRegion} in this month.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {regionalItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectItem(item)}
                  className="bg-white p-3 rounded border border-neutral-200 hover:border-[#530093] transition-colors cursor-pointer group"
                >
                  <div className="flex items-center justify-between text-[11px] text-neutral-500 mb-1">
                    <span className="font-mono text-neutral-600">{item.contentType}</span>
                    <span className="font-semibold text-[#530093]">{item.funnelStage}</span>
                  </div>
                  <div className="text-xs font-bold text-neutral-900 group-hover:text-[#530093] transition-colors line-clamp-1">
                    {item.topic}
                  </div>
                  <div className="mt-1.5 flex items-center justify-between text-[11px] text-neutral-500">
                    <span className="font-mono text-neutral-700 bg-neutral-100 px-1 py-0.5 rounded text-[10.5px]">
                      {item.focusKeyword}
                    </span>
                    <span className="font-semibold text-neutral-700">Priority: {item.priority}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Ranking Sheet Integration Status */}
        <div className="bg-white p-3 rounded border border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-semibold text-neutral-800">Regional Dataset Status: </span>
              <span className="text-neutral-600">
                {uploadedFileName ? (
                  <strong className="text-emerald-700">Imported: {uploadedFileName}</strong>
                ) : (
                  regionInfo.sampleRankTrackerStatus
                )}
              </span>
            </div>
          </div>
          <div className="text-[11px] text-neutral-500">
            Awaiting direct weekly rank-tracker CSV pipeline
          </div>
        </div>

      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-5 space-y-4 border border-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                <Upload className="w-4 h-4 text-[#530093]" />
                Ingest Weekly Live Ranking Workbook (.xlsx)
              </h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-neutral-400 hover:text-neutral-700 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-neutral-600">
              <p>
                The mFilterIt SEO system ingests ONE weekly ranking workbook containing three regional tabs (<strong>India Live Rankings</strong>, <strong>USA Live Rankings</strong>, and <strong>MENA Live Rankings</strong>) to track:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-neutral-700">
                <li>Striking distance keywords (positions 11–20)</li>
                <li>Declining keywords requiring REVAMP or EXPAND actions</li>
                <li>Rising keywords with positive momentum (+X positions)</li>
                <li>Newly ranking keywords entering the SERPs</li>
              </ul>

              <div className="border-2 border-dashed border-neutral-300 rounded-lg p-6 text-center hover:border-[#530093] transition-colors cursor-pointer bg-neutral-50">
                <FileSpreadsheet className="w-8 h-8 text-[#530093] mx-auto mb-2" />
                <label className="cursor-pointer">
                  <span className="font-semibold text-[#530093] hover:underline">
                    Select Live Ranking Workbook (.xlsx)
                  </span>
                  <input
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleSimulatedUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Expected tabs: India Live Rankings, USA Live Rankings, MENA Live Rankings
                </p>
              </div>

              {uploadedFileName && (
                <div className="p-2.5 bg-emerald-50 text-emerald-800 rounded border border-emerald-200 flex items-center gap-2 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Successfully processed {uploadedFileName}</span>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-neutral-200 flex justify-end">
              <button
                onClick={() => setShowUploadModal(false)}
                className="px-4 py-1.5 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-md cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

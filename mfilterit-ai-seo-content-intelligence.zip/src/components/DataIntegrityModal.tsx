import React from 'react';
import { Database, CheckCircle2, Clock, AlertTriangle, ShieldCheck, X } from 'lucide-react';
import { DATA_CONNECTORS } from '../data/solutionsAndPersonas';

interface DataIntegrityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataIntegrityModal: React.FC<DataIntegrityModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-6 space-y-5 border border-neutral-200">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-[#530093]" />
            <div>
              <h2 className="text-base font-bold text-neutral-900">
                Data Connectors & System Integrity Architecture
              </h2>
              <p className="text-xs text-neutral-500">
                Strict data integrity policy: No fabricated performance or vanity numbers.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-700 p-1 rounded-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Data Tier Classifications */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="bg-neutral-50 p-2.5 rounded border border-neutral-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 block">
              Tier 1
            </span>
            <span className="font-bold text-neutral-900">REAL DATA</span>
            <p className="text-[11px] text-neutral-500 mt-0.5">Live GSC/GA4/crawler (when linked)</p>
          </div>

          <div className="bg-neutral-50 p-2.5 rounded border border-neutral-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#530093] block">
              Tier 2
            </span>
            <span className="font-bold text-[#530093]">AI ANALYSIS</span>
            <p className="text-[11px] text-neutral-500 mt-0.5">Intent, persona & cannibalization logic</p>
          </div>

          <div className="bg-neutral-50 p-2.5 rounded border border-neutral-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block">
              Tier 3
            </span>
            <span className="font-bold text-emerald-800">RECOMMENDATION</span>
            <p className="text-[11px] text-neutral-500 mt-0.5">Action proposals (Revamp/Expand/New)</p>
          </div>

          <div className="bg-neutral-50 p-2.5 rounded border border-neutral-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block">
              Tier 4
            </span>
            <span className="font-bold text-amber-800">DEMO ARCHITECTURE</span>
            <p className="text-[11px] text-neutral-500 mt-0.5">Curated initial seed calendar</p>
          </div>
        </div>

        {/* Connectors Table */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
            Connected Pipelines Status
          </h3>

          <div className="divide-y divide-neutral-200 border border-neutral-200 rounded-lg overflow-hidden">
            {DATA_CONNECTORS.map((connector) => {
              const isReady = connector.status === 'Ready for Upload';
              const isConnected = connector.status === 'Connected';

              return (
                <div key={connector.id} className="p-3 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div>
                    <div className="font-bold text-neutral-900">{connector.name}</div>
                    <div className="text-neutral-500 text-[11.5px] mt-0.5">{connector.description}</div>
                  </div>

                  <div className="flex sm:flex-col items-start sm:items-end justify-between gap-1 shrink-0">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold ${
                        isConnected
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : isReady
                          ? 'bg-[#530093]/10 text-[#530093] border border-[#530093]/30'
                          : 'bg-neutral-100 text-neutral-600 border border-neutral-300'
                      }`}
                    >
                      {isConnected ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Clock className="w-3 h-3 text-neutral-400" />
                      )}
                      {connector.status}
                    </span>
                    <span className="text-[10.5px] text-neutral-400 font-mono">
                      {connector.dataNote}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footnote */}
        <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-md text-xs text-amber-900 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-[11.5px] leading-relaxed">
            <strong>Enterprise Data Guarantee:</strong> When Search Console or GA4 is disconnected, the interface explicitly displays "Awaiting connection" rather than generating fabricated traffic or ranking figures.
          </p>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#530093] hover:bg-[#430077] rounded-md transition-colors cursor-pointer"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};

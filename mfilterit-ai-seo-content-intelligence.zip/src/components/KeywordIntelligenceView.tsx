import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
  Minus,
  Sparkles,
  Target,
  PlusCircle,
  ExternalLink,
  ShieldAlert,
  Download,
  Info,
  Layers,
  ChevronRight,
  Globe
} from 'lucide-react';
import {
  CombinedKeywordOpportunity,
  KeywordOpportunityCategory,
  RankingMovement,
} from '../types/keywordIntelligence';
import { Region, ContentItem } from '../types/seo';
import * as XLSX from 'xlsx';

interface KeywordIntelligenceViewProps {
  opportunities: CombinedKeywordOpportunity[];
  selectedRegion: 'ALL' | 'INDIA' | 'USA' | 'MENA';
  onSelectRegion: (reg: 'ALL' | 'INDIA' | 'USA' | 'MENA') => void;
  onSendToCalendar: (opp: CombinedKeywordOpportunity) => void;
  isDemoActive: boolean;
  onOpenGoogleSerp?: (keyword: string) => void;
}

const CATEGORY_TABS: { id: 'ALL' | KeywordOpportunityCategory; label: string; countKey?: string }[] = [
  { id: 'ALL', label: 'All Opportunities' },
  { id: 'STRIKING DISTANCE', label: 'Striking Distance (11–20)' },
  { id: 'QUICK WINS', label: 'Quick Wins (4–10)' },
  { id: 'DECLINING', label: 'Declining (Needs Revamp)' },
  { id: 'RISING', label: 'Rising Momentum' },
  { id: 'NEWLY RANKING', label: 'Newly Ranking' },
  { id: 'COMMERCIAL OPPORTUNITIES', label: 'Commercial BOFU' },
  { id: 'CONTENT GAPS', label: 'Master Content Gaps' },
];

export const KeywordIntelligenceView: React.FC<KeywordIntelligenceViewProps> = ({
  opportunities,
  selectedRegion,
  onSelectRegion,
  onSendToCalendar,
  isDemoActive,
  onOpenGoogleSerp,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim() && onOpenGoogleSerp) {
      onOpenGoogleSerp(searchTerm.trim());
    }
  };
  const [activeCategory, setActiveCategory] = useState<'ALL' | KeywordOpportunityCategory>('ALL');
  const [filterAction, setFilterAction] = useState<string>('ALL');
  const [filterFunnel, setFilterFunnel] = useState<string>('ALL');
  const [sortField, setSortField] = useState<'position' | 'volume' | 'change' | 'keyword'>('position');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  // Filtered & Sorted opportunities
  const filteredOpportunities = useMemo(() => {
    return opportunities
      .filter((opp) => {
        // Region filter
        if (selectedRegion !== 'ALL' && opp.region !== selectedRegion) {
          return false;
        }

        // Category filter
        if (activeCategory !== 'ALL' && opp.category !== activeCategory) {
          return false;
        }

        // Action filter
        if (filterAction !== 'ALL' && opp.recommendedAction !== filterAction) {
          return false;
        }

        // Funnel filter
        if (filterFunnel !== 'ALL' && opp.funnelStage !== filterFunnel) {
          return false;
        }

        // Search text
        if (searchTerm.trim() !== '') {
          const q = searchTerm.toLowerCase();
          const matchKw = opp.keyword.toLowerCase().includes(q);
          const matchSol = opp.productMapping.toLowerCase().includes(q);
          const matchPersona = opp.icpPersona.toLowerCase().includes(q);
          if (!matchKw && !matchSol && !matchPersona) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortField === 'position') {
          const posA = a.currentPosition ?? 999;
          const posB = b.currentPosition ?? 999;
          return sortAsc ? posA - posB : posB - posA;
        }
        if (sortField === 'volume') {
          const volA = a.searchVolume ?? 0;
          const volB = b.searchVolume ?? 0;
          return sortAsc ? volA - volB : volB - volA;
        }
        if (sortField === 'change') {
          const chgA = a.positionChange ?? -999;
          const chgB = b.positionChange ?? -999;
          return sortAsc ? chgA - chgB : chgB - chgA;
        }
        if (sortField === 'keyword') {
          return sortAsc ? a.keyword.localeCompare(b.keyword) : b.keyword.localeCompare(a.keyword);
        }
        return 0;
      });
  }, [
    opportunities,
    selectedRegion,
    activeCategory,
    filterAction,
    filterFunnel,
    searchTerm,
    sortField,
    sortAsc,
  ]);

  // KPI calculations for currently selected region
  const regionalPool = useMemo(() => {
    return selectedRegion === 'ALL'
      ? opportunities
      : opportunities.filter((o) => o.region === selectedRegion);
  }, [opportunities, selectedRegion]);

  const strikingDistanceCount = regionalPool.filter((o) => (o.currentPosition ?? 0) >= 11 && (o.currentPosition ?? 0) <= 20).length;
  const page1Count = regionalPool.filter((o) => (o.currentPosition ?? 0) >= 1 && (o.currentPosition ?? 0) <= 10).length;
  const decliningCount = regionalPool.filter((o) => o.category === 'DECLINING').length;
  const contentGapCount = regionalPool.filter((o) => o.category === 'CONTENT GAPS').length;
  const commercialCount = regionalPool.filter((o) => o.category === 'COMMERCIAL OPPORTUNITIES' || o.leadPotential === 'High').length;

  const handleExportOpportunities = () => {
    const exportRows = filteredOpportunities.map((o) => ({
      Region: o.region,
      Keyword: o.keyword,
      'Opportunity Category': o.category,
      'Current Position': o.currentPosition || 'Not Ranking',
      'Previous Position': o.previousPosition || 'Historical comparison unavailable',
      'Position Change': o.positionChange !== undefined ? o.positionChange : 'N/A',
      Movement: o.movement || 'N/A',
      'Search Volume': o.searchVolume || 'N/A',
      'Search Intent': o.searchIntent,
      'Funnel Stage': o.funnelStage,
      'mFilterIt Solution': o.productMapping,
      'Target Persona': o.icpPersona,
      'Lead Potential': o.leadPotential,
      'Conversion Potential': o.conversionPotential,
      'Recommended Action': o.recommendedAction,
      'Action Rationale': o.actionRationale,
      'Existing URL': o.existingUrl || 'None',
      'Cannibalization Risk': o.cannibalizationRisk,
    }));

    const ws = XLSX.utils.json_to_sheet(exportRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Keyword Opportunities');
    XLSX.writeFile(wb, `mFilterIt_Keyword_Intelligence_${selectedRegion}.xlsx`);
  };

  const getMovementBadge = (movement?: RankingMovement, change?: number) => {
    if (!movement || movement === 'STABLE') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono text-neutral-500">
          <Minus className="w-3 h-3 text-neutral-400" /> Stable
        </span>
      );
    }
    if (movement === 'IMPROVING') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
          <TrendingUp className="w-3 h-3 text-emerald-600" /> +{change}
        </span>
      );
    }
    if (movement === 'DECLINING') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-red-700 bg-red-50 px-1.5 py-0.5 rounded">
          <TrendingDown className="w-3 h-3 text-red-600" /> {change}
        </span>
      );
    }
    if (movement === 'NEWLY RANKING') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-[#530093] bg-[#530093]/10 px-1.5 py-0.5 rounded">
          <Sparkles className="w-3 h-3 text-[#530093]" /> New
        </span>
      );
    }
    return (
      <span className="text-[11px] font-mono text-neutral-400">Lost</span>
    );
  };

  return (
    <div className="space-y-6">
      
      {/* Regional Selector Bar */}
      <div className="bg-white border border-neutral-200 rounded-lg p-3 flex items-center justify-end">
        {/* Region Buttons */}
        <div className="flex items-center gap-1.5 bg-neutral-100 p-1 rounded-lg border border-neutral-200">
          {(['ALL', 'INDIA', 'USA', 'MENA'] as const).map((reg) => {
            const isSelected = selectedRegion === reg;
            const count = reg === 'ALL'
              ? opportunities.length
              : opportunities.filter((o) => o.region === reg).length;

            return (
              <button
                key={reg}
                onClick={() => onSelectRegion(reg)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-[#530093] text-white shadow-xs'
                    : 'text-neutral-700 hover:text-neutral-900 hover:bg-neutral-200/60'
                }`}
              >
                <span>{reg === 'ALL' ? 'All Regions' : reg}</span>
                <span
                  className={`text-[10px] font-mono px-1 py-0.2 rounded ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-neutral-200 text-neutral-700'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>



      {/* Main Intelligence Table Container */}
      <div className="bg-white border border-neutral-200 rounded-lg shadow-xs overflow-hidden">
        
        {/* Category Filter Tabs */}
        <div className="border-b border-neutral-200 bg-neutral-50/60 px-4 py-2.5 overflow-x-auto">
          <div className="flex items-center gap-1.5 scrollbar-none">
            {CATEGORY_TABS.map((tab) => {
              const isActive = activeCategory === tab.id;
              const count =
                tab.id === 'ALL'
                  ? regionalPool.length
                  : regionalPool.filter((o) => o.category === tab.id).length;

              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategory(tab.id)}
                  className={`whitespace-nowrap px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? 'bg-[#530093] text-white shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/50'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`text-[10px] font-mono px-1 py-0.2 rounded ${
                      isActive ? 'bg-white/20 text-white' : 'bg-neutral-200 text-neutral-700'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="p-4 border-b border-neutral-200 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-md flex items-center">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#530093] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search any keyword on Google SERP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-28 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#530093]"
              />
              <button
                type="submit"
                onClick={handleSearchSubmit}
                disabled={!searchTerm.trim()}
                className="absolute right-1 top-1/2 -translate-y-1/2 px-2.5 py-1 text-[10px] font-bold text-neutral-900 bg-[#FFCC29] hover:bg-[#ebd505] rounded transition-colors disabled:opacity-40 cursor-pointer flex items-center gap-1"
                title="Search Google SERP results & top 3 blogs"
              >
                <Globe className="w-3 h-3 text-neutral-900" />
                <span>Search Google</span>
              </button>
            </div>
          </form>

          <div className="flex items-center flex-wrap gap-2 text-xs">
            <select
              value={filterAction}
              onChange={(e) => setFilterAction(e.target.value)}
              className="px-2.5 py-1.5 bg-neutral-50 border border-neutral-300 rounded-md text-neutral-700 text-xs"
            >
              <option value="ALL">All Actions</option>
              <option value="NEW">Action: NEW</option>
              <option value="REVAMP">Action: REVAMP</option>
              <option value="EXPAND">Action: EXPAND</option>
              <option value="SUPPORTING">Action: SUPPORTING</option>
            </select>

            <select
              value={filterFunnel}
              onChange={(e) => setFilterFunnel(e.target.value)}
              className="px-2.5 py-1.5 bg-neutral-50 border border-neutral-300 rounded-md text-neutral-700 text-xs"
            >
              <option value="ALL">All Funnels</option>
              <option value="BOFU">BOFU</option>
              <option value="MOFU">MOFU</option>
              <option value="TOFU">TOFU</option>
            </select>

            <button
              onClick={handleExportOpportunities}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 rounded border border-neutral-300 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#530093]" />
              <span>Export Intel</span>
            </button>
          </div>
        </div>

        {/* Data Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-neutral-50 text-neutral-600 font-semibold border-b border-neutral-200 uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3.5 min-w-[200px]">Keyword</th>
                <th className="py-3 px-2.5 whitespace-nowrap">Region</th>
                <th className="py-3 px-3 whitespace-nowrap">Previous Rank</th>
                <th className="py-3 px-3 whitespace-nowrap">Current Rank</th>
                <th className="py-3 px-3 whitespace-nowrap">Movement</th>
                <th className="py-3 px-3 whitespace-nowrap text-right">Search Volume</th>
                <th className="py-3 px-3 whitespace-nowrap">Intent / Funnel</th>
                <th className="py-3 px-3.5 min-w-[150px] normal-case">mFilterIt Solution</th>
                <th className="py-3 px-3 whitespace-nowrap">Source</th>
                <th className="py-3 px-3 whitespace-nowrap">Last Updated</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-neutral-200 bg-white">
              {filteredOpportunities.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-neutral-500">
                    <p className="font-semibold text-neutral-800">No keyword opportunities in this view.</p>
                    <p className="text-xs text-neutral-400 mt-1">
                      Upload master keyword files or click "Load Demo Dataset" above to explore analysis.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredOpportunities.map((opp) => {
                  const isStriking = (opp.currentPosition ?? 0) >= 11 && (opp.currentPosition ?? 0) <= 20;

                  return (
                    <tr
                      key={opp.id}
                      className="hover:bg-neutral-50/80 transition-colors group"
                    >
                      {/* Keyword */}
                      <td className="py-3 px-3.5">
                        <div className="font-semibold text-neutral-900 font-mono text-[12px] group-hover:text-[#530093]">
                          {opp.keyword}
                        </div>
                        {opp.existingUrl && (
                          <a
                            href={opp.existingUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[11px] text-neutral-500 hover:text-[#530093] hover:underline font-mono truncate max-w-xs block mt-0.5"
                          >
                            {opp.existingUrl}
                          </a>
                        )}
                      </td>

                      {/* Region */}
                      <td className="py-3 px-2.5 whitespace-nowrap font-medium text-neutral-700">
                        {opp.region}
                      </td>

                      {/* Previous Rank */}
                      <td className="py-3 px-3 whitespace-nowrap font-mono tabular-nums text-neutral-600">
                        {opp.previousPosition ? `#${opp.previousPosition}` : '—'}
                      </td>

                      {/* Current Rank */}
                      <td className="py-3 px-3 whitespace-nowrap font-mono tabular-nums">
                        {opp.currentPosition ? (
                          <span
                            className={`font-bold px-2 py-0.5 rounded text-xs ${
                              opp.currentPosition <= 3
                                ? 'bg-emerald-100 text-emerald-900 font-bold'
                                : opp.currentPosition <= 10
                                ? 'bg-emerald-50 text-emerald-800'
                                : isStriking
                                ? 'bg-[#FFCC29]/40 text-neutral-900 font-bold'
                                : 'bg-neutral-100 text-neutral-700'
                            }`}
                          >
                            #{opp.currentPosition}
                          </span>
                        ) : (
                          <span className="text-neutral-400 italic">—</span>
                        )}
                      </td>

                      {/* Movement */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        {getMovementBadge(opp.movement, opp.positionChange)}
                      </td>

                      {/* Search Volume */}
                      <td className="py-3 px-3 whitespace-nowrap text-right font-mono tabular-nums text-neutral-700">
                        {opp.searchVolume ? opp.searchVolume.toLocaleString() : '—'}
                      </td>

                      {/* Intent / Funnel */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-[11px]">
                          <span
                            className={`font-bold ${
                              opp.funnelStage === 'BOFU'
                                ? 'text-[#530093]'
                                : 'text-neutral-700'
                            }`}
                          >
                            {opp.funnelStage}
                          </span>
                          <span className="text-neutral-300">·</span>
                          <span className="text-neutral-500 truncate max-w-[80px]">
                            {opp.searchIntent === 'Commercial Investigation' ? 'Commercial' : opp.searchIntent}
                          </span>
                        </div>
                      </td>

                      {/* mFilterIt Solution */}
                      <td className="py-3 px-3.5 text-neutral-800 font-medium truncate max-w-[150px]" title={opp.productMapping}>
                        {opp.productMapping}
                      </td>

                      {/* Source */}
                      <td className="py-3 px-3 whitespace-nowrap text-neutral-600 text-[11px]">
                        {opp.source || 'Weekly Live Ranking Workbook'}
                      </td>

                      {/* Last Updated */}
                      <td className="py-3 px-3 whitespace-nowrap text-neutral-500 font-mono text-[11px]">
                        {opp.lastUpdated || opp.serpsCheckDate || 'Oct 14, 2026'}
                      </td>

                      {/* Send to Calendar Button */}
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <button
                          onClick={() => onSendToCalendar(opp)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-[#530093] bg-[#530093]/10 hover:bg-[#530093] hover:text-white rounded transition-colors cursor-pointer"
                          title="Schedule this opportunity into the current Monthly Content Calendar"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>+ Calendar</span>
                        </button>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
};

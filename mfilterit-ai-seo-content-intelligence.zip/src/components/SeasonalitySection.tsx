import React, { useState } from 'react';
import { Calendar, Clock, Flame, ShieldAlert, Sparkles, Tag, PlusCircle, Check, AlertTriangle, Layers, Target, DollarSign, ArrowUpRight } from 'lucide-react';
import { REGIONAL_SEASONALITY_EVENTS, SeasonalEvent, SeasonalTopicSuggestion } from '../data/seasonalityEvents';
import { Region } from '../types/seo';

interface SeasonalitySectionProps {
  onOpenGoogleSerp?: (kw: string, region?: 'INDIA' | 'USA' | 'MENA' | 'GLOBAL') => void;
  onScheduleSeasonalTopic?: (topic: SeasonalTopicSuggestion, event: SeasonalEvent) => void;
}

export const SeasonalitySection: React.FC<SeasonalitySectionProps> = ({
  onOpenGoogleSerp,
  onScheduleSeasonalTopic
}) => {
  const [selectedRegion, setSelectedRegion] = useState<Region | 'ALL'>('INDIA');
  const [scheduledIds, setScheduledIds] = useState<Set<string>>(new Set());

  const filteredEvents = REGIONAL_SEASONALITY_EVENTS.filter((e) =>
    selectedRegion === 'ALL' ? true : e.region === selectedRegion
  );

  const handleSchedule = (topic: SeasonalTopicSuggestion, event: SeasonalEvent, key: string) => {
    onScheduleSeasonalTopic?.(topic, event);
    setScheduledIds((prev) => new Set(prev).add(key));
  };

  return (
    <div className="bg-white border border-neutral-200 rounded-xl p-6 space-y-6 shadow-xs">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-4 border-b border-neutral-200 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-purple-50 text-[#530093] border border-purple-200">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-neutral-900">
                Regional Seasonality & Event Ramp-Up Planning
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                Align SEO and content publishing 4–8 weeks before peak shopping, holiday, and advertising events across India, USA, and MENA.
              </p>
            </div>
          </div>
        </div>

        {/* Region Filter Tabs */}
        <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-lg text-xs self-start md:self-auto border border-neutral-200/80">
          {(['ALL', 'INDIA', 'USA', 'MENA'] as const).map((r) => {
            const isActive = selectedRegion === r;
            return (
              <button
                key={r}
                onClick={() => setSelectedRegion(r)}
                className={`px-3 py-1.5 rounded-md font-bold cursor-pointer transition-all ${
                  isActive
                    ? 'bg-[#530093] text-white shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200/60'
                }`}
              >
                {r === 'ALL' ? '🌐 All Regions' : r === 'INDIA' ? '🇮🇳 India' : r === 'USA' ? '🇺🇸 USA' : '🇦🇪 MENA'}
              </button>
            );
          })}
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-purple-50/50 border border-purple-200/60 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wide">Upcoming Peak Events</span>
            <div className="text-2xl font-black text-[#530093] mt-0.5">{filteredEvents.length} Events</div>
            <div className="text-[11px] text-neutral-500 mt-0.5">India, USA & MENA</div>
          </div>
          <Flame className="w-8 h-8 text-[#530093]/20" />
        </div>

        <div className="p-4 bg-amber-50/50 border border-amber-200/60 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wide">Recommended Ramp-Up</span>
            <div className="text-2xl font-black text-amber-900 mt-0.5">4–8 Weeks</div>
            <div className="text-[11px] text-neutral-500 mt-0.5">Prior to event peak date</div>
          </div>
          <Clock className="w-8 h-8 text-amber-600/20" />
        </div>

        <div className="p-4 bg-rose-50/50 border border-rose-200/60 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wide">Ad Budget Protection</span>
            <div className="text-2xl font-black text-rose-900 mt-0.5">15%–35%</div>
            <div className="text-[11px] text-neutral-500 mt-0.5">Estimated ad waste prevented</div>
          </div>
          <DollarSign className="w-8 h-8 text-rose-600/20" />
        </div>
      </div>

      {/* Seasonal Events List */}
      <div className="space-y-6">
        {filteredEvents.map((event) => (
          <div
            key={event.id}
            className="bg-neutral-50/70 border border-neutral-200 hover:border-[#530093]/40 rounded-xl p-5 space-y-4 transition-colors"
          >
            {/* Title & Metadata Header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-neutral-200/80 pb-4">
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-800 border border-amber-300/60 shrink-0 mt-0.5">
                  <Flame className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-bold text-neutral-900">{event.eventName}</h3>
                    <span className="px-2.5 py-0.5 text-xs font-extrabold bg-purple-100 text-[#530093] border border-purple-200 rounded-md">
                      {event.eventWindow}
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-neutral-200/80 text-neutral-700 rounded">
                      {event.region}
                    </span>
                    <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded border ${
                      event.businessValue === 'Critical'
                        ? 'bg-rose-100 text-rose-800 border-rose-200'
                        : event.businessValue === 'High'
                        ? 'bg-amber-100 text-amber-800 border-amber-200'
                        : 'bg-blue-100 text-blue-800 border-blue-200'
                    }`}>
                      {event.businessValue} Business Value
                    </span>
                  </div>

                  <div className="text-xs text-neutral-500 mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                    <span className="flex items-center gap-1 font-medium text-neutral-700">
                      <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                      Peak Range: <strong className="text-neutral-900 font-semibold">{event.eventDateRange}</strong>
                    </span>
                    <span className="flex items-center gap-1 font-medium text-purple-800">
                      <Clock className="w-3.5 h-3.5 text-purple-600" />
                      Ramp-Up Start: <strong className="font-semibold">{event.rampUpStartDate} ({event.contentRampUpWeeks} Wks Prior)</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Badges */}
              <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
                <span className="px-3 py-1 text-xs font-bold bg-[#FFCC29]/30 text-neutral-900 border border-[#FFCC29] rounded-md">
                  Action: {event.recommendedAction}
                </span>
                <span className="px-2.5 py-1 text-xs font-mono font-bold bg-neutral-200 text-neutral-800 rounded-md">
                  {event.suggestedFunnel}
                </span>
              </div>
            </div>

            {/* Event Description */}
            <p className="text-xs text-neutral-700 leading-relaxed font-sans">
              {event.description}
            </p>

            {/* Strategic Impact & Budget Risk Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 bg-amber-50/80 border border-amber-200/80 rounded-lg text-xs text-amber-950 flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold text-amber-900">Strategic Impact: </strong>
                  <span>{event.strategicImportance}</span>
                </div>
              </div>

              <div className="p-3 bg-rose-50/80 border border-rose-200/80 rounded-lg text-xs text-rose-950 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold text-rose-900">Estimated Budget Risk: </strong>
                  <span>{event.estimatedBudgetRisk}</span>
                </div>
              </div>
            </div>

            {/* Target Solution & Personas */}
            <div className="flex flex-wrap items-center justify-between text-xs bg-white p-3 rounded-lg border border-neutral-200/80 gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#530093]" />
                <span className="text-neutral-500 font-medium">Primary mFilterIt Solution:</span>
                <strong className="text-neutral-900 font-bold">{event.primarySolution}</strong>
              </div>
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-purple-700" />
                <span className="text-neutral-500 font-medium">Target ICP Persona:</span>
                <strong className="text-neutral-900 font-bold">{event.targetPersona}</strong>
              </div>
            </div>

            {/* Seasonal Target Queries */}
            <div className="space-y-1.5">
              <span className="text-neutral-600 font-bold text-xs flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-[#530093]" />
                Seasonal High-Intent Target Queries (Click for Live Google SERP Grounding):
              </span>
              <div className="flex flex-wrap items-center gap-2">
                {event.featuredKeywords.map((kw, i) => (
                  <button
                    key={i}
                    onClick={() => onOpenGoogleSerp?.(kw, event.region as any)}
                    className="px-2.5 py-1 bg-white hover:bg-purple-50 text-[#530093] hover:text-[#3a0068] border border-neutral-300 hover:border-[#530093] rounded-md font-mono text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                    title={`Run live Google SERP grounding for "${kw}"`}
                  >
                    <span>{kw}</span>
                    <Sparkles className="w-3 h-3 text-[#FFCC29]" />
                  </button>
                ))}
              </div>
            </div>

            {/* Actionable Pre-Event Topic Blueprints */}
            {event.suggestedTopics && event.suggestedTopics.length > 0 && (
              <div className="pt-3 border-t border-neutral-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-neutral-900 flex items-center gap-1.5">
                    <ArrowUpRight className="w-4 h-4 text-[#530093]" />
                    Recommended Pre-Event Content Blueprints:
                  </span>
                  <span className="text-[11px] text-neutral-500 font-medium">
                    Schedule 4-8 weeks before peak
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-2.5">
                  {event.suggestedTopics.map((topic, idx) => {
                    const uniqueKey = `${event.id}-${idx}`;
                    const isScheduled = scheduledIds.has(uniqueKey);

                    return (
                      <div
                        key={uniqueKey}
                        className="bg-white p-3.5 rounded-lg border border-neutral-200 hover:border-purple-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all"
                      >
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="px-2 py-0.5 text-[10px] font-extrabold bg-purple-50 text-[#530093] border border-purple-200 rounded">
                              {topic.contentType}
                            </span>
                            <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-neutral-100 text-neutral-800 rounded">
                              {topic.funnel}
                            </span>
                            <span className="px-1.5 py-0.5 text-[10px] font-bold bg-[#FFCC29]/20 text-neutral-900 border border-[#FFCC29]/60 rounded">
                              Action: {topic.action}
                            </span>
                          </div>
                          <h4 className="text-xs font-bold text-neutral-900 leading-snug">
                            {topic.title}
                          </h4>
                          <p className="text-[11px] text-neutral-500">
                            Target Keyword: <code className="text-[#530093] font-mono font-bold">{topic.keyword}</code> — {topic.rationale}
                          </p>
                        </div>

                        <button
                          onClick={() => handleSchedule(topic, event, uniqueKey)}
                          disabled={isScheduled}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0 transition-all ${
                            isScheduled
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 cursor-default'
                              : 'bg-[#530093] hover:bg-[#3a0068] text-white shadow-2xs'
                          }`}
                        >
                          {isScheduled ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Scheduled in Calendar</span>
                            </>
                          ) : (
                            <>
                              <PlusCircle className="w-3.5 h-3.5" />
                              <span>Schedule in Calendar</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          </div>
        ))}
      </div>

    </div>
  );
};


import React, { useState, useRef } from 'react';
import {
  Database,
  Upload,
  RefreshCw,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Info,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import {
  MasterDataSourceInfo,
  LiveRankingWorkbookInfo,
  DataSourceStatus,
} from '../types/keywordIntelligence';
import {
  parseMasterKeywordFile,
  parseLiveRankingWorkbook,
} from '../utils/fileParsers';
import {
  DEMO_MASTER_KEYWORDS,
  DEMO_LIVE_RANKINGS,
} from '../data/demoKeywordData';

interface KeywordDataSourcesSectionProps {
  masterSources: Record<'INDIA' | 'USA' | 'MENA', MasterDataSourceInfo>;
  liveWorkbook: LiveRankingWorkbookInfo;
  onUpdateMasterSource: (region: 'INDIA' | 'USA' | 'MENA', source: MasterDataSourceInfo) => void;
  onUpdateLiveWorkbook: (workbook: LiveRankingWorkbookInfo) => void;
  onLoadDemoData: () => void;
  isDemoActive: boolean;
}

export const KeywordDataSourcesSection: React.FC<KeywordDataSourcesSectionProps> = ({
  masterSources,
  liveWorkbook,
  onUpdateMasterSource,
  onUpdateLiveWorkbook,
  onLoadDemoData,
  isDemoActive,
}) => {
  const [activeUploadRegion, setActiveUploadRegion] = useState<'INDIA' | 'USA' | 'MENA' | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [expandedSourceId, setExpandedSourceId] = useState<string | null>(null);

  const masterFileInputRef = useRef<HTMLInputElement>(null);
  const liveWorkbookInputRef = useRef<HTMLInputElement>(null);

  // Trigger file upload for specific master source
  const handleOpenMasterUpload = (region: 'INDIA' | 'USA' | 'MENA') => {
    setActiveUploadRegion(region);
    if (masterFileInputRef.current) {
      masterFileInputRef.current.value = '';
      masterFileInputRef.current.click();
    }
  };

  // Process master keyword file upload
  const handleMasterFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0] || !activeUploadRegion) return;
    const file = e.target.files[0];
    const region = activeUploadRegion;
    setIsProcessing(true);

    try {
      const { records, detectedColumns, validationWarnings } = await parseMasterKeywordFile(file, region);
      const now = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });

      onUpdateMasterSource(region, {
        id: `${region.toLowerCase()}-master` as any,
        region,
        name: `${region === 'INDIA' ? 'India' : region === 'USA' ? 'USA' : 'MENA'} — All Keywords`,
        fileName: file.name,
        status: validationWarnings.length > 0 && records.length === 0 ? 'DATA VALIDATION REQUIRED' : 'CONNECTED',
        lastUpdated: now,
        rowCount: records.length,
        keywordCount: records.length,
        detectedColumns,
        validationWarnings,
        records,
        isDemoData: false,
      });
    } catch (err: any) {
      onUpdateMasterSource(region, {
        ...masterSources[region],
        status: 'ERROR',
        validationWarnings: [err.message || 'Failed to process file format.'],
      });
    } finally {
      setIsProcessing(false);
      setActiveUploadRegion(null);
    }
  };

  // Process live ranking workbook upload (1 workbook, 3 tabs)
  const handleLiveWorkbookChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    setIsProcessing(true);

    try {
      const { tabs, validationWarnings } = await parseLiveRankingWorkbook(file);
      const now = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });

      const totalRows = tabs.INDIA.rowCount + tabs.USA.rowCount + tabs.MENA.rowCount;

      onUpdateLiveWorkbook({
        id: 'live-rankings-workbook',
        name: 'Live Ranking Workbook',
        fileName: file.name,
        status: totalRows > 0 ? 'CONNECTED' : 'DATA VALIDATION REQUIRED',
        lastUpdated: now,
        currentWeekLabel: `Uploaded ${now}`,
        tabs,
        validationWarnings,
        isDemoData: false,
      });
    } catch (err: any) {
      onUpdateLiveWorkbook({
        ...liveWorkbook,
        status: 'ERROR',
        validationWarnings: [err.message || 'Failed to parse live ranking workbook tabs.'],
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Refresh individual master source
  const handleRefreshMaster = (region: 'INDIA' | 'USA' | 'MENA') => {
    const existing = masterSources[region];
    if (existing.status !== 'CONNECTED' && !existing.isDemoData) {
      handleOpenMasterUpload(region);
      return;
    }
    const now = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    onUpdateMasterSource(region, {
      ...existing,
      lastUpdated: now,
    });
  };

  // Refresh live ranking workbook automatically from SharePoint API
  const handleRefreshLiveWorkbook = async () => {
    setIsProcessing(true);
    try {
      const res = await fetch('/api/live-workbook');
      if (res.ok) {
        const data = await res.json();
        onUpdateLiveWorkbook(data);
        return;
      }
    } catch (err) {
      console.warn('Failed to refresh SharePoint workbook via API:', err);
    } finally {
      setIsProcessing(false);
    }

    const now = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    onUpdateLiveWorkbook({
      ...liveWorkbook,
      lastUpdated: now,
    });
  };

  const getStatusBadge = (status: DataSourceStatus, isDemo?: boolean) => {
    if (isDemo) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-[#FFCC29]/30 text-neutral-900 border border-[#FFCC29]">
          DEMO DATA
        </span>
      );
    }
    switch (status) {
      case 'CONNECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            CONNECTED
          </span>
        );
      case 'DATA VALIDATION REQUIRED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-300">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            VALIDATION REQUIRED
          </span>
        );
      case 'ERROR':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-red-50 text-red-800 border border-red-300">
            ERROR
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-neutral-100 text-neutral-600 border border-neutral-300">
            <Clock className="w-3 h-3 text-neutral-400" />
            Awaiting connection
          </span>
        );
    }
  };

  return (
    <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-6">
      
      {/* Hidden File Inputs */}
      <input
        type="file"
        ref={masterFileInputRef}
        onChange={handleMasterFileChange}
        accept=".csv, .xlsx, .xls"
        className="hidden"
      />
      <input
        type="file"
        ref={liveWorkbookInputRef}
        onChange={handleLiveWorkbookChange}
        accept=".xlsx, .xls"
        className="hidden"
      />

      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 border-b border-neutral-200 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-[#530093]" />
            <h2 className="text-base font-bold text-neutral-900">
              Keyword Data Architecture & Source Management
            </h2>
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Manages the 4 actual data sources: 3 separate regional Master Keyword datasets + 1 weekly updated Live Ranking Workbook (3 tabs).
          </p>
        </div>

        {/* Global actions: Demo Data Loader & Refresh */}
        <div className="flex items-center flex-wrap gap-2.5">
          <button
            onClick={onLoadDemoData}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
              isDemoActive
                ? 'bg-[#FFCC29] text-neutral-900 border-[#FFCC29] shadow-xs'
                : 'bg-neutral-50 text-neutral-700 border-neutral-300 hover:bg-neutral-100'
            }`}
            title="Inspect architecture with pre-loaded demo keywords & weekly rankings"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isDemoActive ? 'Demo Data Active' : 'Load Demo Dataset'}</span>
          </button>

          <button
            onClick={handleRefreshLiveWorkbook}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-[#530093] hover:bg-[#430077] rounded-md shadow-xs transition-colors cursor-pointer"
            title="Refresh live rankings automatically from SharePoint"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#FFCC29]" />
            <span>Sync SharePoint Workbook</span>
          </button>
        </div>
      </div>

      {/* Notice if Demo Data is active */}
      {isDemoActive && (
        <div className="p-3 bg-amber-50/80 border border-amber-300 rounded-lg text-xs text-amber-900 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold">DEMO DATA NOTICE:</strong> Currently demonstrating the architecture using curated demo datasets for India, USA, and MENA. Real mFilterIt ranking files can be connected below via the "Upload" buttons anytime.
            </div>
          </div>
          <span className="text-[11px] font-mono font-bold bg-[#FFCC29] px-2 py-0.5 rounded text-neutral-900 shrink-0">
            DEMO DATA
          </span>
        </div>
      )}

      {/* Section 1: The Three Master Keyword Sources */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#530093]" />
            Master Keyword Datasets (3 Separate Regional Sources)
          </h3>
          <span className="text-[11px] text-neutral-500">
            Complete keyword universe per market (never merged)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(['INDIA', 'USA', 'MENA'] as const).map((region) => {
            const source = masterSources[region];
            const isConnected = source.status === 'CONNECTED' || source.isDemoData;
            const isExpanded = expandedSourceId === source.id;

            return (
              <div
                key={source.id}
                className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 space-y-3 flex flex-col justify-between hover:border-[#530093]/40 transition-colors"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                        Source {region === 'INDIA' ? '1' : region === 'USA' ? '2' : '3'}
                      </span>
                      <h4 className="text-sm font-bold text-neutral-900">{source.name}</h4>
                    </div>
                    {getStatusBadge(source.status, source.isDemoData)}
                  </div>

                  <p className="text-[11.5px] text-neutral-500 leading-normal">
                    Complete keyword target list for {region}. Supports dynamic column mapping (Volume, KD, CPC, Intent, Category).
                  </p>

                  {/* Connected Details */}
                  {isConnected && (
                    <div className="mt-3 pt-2.5 border-t border-neutral-200/80 space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Keywords Ingested:</span>
                        <strong className="font-mono text-neutral-900 tabular-nums">
                          {source.keywordCount} rows
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Last Refreshed:</span>
                        <span className="text-neutral-700 font-mono text-[11px]">
                          {source.lastUpdated || 'Awaiting upload'}
                        </span>
                      </div>
                      {source.fileName && (
                        <div className="flex justify-between text-[11px]">
                          <span className="text-neutral-500">File:</span>
                          <span className="text-[#530093] font-mono truncate max-w-[150px]">
                            {source.fileName}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Detected columns dropdown */}
                  {isConnected && source.detectedColumns.length > 0 && (
                    <div className="mt-2 text-[11px]">
                      <button
                        onClick={() => setExpandedSourceId(isExpanded ? null : source.id)}
                        className="text-[#530093] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                      >
                        <span>{source.detectedColumns.length} Columns Detected</span>
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>

                      {isExpanded && (
                        <div className="mt-1.5 p-2 bg-white rounded border border-neutral-200 font-mono text-[10.5px] text-neutral-600 space-y-0.5">
                          {source.detectedColumns.map((col) => (
                            <div key={col} className="truncate">· {col}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Validation warnings */}
                  {source.validationWarnings.length > 0 && (
                    <div className="mt-2 p-2 bg-amber-50 rounded border border-amber-200 text-[10.5px] text-amber-800 space-y-0.5">
                      {source.validationWarnings.map((w, i) => (
                        <div key={i} className="flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                          <span>{w}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Upload & Refresh Buttons */}
                <div className="pt-2 border-t border-neutral-200/80 flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleOpenMasterUpload(region)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-neutral-700 bg-white hover:bg-neutral-100 rounded border border-neutral-300 transition-colors cursor-pointer"
                  >
                    <Upload className="w-3 h-3 text-[#530093]" />
                    <span>{isConnected ? 'Replace File' : 'Upload File'}</span>
                  </button>

                  <button
                    onClick={() => handleRefreshMaster(region)}
                    className="inline-flex items-center gap-1 px-2 py-1.5 text-xs font-medium text-neutral-600 hover:text-[#530093] rounded transition-colors cursor-pointer"
                    title="Refresh data from latest source"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Refresh</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 2: Source 4 — The Live Ranking Workbook (1 Workbook, 3 Tabs) */}
      <div className="space-y-3 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FFCC29]" />
              Live Ranking Data: Source 4 — Weekly Live Ranking Workbook (.xlsx)
            </h3>
            <p className="text-xs text-neutral-500">
              ONE Excel workbook containing three regional tabs. Updated every week for rank movement tracking.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {getStatusBadge(liveWorkbook.status, liveWorkbook.isDemoData)}
          </div>
        </div>

        {/* Workbook Container */}
        <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded bg-[#530093] flex items-center justify-center text-white font-bold text-sm">
                <FileSpreadsheet className="w-5 h-5 text-[#FFCC29]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-neutral-900">{liveWorkbook.name}</h4>
                  {liveWorkbook.fileName && (
                    <span className="text-[11px] font-mono text-neutral-500 bg-white px-2 py-0.5 rounded border border-neutral-200">
                      {liveWorkbook.fileName}
                    </span>
                  )}
                </div>
                <div className="text-xs text-neutral-500 mt-0.5">
                  Latest Weekly Cycle: <strong className="text-neutral-800">{liveWorkbook.currentWeekLabel || 'Awaiting upload'}</strong>
                  {liveWorkbook.lastUpdated && ` · Last Processed: ${liveWorkbook.lastUpdated}`}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleRefreshLiveWorkbook}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-[#530093] hover:bg-[#430077] rounded-md shadow-xs transition-colors cursor-pointer"
                title="Automatically refresh latest rankings from SharePoint source"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#FFCC29]" />
                <span>Refresh SharePoint Sync</span>
              </button>

              <button
                onClick={() => {
                  if (liveWorkbookInputRef.current) {
                    liveWorkbookInputRef.current.value = '';
                    liveWorkbookInputRef.current.click();
                  }
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11.5px] font-medium text-neutral-500 hover:text-neutral-800 bg-white hover:bg-neutral-100 rounded border border-dashed border-neutral-300 transition-colors cursor-pointer"
                title="Manual file upload fallback if SharePoint is offline"
              >
                <Upload className="w-3 h-3 text-neutral-400" />
                <span>Manual Upload / Fallback</span>
              </button>
            </div>
          </div>

          {/* Three Tabs Status Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            {(['INDIA', 'USA', 'MENA'] as const).map((reg) => {
              const tab = liveWorkbook.tabs[reg];
              const isTabActive = tab.rowCount > 0;

              return (
                <div
                  key={tab.tabName}
                  className="bg-white p-3 rounded-md border border-neutral-200 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-neutral-800">{tab.tabName}</span>
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                        isTabActive
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-neutral-100 text-neutral-500'
                      }`}
                    >
                      {isTabActive ? `${tab.rowCount} tracked` : 'Awaiting data'}
                    </span>
                  </div>

                  <div className="text-[11px] text-neutral-500 space-y-0.5">
                    <div>
                      Region Target: <strong className="text-neutral-700">{reg}</strong>
                    </div>
                    {isTabActive ? (
                      <div>
                        Detected: <span className="font-mono text-[#530093]">{tab.detectedColumns.slice(0, 3).join(', ')}...</span>
                      </div>
                    ) : (
                      <div className="italic text-neutral-400">Sheet required in uploaded .xlsx</div>
                    )}
                  </div>

                  {tab.validationWarnings.length > 0 && (
                    <div className="text-[10px] text-amber-700 bg-amber-50 p-1.5 rounded">
                      {tab.validationWarnings[0]}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Validation Warnings for Workbook */}
          {liveWorkbook.validationWarnings.length > 0 && (
            <div className="p-2.5 bg-amber-50 rounded border border-amber-200 text-xs text-amber-800 space-y-1">
              <strong className="block font-bold">Workbook Structure Check:</strong>
              {liveWorkbook.validationWarnings.map((w, idx) => (
                <div key={idx} className="flex items-center gap-1.5 text-[11px]">
                  <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                  <span>{w}</span>
                </div>
              ))}
            </div>
          )}

          {/* Architecture Rule Footer */}
          <div className="p-3 bg-white rounded border border-neutral-200 text-xs text-neutral-600 flex items-start gap-2">
            <Info className="w-4 h-4 text-[#530093] shrink-0 mt-0.5" />
            <div>
              <strong className="text-neutral-800">Weekly Versioning:</strong> When a new weekly workbook is uploaded, current rankings become previous rankings to automatically compute <strong>Position Change</strong> and <strong>Trend (Improving / Declining / Stable / Newly Ranking)</strong> without overwriting historical datasets.
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

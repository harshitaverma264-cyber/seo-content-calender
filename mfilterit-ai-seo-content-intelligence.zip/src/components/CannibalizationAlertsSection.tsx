import React from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle, ExternalLink, HelpCircle } from 'lucide-react';
import { CannibalizationAlert } from '../types/seo';

interface CannibalizationAlertsProps {
  alerts: CannibalizationAlert[];
}

export const CannibalizationAlertsSection: React.FC<CannibalizationAlertsProps> = ({ alerts }) => {
  return (
    <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-neutral-200 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-600" />
            <h2 className="text-base font-bold text-neutral-900">
              Keyword Cannibalization Guard & Audit
            </h2>
          </div>
          <p className="text-xs text-neutral-500">
            Automated check comparing proposed keywords and search intent against existing mFilterIt published pages to prevent self-competing rankings.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-red-700 bg-red-50 border border-red-200 px-3 py-1 rounded-md">
            {alerts.length} Potential Collisions Audited
          </span>
        </div>
      </div>

      {alerts.length === 0 ? (
        <div className="py-8 text-center text-neutral-500 text-xs flex flex-col items-center justify-center gap-2">
          <CheckCircle className="w-6 h-6 text-emerald-600" />
          <p className="font-semibold text-neutral-700">Zero Cannibalization Risks Detected</p>
          <p className="text-neutral-400">All planned opportunities target distinct keyword intent without splitting link equity.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-neutral-50 text-neutral-600 font-semibold border-b border-neutral-200 uppercase tracking-wider text-[11px]">
                <th className="py-2.5 px-3">Proposed Topic / Keyword</th>
                <th className="py-2.5 px-3">Existing mFilterIt URL & Target</th>
                <th className="py-2.5 px-3">Intent Similarity</th>
                <th className="py-2.5 px-3">Risk Level</th>
                <th className="py-2.5 px-3">Mandatory Action & Mitigation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {alerts.map((alert) => {
                const isHigh = alert.riskLevel === 'High';
                const isMed = alert.riskLevel === 'Medium';

                return (
                  <tr key={alert.id} className="hover:bg-neutral-50 transition-colors">
                    
                    {/* Proposed Topic & Keyword */}
                    <td className="py-3 px-3">
                      <div className="font-semibold text-neutral-900">{alert.proposedTopic}</div>
                      <div className="text-[11px] font-mono text-[#530093] mt-0.5 font-bold">
                        Proposed: {alert.proposedKeyword}
                      </div>
                    </td>

                    {/* Existing URL & Keyword */}
                    <td className="py-3 px-3 max-w-xs">
                      <a
                        href={alert.existingUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-neutral-700 hover:text-[#530093] hover:underline font-mono text-[11px] flex items-center gap-1 truncate"
                      >
                        <span className="truncate">{alert.existingUrl}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                      <div className="text-[11px] text-neutral-500 font-mono mt-0.5">
                        Targeting: <strong className="text-neutral-700">{alert.existingKeyword}</strong>
                      </div>
                    </td>

                    {/* Intent Similarity */}
                    <td className="py-3 px-3 text-neutral-700">
                      <span className="font-medium">{alert.intentSimilarity}</span>
                    </td>

                    {/* Risk Level */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold ${
                          isHigh
                            ? 'bg-red-50 text-red-800 border border-red-200'
                            : isMed
                            ? 'bg-amber-50 text-amber-800 border border-amber-200'
                            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        <AlertTriangle className="w-3 h-3" />
                        {alert.riskLevel} Risk
                      </span>
                    </td>

                    {/* Recommended Action */}
                    <td className="py-3 px-3 text-neutral-800">
                      <div className="text-[11.5px] leading-relaxed font-medium bg-neutral-50 p-2 rounded border border-neutral-200">
                        {alert.recommendedAction}
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Editorial Rule Note */}
      <div className="p-3 bg-neutral-50 rounded border border-neutral-200 text-xs text-neutral-600 flex items-start gap-2">
        <HelpCircle className="w-4 h-4 text-[#530093] shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-neutral-800">Intent Differentiation Rule:</span> Related keywords like{' '}
          <code className="text-[#530093] font-mono">"affiliate fraud"</code> (TOFU informational) and{' '}
          <code className="text-[#530093] font-mono">"affiliate fraud detection software"</code> (BOFU commercial software search) can safely coexist only if SERP structure and search intent justify separate assets. Otherwise, consolidate into one master cluster asset.
        </div>
      </div>
    </div>
  );
};

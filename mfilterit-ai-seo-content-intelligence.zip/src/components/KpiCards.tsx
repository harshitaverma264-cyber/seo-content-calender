import React from 'react';
import { Layers, Sparkles, RefreshCw, Target, ShieldCheck } from 'lucide-react';
import { ContentItem } from '../types/seo';
import { getTrustPillarForItem } from '../utils/trustPillar';

interface KpiCardsProps {
  items: ContentItem[];
}

export const KpiCards: React.FC<KpiCardsProps> = ({ items }) => {
  // 1. Total Content
  const totalContent = items.length;

  // 2. New Content
  const newContent = items.filter((i) => i.contentAction === 'NEW').length;

  // 3. Revamp / Expand
  const revampExpand = items.filter((i) =>
    i.contentAction === 'REVAMP' || i.contentAction === 'EXPAND' || i.contentAction === 'MERGE'
  ).length;

  // 4. Lead Opportunities
  const leadOpportunities = items.filter((i) => i.leadPotential === 'High').length;

  // 5. Trust Pillars breakdown
  const mediaTrustCount = items.filter((i) => getTrustPillarForItem(i) === 'Media Trust').length;
  const brandTrustCount = items.filter((i) => getTrustPillarForItem(i) === 'Brand Trust').length;
  const financialTrustCount = items.filter((i) => getTrustPillarForItem(i) === 'Financial Trust').length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
      {/* 1. Total Content */}
      <div className="bg-white border border-neutral-200 rounded-lg p-4 shadow-2xs hover:border-[#530093]/30 transition-colors">
        <div className="flex items-center justify-between text-neutral-500 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">Total Content</span>
          <Layers className="w-4 h-4 text-[#530093]" />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold font-mono text-neutral-900">{totalContent}</span>
          <span className="text-xs text-neutral-500">items planned</span>
        </div>
      </div>

      {/* 2. New Content */}
      <div className="bg-white border border-neutral-200 rounded-lg p-4 shadow-2xs hover:border-[#530093]/30 transition-colors">
        <div className="flex items-center justify-between text-neutral-500 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">New Content</span>
          <Sparkles className="w-4 h-4 text-[#530093]" />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold font-mono text-neutral-900">{newContent}</span>
          <span className="text-xs text-neutral-500">fresh topics</span>
        </div>
      </div>

      {/* 3. Revamp / Expand */}
      <div className="bg-white border border-neutral-200 rounded-lg p-4 shadow-2xs hover:border-[#530093]/30 transition-colors">
        <div className="flex items-center justify-between text-neutral-500 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">Revamp / Expand</span>
          <RefreshCw className="w-4 h-4 text-[#530093]" />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold font-mono text-neutral-900">{revampExpand}</span>
          <span className="text-xs text-neutral-500">existing pages</span>
        </div>
      </div>

      {/* 4. Lead Opportunities */}
      <div className="bg-white border border-neutral-200 rounded-lg p-4 shadow-2xs hover:border-[#530093]/30 transition-colors">
        <div className="flex items-center justify-between text-neutral-500 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">Lead Opportunities</span>
          <Target className="w-4 h-4 text-[#530093]" />
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold font-mono text-[#530093]">{leadOpportunities}</span>
          <span className="text-xs text-neutral-500">high lead priority</span>
        </div>
      </div>

      {/* 5. Trust Pillars Distribution */}
      <div className="col-span-2 sm:col-span-1 bg-white border border-neutral-200 rounded-lg p-3.5 shadow-2xs hover:border-[#530093]/30 transition-colors flex flex-col justify-between">
        <div className="flex items-center justify-between text-neutral-500 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-700">Trust Pillars</span>
          <ShieldCheck className="w-4 h-4 text-[#530093]" />
        </div>
        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
          <span className="px-2 py-0.5 rounded text-[10.5px] font-extrabold bg-purple-100 text-[#530093] border border-purple-200" title="Media Trust">
            Media: {mediaTrustCount}
          </span>
          <span className="px-2 py-0.5 rounded text-[10.5px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200" title="Brand Trust">
            Brand: {brandTrustCount}
          </span>
          <span className="px-2 py-0.5 rounded text-[10.5px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200" title="Financial Trust">
            Financial: {financialTrustCount}
          </span>
        </div>
      </div>
    </div>
  );
};

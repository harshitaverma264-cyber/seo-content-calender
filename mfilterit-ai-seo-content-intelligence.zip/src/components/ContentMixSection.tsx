import React from 'react';
import { ContentItem } from '../types/seo';
import { mFilterItSolutions } from '../data/solutionsAndPersonas';

interface ContentMixSectionProps {
  items: ContentItem[];
}

export const ContentMixSection: React.FC<ContentMixSectionProps> = ({ items }) => {
  const total = items.length || 1;

  // Funnel Stage Breakdown
  const tofuCount = items.filter((i) => i.funnelStage === 'TOFU').length;
  const mofuCount = items.filter((i) => i.funnelStage === 'MOFU').length;
  const bofuCount = items.filter((i) => i.funnelStage === 'BOFU').length;

  const tofuPct = Math.round((tofuCount / total) * 100);
  const mofuPct = Math.round((mofuCount / total) * 100);
  const bofuPct = Math.round((bofuCount / total) * 100);

  // Content Action Breakdown
  const actionCounts = {
    NEW: items.filter((i) => i.contentAction === 'NEW').length,
    REVAMP: items.filter((i) => i.contentAction === 'REVAMP').length,
    EXPAND: items.filter((i) => i.contentAction === 'EXPAND').length,
    MERGE: items.filter((i) => i.contentAction === 'MERGE').length,
    SUPPORTING: items.filter((i) => i.contentAction === 'SUPPORTING').length,
  };

  // Solution distribution
  const solutionCounts = mFilterItSolutions.map((sol) => ({
    solution: sol,
    count: items.filter((i) => i.productMapping === sol).length,
  })).sort((a, b) => b.count - a.count);

  return (
    <div className="bg-white border border-neutral-200 rounded-lg p-5 space-y-6">
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-base font-bold text-neutral-900">
            Content Mix & Lead Funnel Architecture
          </h2>
          <p className="text-xs text-neutral-500">
            Balance between high-conversion BOFU assets and topical authority TOFU pillars.
          </p>
        </div>
        <div className="text-xs text-right">
          <span className="text-neutral-500">Total Monthly Scope:</span>{' '}
          <strong className="font-mono text-neutral-900">{items.length} assets</strong>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* 1. Funnel Distribution */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-neutral-700">
            <span>Search Intent & Funnel Balance</span>
            <span className="text-neutral-500 font-mono text-[11px]">Target: 40% BOFU</span>
          </div>

          {/* Segmented bar */}
          <div className="h-3 w-full bg-neutral-100 rounded-full overflow-hidden flex">
            <div
              style={{ width: `${bofuPct}%` }}
              className="bg-[#530093] transition-all"
              title={`BOFU: ${bofuPct}%`}
            />
            <div
              style={{ width: `${mofuPct}%` }}
              className="bg-[#FFCC29] transition-all"
              title={`MOFU: ${mofuPct}%`}
            />
            <div
              style={{ width: `${tofuPct}%` }}
              className="bg-neutral-300 transition-all"
              title={`TOFU: ${tofuPct}%`}
            />
          </div>

          {/* Funnel rows */}
          <div className="space-y-2 pt-1 text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#530093]" />
                <span className="font-medium text-neutral-800">BOFU (Bottom of Funnel)</span>
              </div>
              <div className="font-mono tabular-nums text-neutral-700">
                {bofuCount} <span className="text-neutral-400">({bofuPct}%)</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FFCC29]" />
                <span className="font-medium text-neutral-800">MOFU (Middle of Funnel)</span>
              </div>
              <div className="font-mono tabular-nums text-neutral-700">
                {mofuCount} <span className="text-neutral-400">({mofuPct}%)</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-neutral-300" />
                <span className="font-medium text-neutral-800">TOFU (Top of Funnel)</span>
              </div>
              <div className="font-mono tabular-nums text-neutral-700">
                {tofuCount} <span className="text-neutral-400">({tofuPct}%)</span>
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-neutral-50 rounded-md border border-neutral-200 text-[11px] text-neutral-600 leading-normal">
            <strong className="text-neutral-800">Policy:</strong> Prioritize BOFU/MOFU for qualified leads without sacrificing TOFU cluster pillars needed for domain authority.
          </div>
        </div>

        {/* 2. Content Action Breakdown */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-neutral-700">
            <span>Content Action Strategy</span>
            <span className="text-neutral-500 font-mono text-[11px]">Revamp vs New</span>
          </div>

          <div className="space-y-2 text-xs">
            {Object.entries(actionCounts).map(([action, count]) => {
              const pct = Math.round((count / total) * 100);
              return (
                <div key={action} className="space-y-1">
                  <div className="flex items-center justify-between text-[11.5px]">
                    <span className="font-medium text-neutral-800">{action}</span>
                    <span className="font-mono text-neutral-600 tabular-nums">
                      {count} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${
                        action === 'REVAMP'
                          ? 'bg-[#530093]'
                          : action === 'NEW'
                          ? 'bg-neutral-800'
                          : action === 'EXPAND'
                          ? 'bg-[#FFCC29]'
                          : 'bg-neutral-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-2.5 bg-neutral-50 rounded-md border border-neutral-200 text-[11px] text-neutral-600 leading-normal">
            <strong className="text-neutral-800">Action Rule:</strong> Never create a new article when an existing mFilterIt URL can be revamped or expanded.
          </div>
        </div>

        {/* 3. Product / Solution Coverage */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-neutral-700">
            <span>mFilterIt Solution Mapping</span>
            <span className="text-neutral-500 font-mono text-[11px]">Core Products</span>
          </div>

          <div className="space-y-2 text-xs">
            {solutionCounts.map(({ solution, count }) => {
              const pct = Math.round((count / total) * 100);
              return (
                <div key={solution} className="space-y-1">
                  <div className="flex items-center justify-between text-[11.5px]">
                    <span className="text-neutral-800 truncate pr-2 max-w-[200px]" title={solution}>
                      {solution}
                    </span>
                    <span className="font-mono text-neutral-600 tabular-nums shrink-0">
                      {count}
                    </span>
                  </div>
                  <div className="w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#530093] h-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-2.5 bg-neutral-50 rounded-md border border-neutral-200 text-[11px] text-neutral-600 leading-normal">
            <strong className="text-neutral-800">Strict Product Grounding:</strong> Every content opportunity maps directly to a verified mFilterIt solution line.
          </div>
        </div>

      </div>
    </div>
  );
};

import React from 'react';
import {
  Layers,
  FileText,
  Globe,
  Image as ImageIcon,
  BookOpen,
  ArrowRightLeft,
  Swords,
  Target
} from 'lucide-react';
import { ContentTypeFilter } from '../types/seo';
import { AppViewMode } from './Header';

interface SidebarProps {
  activeContentType: ContentTypeFilter;
  onSelectContentType: (type: ContentTypeFilter) => void;
  contentTypeCounts: Record<ContentTypeFilter, number>;
  currentView: AppViewMode;
  onSelectView: (view: AppViewMode) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeContentType,
  onSelectContentType,
  contentTypeCounts,
  currentView,
  onSelectView,
}) => {
  const sidebarItems: { label: ContentTypeFilter; icon: React.ReactNode }[] = [
    { label: 'All Content', icon: <Layers className="w-4 h-4 shrink-0" /> },
    { label: 'Website Blog', icon: <FileText className="w-4 h-4 shrink-0" /> },
    { label: 'SEO / Guest Post', icon: <Globe className="w-4 h-4 shrink-0" /> },
    { label: 'Infographic', icon: <ImageIcon className="w-4 h-4 shrink-0" /> },
    { label: 'Glossary', icon: <BookOpen className="w-4 h-4 shrink-0" /> },
  ];

  return (
    <aside className="w-64 bg-white border-r border-neutral-200/90 flex flex-col justify-between shrink-0 h-screen sticky top-0 z-40 select-none">
      
      {/* Top Section: Brand & Nav Items */}
      <div className="flex flex-col">
        
        {/* Brand Header */}
        <div className="p-5 pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-2.5">
            {/* mFilterIt Circular Emblem */}
            <div className="w-8 h-8 rounded-full bg-[#530093] flex items-center justify-center text-white font-black text-sm tracking-tighter shrink-0 shadow-2xs">
              m
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black tracking-tight text-neutral-900 leading-none">
                mFilter<span className="text-[#530093]">It</span>
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Section */}
        <div className="p-4 space-y-4">
          <div>
            <h2 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider px-3 mb-2.5">
              CONTENT CALENDAR
            </h2>

            <nav className="space-y-1.5">
              {/* Competitor Content Gap as first item */}
              <button
                onClick={() => onSelectView('competitor-gap')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'competitor-gap'
                    ? 'bg-[#530093]/10 text-[#530093] border border-[#530093]/30 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100/70 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={currentView === 'competitor-gap' ? 'text-[#530093]' : 'text-neutral-500'}>
                    <Swords className="w-4 h-4 shrink-0" />
                  </span>
                  <span>Competitor Content Gap</span>
                </div>
                <span className={`text-[11px] font-mono px-2 py-0.5 rounded-md ${
                  currentView === 'competitor-gap'
                    ? 'bg-[#530093] text-white font-bold'
                    : 'bg-[#FFCC29]/30 text-neutral-800 font-bold'
                }`}>
                  Gap Studio
                </span>
              </button>

              {/* Keyword Gap directly below Competitor Content Gap */}
              <button
                onClick={() => onSelectView('keyword-gap')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  currentView === 'keyword-gap'
                    ? 'bg-[#530093]/10 text-[#530093] border border-[#530093]/30 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100/70 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={currentView === 'keyword-gap' ? 'text-[#530093]' : 'text-neutral-500'}>
                    <Target className="w-4 h-4 shrink-0" />
                  </span>
                  <span>Keyword Gap</span>
                </div>
                <span className={`text-[11px] font-mono px-2 py-0.5 rounded-md ${
                  currentView === 'keyword-gap'
                    ? 'bg-[#530093] text-white font-bold'
                    : 'bg-purple-100 text-purple-800 font-bold'
                }`}>
                  Gap Analysis
                </span>
              </button>

              {sidebarItems.map((item) => {
                const isActive = currentView === 'calendar' && activeContentType === item.label;
                const count = contentTypeCounts[item.label] || 0;

                return (
                  <button
                    key={item.label}
                    onClick={() => {
                      onSelectContentType(item.label);
                      if (currentView !== 'calendar') {
                        onSelectView('calendar');
                      }
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#530093]/10 text-[#530093] border border-[#530093]/30 shadow-2xs'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100/70 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={isActive ? 'text-[#530093]' : 'text-neutral-500'}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    <span
                      className={`text-[11px] font-mono px-2 py-0.5 rounded-md ${
                        isActive
                          ? 'bg-[#530093] text-white font-bold'
                          : 'bg-neutral-100 text-neutral-500'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </nav>
          </div>

        </div>

      </div>

      {/* Bottom Section: User Profile Card */}
      <div className="p-4 border-t border-neutral-100 bg-white">
        <div className="flex items-center justify-between p-2 rounded-xl hover:bg-neutral-50 transition-colors">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#530093] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
              HV
            </div>
            <div className="flex flex-col text-left">
              <span className="text-xs font-bold text-neutral-900 leading-tight">
                Harshita Verma
              </span>
              <span className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wide">
                SEO_WEB
              </span>
            </div>
          </div>
          <button
            title="Switch Profile / Workspace"
            className="text-neutral-400 hover:text-neutral-600 p-1.5 rounded-md cursor-pointer hover:bg-neutral-100"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </aside>
  );
};

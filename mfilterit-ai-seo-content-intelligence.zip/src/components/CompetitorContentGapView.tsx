import React, { useState, useMemo, useEffect } from 'react';
import {
  Swords,
  ExternalLink,
  Plus,
  CheckCircle2,
  AlertCircle,
  Globe,
  TrendingUp,
  Filter,
  Shield,
  Layers,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  RefreshCw
} from 'lucide-react';
import { COMPETITOR_GAP_RECORDS, CompetitorGapRecord } from '../data/competitorGaps';
import { ContentItem } from '../types/seo';
import { fetchLiveMFilterItBlogs } from '../utils/liveBlogAnalysis';

interface CompetitorContentGapViewProps {
  onSendToCalendar: (item: ContentItem) => void;
  onBackToCalendar: () => void;
  currentMonthLabel: string;
  currentMonthlyItems?: ContentItem[];
}

export const CompetitorContentGapView: React.FC<CompetitorContentGapViewProps> = ({
  onSendToCalendar,
  onBackToCalendar,
  currentMonthLabel,
  currentMonthlyItems = [],
}) => {
  const [selectedRegion, setSelectedRegion] = useState<'ALL' | 'INDIA' | 'USA' | 'MENA' | 'OVERALL'>('ALL');
  const [selectedGapType, setSelectedGapType] = useState<string>('ALL');
  const [selectedSolution, setSelectedSolution] = useState<string>('ALL');
  const [selectedCrawlStatus, setSelectedCrawlStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [scheduledIds, setScheduledIds] = useState<Record<string, boolean>>({});
  const [sitemapPayload, setSitemapPayload] = useState<any>(null);
  const [isRefreshingSitemap, setIsRefreshingSitemap] = useState<boolean>(false);
  const [competitorCrawlPayload, setCompetitorCrawlPayload] = useState<any>(null);
  const [isRefreshingCompetitorCrawl, setIsRefreshingCompetitorCrawl] = useState<boolean>(false);

  useEffect(() => {
    fetchLiveMFilterItBlogs().then((data) => {
      setSitemapPayload(data);
    });
    fetch('/api/competitor-crawl')
      .then(res => res.json())
      .then(data => setCompetitorCrawlPayload(data))
      .catch(err => console.error(err));
  }, []);

  const handleRefreshSitemap = async () => {
    setIsRefreshingSitemap(true);
    try {
      const data = await fetchLiveMFilterItBlogs(true);
      setSitemapPayload(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsRefreshingSitemap(false);
    }
  };

  const handleRefreshCompetitorCrawl = async () => {
    setIsRefreshingCompetitorCrawl(true);
    try {
      const res = await fetch('/api/competitor-crawl?refresh=true');
      const data = await res.json();
      setCompetitorCrawlPayload(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsRefreshingCompetitorCrawl(false);
    }
  };

  const enhancedRecords = useMemo(() => {
    if (!competitorCrawlPayload?.competitors) return COMPETITOR_GAP_RECORDS;
    const crawlMap = new Map(competitorCrawlPayload.competitors.map((c: any) => [c.competitorName.toLowerCase(), c]));
    return COMPETITOR_GAP_RECORDS.map((rec) => {
      const liveCrawl = crawlMap.get(rec.competitorName.toLowerCase()) as any;
      if (liveCrawl) {
        return {
          ...rec,
          isCrawlSuccess: liveCrawl.isCrawlSuccess,
          crawlStatusNote: liveCrawl.crawlStatusNote,
          sampleUrls: liveCrawl.sampleUrls || []
        };
      }
      return rec;
    });
  }, [competitorCrawlPayload]);

  const filteredRecords = useMemo(() => {
    return enhancedRecords.filter((rec) => {
      const matchRegion = selectedRegion === 'ALL' || rec.region === selectedRegion;
      const matchGap = selectedGapType === 'ALL' || rec.gapType === selectedGapType;
      const matchSol = selectedSolution === 'ALL' || rec.solution === selectedSolution;
      const matchCrawl =
        selectedCrawlStatus === 'ALL' ||
        (selectedCrawlStatus === 'SUCCESS' && rec.isCrawlSuccess) ||
        (selectedCrawlStatus === 'FAILURE' && !rec.isCrawlSuccess);

      const matchSearch =
        !searchTerm.trim() ||
        rec.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.primaryKeyword.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.competitorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.competitorTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.trustPillar.toLowerCase().includes(searchTerm.toLowerCase());

      return matchRegion && matchGap && matchSol && matchCrawl && matchSearch;
    });
  }, [enhancedRecords, selectedRegion, selectedGapType, selectedSolution, selectedCrawlStatus, searchTerm]);

  const stats = useMemo(() => {
    const total = COMPETITOR_GAP_RECORDS.length;
    const missing = COMPETITOR_GAP_RECORDS.filter((r) => r.gapType === 'MISSING_TOPIC').length;
    const overlapping = COMPETITOR_GAP_RECORDS.filter((r) => r.gapType === 'OVERLAPPING_TOPIC').length;
    const actionable = COMPETITOR_GAP_RECORDS.filter((r) => r.gapType === 'ACTIONABLE_GAP').length;
    const crawlFailures = COMPETITOR_GAP_RECORDS.filter((r) => !r.isCrawlSuccess).length;
    return { total, missing, overlapping, actionable, crawlFailures };
  }, []);

  const handleScheduleRecord = (rec: CompetitorGapRecord) => {
    const isDuplicate = currentMonthlyItems.some(
      (item) =>
        item.topic.toLowerCase() === rec.topic.toLowerCase() ||
        (item.primaryKeyword && item.primaryKeyword.toLowerCase() === rec.primaryKeyword.toLowerCase())
    );

    const hasExistingCoverage = Boolean(rec.mFilterItMatchUrl || rec.mFilterItMatchTitle);

    if (isDuplicate) {
      alert(`Duplicate Topic Warning: The topic "${rec.topic}" or primary keyword "${rec.primaryKeyword}" is already scheduled in the monthly content calendar.`);
      return;
    }

    if (hasExistingCoverage) {
      const proceed = window.confirm(
        `Existing mFilterIt Coverage Detected (Potential Cannibalization Risk):\nMatch Asset: "${rec.mFilterItMatchTitle || rec.mFilterItMatchUrl}"\n\nDo you still want to schedule this gap recommendation to the calendar?`
      );
      if (!proceed) return;
    }

    // Enforce monthly and regional quotas
    const contentType = 'Website Blog';
    const region = rec.region;
    const existingCountForRegion = currentMonthlyItems.filter(
      (item) => item.contentType === contentType && item.region === region
    ).length;

    const regionQuotaLimit = 5; // 5 Website Blogs per region (India 5, USA 5, MENA 5)
    if (existingCountForRegion >= regionQuotaLimit) {
      alert(`Regional Quota Reached: The monthly quota for Website Blogs in region ${region} is exactly ${regionQuotaLimit}. Cannot exceed regional quota.`);
      return;
    }

    const newItem: ContentItem = {
      id: `comp-gap-${rec.id}-${Date.now()}`,
      date: '2026-10-20',
      contentType: 'Website Blog',
      topic: rec.topic,
      primaryKeyword: rec.primaryKeyword,
      focusKeyword: rec.primaryKeyword,
      searchVolume: rec.searchVolume,
      primarySearchVolume: rec.searchVolume,
      primaryVolumeType: 'Verified',
      primarySource: `Competitor Intelligence Benchmark (${rec.competitorName})`,
      primaryLastUpdated: '2026-10-12',
      region: rec.region,
      productMapping: rec.solution,
      icpPersona: rec.icpPersona as any,
      contentAction: rec.recommendedAction,
      searchIntent: rec.funnelStage === 'BOFU' ? 'Transactional' : rec.funnelStage === 'MOFU' ? 'Commercial Investigation' : 'Informational',
      funnelStage: rec.funnelStage,
      priority: rec.priority,
      leadPotential: rec.priority === 'High' ? 'High' : 'Medium',
      conversionPotential: rec.priority === 'High' ? 'High' : 'Medium',
      leadRationale: `[Trust Pillar: ${rec.trustPillar}] Competitor Gap Intelligence against ${rec.competitorName} (${rec.competitorUrl}). Solution: ${rec.solution}. Action: ${rec.recommendedAction}. Rationale: ${rec.rationale}`,
      competitorReferenceLinks: [rec.competitorUrl, ...(rec.sampleUrls || [])],
      status: 'Planned',
      recommendedCta: `Request Free ${rec.solution.split('/')[0]} Audit`,
      actionRationale: rec.rationale,
    };

    onSendToCalendar(newItem);
    setScheduledIds((prev) => ({ ...prev, [rec.id]: true }));
  };

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'NEW':
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-100 text-emerald-800 border border-emerald-200">NEW</span>;
      case 'REVAMP':
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-blue-100 text-blue-800 border border-blue-200">REVAMP</span>;
      case 'EXPAND':
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-purple-100 text-purple-800 border border-purple-200">EXPAND</span>;
      case 'OVERLAP':
      case 'SUPPORT':
      case 'SUPPORTING':
      case 'MERGE':
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-indigo-100 text-indigo-800 border border-indigo-200">OVERLAP</span>;
      default:
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-neutral-100 text-neutral-800">{action}</span>;
    }
  };

  const getGapTypeBadge = (type: string) => {
    switch (type) {
      case 'MISSING_TOPIC':
        return <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200/60 flex items-center gap-1.5"><Plus className="w-3 h-3" /> Missing Topic Gap</span>;
      case 'OVERLAPPING_TOPIC':
        return <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200/60 flex items-center gap-1.5"><Layers className="w-3 h-3" /> Overlapping Topic</span>;
      case 'ACTIONABLE_GAP':
        return <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200/60 flex items-center gap-1.5"><TrendingUp className="w-3 h-3" /> Actionable Expansion</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* View Header & Back Button */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-5 border-b border-neutral-200">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#530093]/10 border border-[#530093]/30 flex items-center justify-center text-[#530093]">
            <Swords className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-[#530093] uppercase tracking-wider">Competitor Intelligence Hub</span>
            </div>
            <h2 className="text-xl font-black text-neutral-900 tracking-tight">
              Competitor Content Gap &amp; Overlap Studio
            </h2>
            <p className="text-xs text-neutral-500">
              Comparing live competitor blogs, Trust Pillars, and solutions against mFilterIt. Distinguishing crawl failures from genuine content gaps.
            </p>
          </div>
        </div>

        <button
          onClick={onBackToCalendar}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-neutral-700 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-xl transition-colors cursor-pointer shadow-2xs"
        >
          <span>Back to Content Calendar</span>
        </button>
      </div>







      {/* Live Competitor Crawling Section */}
      <div className="bg-gradient-to-r from-purple-50 via-white to-neutral-50 border border-purple-200/80 rounded-2xl p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
            <RefreshCw className={`w-4 h-4 ${isRefreshingCompetitorCrawl ? 'animate-spin' : ''}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-neutral-900">Live Competitor Crawling &amp; Discovery</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                {competitorCrawlPayload?.source === 'CACHED' ? 'Cached (15m TTL)' : 'Live Crawled'}
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">
              Crawled {competitorCrawlPayload?.competitors?.length || 12} competitor sitemaps &amp; accessible URLs with robust bot-shield fallback handling.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefreshCompetitorCrawl}
            disabled={isRefreshingCompetitorCrawl}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-purple-700 bg-purple-100 hover:bg-purple-200 border border-purple-300 rounded-xl transition-colors cursor-pointer disabled:opacity-50 shadow-2xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingCompetitorCrawl ? 'animate-spin' : ''}`} />
            <span>{isRefreshingCompetitorCrawl ? 'Crawling Competitors...' : 'Refresh Competitor Crawl'}</span>
          </button>
        </div>
      </div>

      {/* Records Table / Cards Grid */}
      <div className="space-y-4">
        {filteredRecords.length === 0 ? (
          <div className="bg-white rounded-2xl border border-neutral-200/80 p-12 text-center">
            <AlertCircle className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
            <p className="text-sm font-semibold text-neutral-700">No competitor gaps match your selected filters.</p>
            <p className="text-xs text-neutral-400 mt-1">Try resetting filters or adjusting your search query.</p>
          </div>
        ) : (
          filteredRecords.map((rec) => {
            const isScheduled = scheduledIds[rec.id];

            return (
              <div
                key={rec.id}
                className="bg-white rounded-2xl border border-neutral-200/80 p-5 shadow-2xs hover:shadow-md transition-shadow flex flex-col gap-4"
              >
                {/* Top Row: Competitor & Badges */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-100 pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-700 font-black text-xs">
                      {rec.competitorName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-neutral-900">{rec.competitorName}</span>
                        <a
                          href={rec.competitorWebsite}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] text-blue-600 hover:underline inline-flex items-center gap-1"
                        >
                          <span>({rec.competitorWebsite.replace('https://', '')})</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                        <span className="text-neutral-300">·</span>
                        <span className="text-[11px] font-semibold text-neutral-600 bg-neutral-100 px-2 py-0.5 rounded">
                          {rec.region === 'INDIA' ? '🇮🇳 India' : rec.region === 'USA' ? '🇺🇸 USA' : rec.region === 'MENA' ? '🇦🇪 MENA' : '🌐 Overall'}
                        </span>
                      </div>
                      <p className="text-[11px] text-purple-700 font-semibold mt-0.5">
                        Trust Pillar: {rec.trustPillar} &gt; {rec.relevantCategory}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {getGapTypeBadge(rec.gapType)}
                    {getActionBadge(rec.recommendedAction)}
                    <span className="text-xs font-bold text-neutral-700 bg-neutral-100 px-2.5 py-1 rounded-lg">
                      Vol: {rec.searchVolume.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Content Details */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {/* Competitor Evidence */}
                  <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5 text-purple-600" />
                        <span>Competitor Content &amp; Evidence</span>
                      </span>
                    </div>

                    <div>
                      <a
                        href={rec.competitorUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1 leading-tight"
                      >
                        <span>{rec.competitorTitle}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                      <p className="text-[11px] text-neutral-500 mt-1 font-mono break-all">{rec.competitorUrl}</p>
                    </div>

                    <div className="border-t border-neutral-200/60 pt-2 flex items-center justify-between gap-2">
                      <p className="text-[11px] text-neutral-600 italic">
                        Crawl Status: {rec.crawlStatusNote}
                      </p>
                      {!rec.isCrawlSuccess && (
                        <span className="shrink-0 px-2 py-0.5 text-[10px] font-bold rounded bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 text-amber-700" />
                          <span>NEEDS VERIFICATION</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* mFilterIt Mapping */}
                  <div className="bg-[#530093]/5 p-3.5 rounded-xl border border-[#530093]/20 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#530093] tracking-wider flex items-center gap-1.5">
                        <Shield className="w-3.5 h-3.5 text-[#530093]" />
                        <span>mFilterIt Solution Mapping</span>
                      </span>
                      <span className="text-[10px] font-bold text-[#530093] bg-[#530093]/10 px-2 py-0.5 rounded">
                        {rec.solution}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs font-black text-neutral-900">{rec.topic}</h4>
                      <p className="text-[11px] text-neutral-600 mt-0.5">
                        Primary Keyword: <strong className="text-neutral-800">{rec.primaryKeyword}</strong> ({rec.funnelStage} · {rec.icpPersona})
                      </p>
                    </div>

                    {rec.mFilterItMatchUrl && (
                      <div className="text-[11px] text-emerald-700 bg-emerald-50 p-2 rounded border border-emerald-200/60">
                        <span className="font-bold">Existing Match Asset:</span>{' '}
                        <a href={rec.mFilterItMatchUrl} target="_blank" rel="noopener noreferrer" className="underline hover:text-emerald-900">
                          {rec.mFilterItMatchTitle}
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Rationale & Action */}
                  <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200/60 flex flex-col justify-between space-y-3">
                    <div>
                      <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block mb-1">
                        Strategic Rationale &amp; Gap Analysis
                      </span>
                      <p className="text-xs text-neutral-700 leading-relaxed">{rec.rationale}</p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-neutral-200/60">
                      <span className="text-[11px] font-bold text-neutral-500">
                        Priority: <strong className={rec.priority === 'High' ? 'text-red-600' : 'text-amber-600'}>{rec.priority}</strong>
                      </span>

                      <button
                        onClick={() => handleScheduleRecord(rec)}
                        disabled={isScheduled}
                        className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer shadow-2xs ${
                          isScheduled
                            ? 'bg-emerald-600 text-white cursor-default'
                            : 'bg-[#530093] hover:bg-[#430078] text-white'
                        }`}
                      >
                        {isScheduled ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Scheduled to Calendar</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Schedule to Calendar</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

import React from 'react';
import { Target, Check, Sparkles, Filter, Info, ChevronRight, Layers } from 'lucide-react';
import { StrategicObjective, ContentItem } from '../types/seo';
import { ALL_STRATEGIC_OBJECTIVES, getItemStrategicObjectives, isItemAlignedWithObjectives } from '../utils/strategicObjectives';

interface StrategicObjectivesBarProps {
  selectedObjectives: StrategicObjective[];
  onToggleObjective: (objective: StrategicObjective) => void;
  onSelectAllObjectives: () => void;
  onClearObjectives: () => void;
  monthlyItems: ContentItem[];
}

export const StrategicObjectivesBar: React.FC<StrategicObjectivesBarProps> = ({
  selectedObjectives,
  onToggleObjective,
  onSelectAllObjectives,
  onClearObjectives,
  monthlyItems,
}) => {
  const isAllSelected = selectedObjectives.length === ALL_STRATEGIC_OBJECTIVES.length;
  const isNoneSelected = selectedObjectives.length === 0;

  // Calculate matching items count
  const matchingItemCount = monthlyItems.filter((item) =>
    isItemAlignedWithObjectives(item, selectedObjectives)
  ).length;

  return (
    <div className="bg-white border border-neutral-200 rounded-xl p-4 shadow-xs space-y-3">
      
      {/* Top Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-200/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-md bg-[#530093]/10 text-[#530093] border border-[#530093]/20">
            <Target className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-neutral-900">
                Strategic Content Objectives &amp; High-Level Priorities
              </h3>
              <span className="px-2 py-0.5 text-[10px] font-extrabold bg-purple-50 text-[#530093] border border-purple-200 rounded-md">
                Select 1 or Multiple
              </span>
            </div>
            <p className="text-[11.5px] text-neutral-500 mt-0.5">
              Prioritize monthly SEO topics based on target enterprise growth goals.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 text-xs self-start sm:self-auto">
          <button
            onClick={isAllSelected ? onClearObjectives : onSelectAllObjectives}
            className="text-[11px] font-bold text-[#530093] hover:text-[#3a0068] hover:underline cursor-pointer"
          >
            {isAllSelected ? 'Deselect All' : 'Select All (All 5 Active)'}
          </button>
        </div>
      </div>

      {/* Selectable Objective Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
        {ALL_STRATEGIC_OBJECTIVES.map((obj) => {
          const isSelected = selectedObjectives.includes(obj.id);

          // Count matching items for this specific objective in active month
          const countForThisObj = monthlyItems.filter((item) =>
            getItemStrategicObjectives(item).includes(obj.id)
          ).length;

          return (
            <button
              key={obj.id}
              onClick={() => onToggleObjective(obj.id)}
              className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all flex flex-col justify-between gap-1.5 relative group ${
                isSelected
                  ? 'bg-purple-50/70 border-[#530093] shadow-xs ring-1 ring-[#530093]/30'
                  : 'bg-neutral-50/60 hover:bg-white border-neutral-200 hover:border-neutral-300'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm">{obj.iconSymbol}</span>
                  <span className={`text-xs font-bold leading-tight ${isSelected ? 'text-[#530093]' : 'text-neutral-800'}`}>
                    {obj.label}
                  </span>
                </div>
                
                <div className={`w-4 h-4 rounded-full flex items-center justify-center border text-[10px] shrink-0 ${
                  isSelected
                    ? 'bg-[#530093] text-white border-[#530093]'
                    : 'bg-white border-neutral-300 text-transparent'
                }`}>
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                </div>
              </div>

              <div className="flex items-center justify-between text-[10.5px] mt-1">
                <span className="text-neutral-500 font-medium">Aligned Topics:</span>
                <span className={`font-extrabold px-1.5 py-0.2 rounded ${
                  isSelected ? 'bg-[#530093]/10 text-[#530093]' : 'bg-neutral-200/80 text-neutral-700'
                }`}>
                  {countForThisObj}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Strategic Priority Alignment Summary Banner */}
      <div className="p-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#FFCC29] shrink-0" />
          <span className="text-neutral-700 font-medium">
            Active Priority Alignment: <strong className="text-neutral-900 font-bold">{matchingItemCount} of {monthlyItems.length} Monthly Topics</strong> match your selected strategic objectives ({selectedObjectives.length === 0 ? 'None selected' : selectedObjectives.join(', ')}).
          </span>
        </div>
      </div>

    </div>
  );
};

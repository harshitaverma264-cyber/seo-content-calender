import React from 'react';
import { RefreshCw, ArrowUpRight, GitMerge, Maximize2, AlertCircle } from 'lucide-react';
import { ContentItem } from '../types/seo';

interface ContentRefreshSectionProps {
  items: ContentItem[];
  onSelectItem: (item: ContentItem) => void;
}

export const ContentRefreshSection: React.FC<ContentRefreshSectionProps> = ({
  items,
  onSelectItem,
}) => {
  // Filter for REVAMP, EXPAND, MERGE
  const refreshCandidates = items.filter((item) =>
    ['REVAMP', 'EXPAND', 'MERGE'].includes(item.contentAction)
  );

  return (
    <div className="bg-white border border-neutral-200/90 rounded-2xl p-6 space-y-4 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-neutral-200 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-[#530093]" />
            <h2 className="text-base font-bold text-neutral-900">
              Existing Content Refresh & Consolidation Pipeline
            </h2>
          </div>
          <p className="text-xs text-neutral-500">
            Strict mandate: Never produce duplicate URLs when existing mFilterIt content can be revamped, expanded, or merged.
          </p>
        </div>

        <div className="text-xs font-semibold text-neutral-700 bg-neutral-100 px-3 py-1 rounded-md self-start sm:self-auto border border-neutral-200">
          {refreshCandidates.length} Existing Assets Requiring Action
        </div>
      </div>

      {refreshCandidates.length === 0 ? (
        <div className="py-8 text-center text-neutral-500 text-xs">
          No content refresh candidates identified for this monthly cycle.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {refreshCandidates.map((item) => {
            const isRevamp = item.contentAction === 'REVAMP';
            const isExpand = item.contentAction === 'EXPAND';
            const isMerge = item.contentAction === 'MERGE';

            return (
              <div
                key={item.id}
                onClick={() => onSelectItem(item)}
                className="border border-neutral-200 hover:border-[#530093] rounded-lg p-4 transition-all hover:shadow-xs cursor-pointer flex flex-col justify-between bg-neutral-50/40 group"
              >
                <div>
                  {/* Action Badge & Region */}
                  <div className="flex items-center justify-between text-[11px] mb-2">
                    <span
                      className={`font-bold px-2 py-0.5 rounded text-xs ${
                        isRevamp
                          ? 'bg-[#530093] text-white'
                          : isExpand
                          ? 'bg-[#FFCC29] text-neutral-900'
                          : 'bg-red-700 text-white'
                      }`}
                    >
                      {item.contentAction}
                    </span>
                    <span className="font-medium text-neutral-500">{item.region}</span>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-bold text-neutral-900 group-hover:text-[#530093] transition-colors leading-snug">
                    {item.topic}
                  </h3>

                  {/* Existing URL Reference */}
                  {item.referenceLink && (
                    <div className="mt-2 text-xs">
                      <span className="text-neutral-400 text-[10.5px] uppercase font-bold tracking-wider block">
                        Target Existing URL
                      </span>
                      <a
                        href={item.referenceLink}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="text-[#530093] hover:underline font-mono text-[11px] flex items-center gap-1 truncate"
                      >
                        <span className="truncate">{item.referenceLink}</span>
                        <ArrowUpRight className="w-3 h-3 shrink-0" />
                      </a>
                    </div>
                  )}

                  {/* Action Rationale */}
                  <div className="mt-3 text-xs bg-white p-2.5 rounded border border-neutral-200">
                    <span className="font-semibold text-neutral-800 block text-[11px] mb-1">
                      Editorial Action Rationale:
                    </span>
                    <p className="text-neutral-600 text-[11.5px] leading-relaxed">
                      {item.actionRationale ||
                        (isRevamp
                          ? 'Update outdated data, refresh benchmarks to 2026/2027, and optimize search intent.'
                          : isExpand
                          ? 'Broaden scope to capture emerging sub-queries and improve search visibility.'
                          : 'Consolidate multiple competing URLs via 301 redirects to build a single high-authority asset.')}
                    </p>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-neutral-200 flex items-center justify-between text-[11px] text-neutral-500">
                  <span>
                    Focus Keyword: <strong className="text-neutral-800 font-mono">{item.focusKeyword}</strong>
                  </span>
                  <span className="font-semibold text-[#530093] group-hover:underline">
                    View Plan →
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

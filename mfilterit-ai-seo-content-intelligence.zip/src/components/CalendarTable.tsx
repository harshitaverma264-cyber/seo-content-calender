import React, { useState, useMemo } from 'react';
import {
  Search,
  ArrowUpDown,
  Download,
  Calendar,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import {
  ContentItem,
  ContentTypeFilter,
  ContentStatus,
  ContentAction,
  StrategicObjective,
  TrustPillar
} from '../types/seo';
import { getItemStrategicObjectives } from '../utils/strategicObjectives';
import { getTrustPillarForItem, ALL_TRUST_PILLARS } from '../utils/trustPillar';
import { Globe, ShieldCheck } from 'lucide-react';

interface CalendarTableProps {
  items: ContentItem[];
  activeContentType: ContentTypeFilter;
  onSelectItem: (item: ContentItem) => void;
  onUpdateStatus: (itemId: string, newStatus: ContentStatus) => void;
  onExportCalendar?: (tab: ContentTypeFilter, monthKey?: string) => void;
  currentMonthKey?: string;
  availableMonths?: { key: string; label: string }[];
  onSelectMonth?: (monthKey: string) => void;
  onOpenGoogleSerp?: (keyword: string) => void;
  selectedObjectives?: StrategicObjective[];
}

export const CalendarTable: React.FC<CalendarTableProps> = ({
  items,
  activeContentType,
  onSelectItem,
  onUpdateStatus,
  onExportCalendar,
  currentMonthKey,
  availableMonths,
  onSelectMonth,
  onOpenGoogleSerp,
  selectedObjectives = [],
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTrustPillar, setSelectedTrustPillar] = useState<string>('All Pillars');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim() && onOpenGoogleSerp) {
      onOpenGoogleSerp(searchTerm.trim());
    }
  };

  // Filtered & Sorted items
  const filteredItems = useMemo(() => {
    return items
      .filter((item) => {
        // Content type filter
        if (activeContentType !== 'All Content' && item.contentType !== activeContentType) {
          return false;
        }

        // Trust Pillar filter
        if (selectedTrustPillar !== 'All Pillars') {
          const itemPillar = getTrustPillarForItem(item);
          if (itemPillar !== selectedTrustPillar) {
            return false;
          }
        }

        // Search text: topic, primary keyword, or focus keyword
        if (searchTerm.trim() !== '') {
          const q = searchTerm.toLowerCase();
          const matchTopic = item.topic.toLowerCase().includes(q);
          const matchKeyword = (item.primaryKeyword || item.focusKeyword || '').toLowerCase().includes(q);
          if (!matchTopic && !matchKeyword) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        return sortAsc
          ? a.date.localeCompare(b.date)
          : b.date.localeCompare(a.date);
      });
  }, [items, activeContentType, selectedTrustPillar, searchTerm, sortAsc]);

  const toggleSort = () => {
    setSortAsc(!sortAsc);
  };

  return (
    <div className="bg-white border border-neutral-200/90 rounded-2xl shadow-xs overflow-hidden">
      
      {/* Top Filter and Controls Bar: ONLY Search, Month Dropdown, and Export Excel */}
      <div className="p-4 border-b border-neutral-200 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          
          {/* 1. Search Input with Google SERP Trigger */}
          <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-md flex items-center gap-1.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#530093] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search any keyword on Google SERP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-24 py-1.5 text-xs bg-neutral-50 border border-neutral-300 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#530093] focus:border-[#530093]"
              />
              <button
                type="submit"
                onClick={handleSearchSubmit}
                disabled={!searchTerm.trim()}
                className="absolute right-1 top-1/2 -translate-y-1/2 px-2 py-0.5 text-[10px] font-bold text-neutral-900 bg-[#FFCC29] hover:bg-[#ebd505] rounded transition-colors disabled:opacity-40 cursor-pointer flex items-center gap-1"
                title="Search Google SERP results & top 3 blogs"
              >
                <Globe className="w-2.5 h-2.5 text-neutral-900" />
                <span>Search Google</span>
              </button>
            </div>
          </form>

          {/* 2. Trust Pillar Filter, Month Dropdown & Export Excel */}
          <div className="flex items-center gap-2.5 text-xs flex-wrap">
            {/* Trust Pillar Filter Dropdown */}
            <select
              value={selectedTrustPillar}
              onChange={(e) => setSelectedTrustPillar(e.target.value)}
              className="px-3 py-1.5 bg-purple-50/80 border border-purple-200 rounded-md text-[#530093] text-xs font-bold focus:outline-none focus:border-[#530093] cursor-pointer"
              title="Filter by Trust Pillar"
            >
              <option value="All Pillars">All Trust Pillars</option>
              {ALL_TRUST_PILLARS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label}
                </option>
              ))}
            </select>

            {/* Month Dropdown */}
            {availableMonths && onSelectMonth && (
              <select
                value={currentMonthKey}
                onChange={(e) => onSelectMonth(e.target.value)}
                className="px-3 py-1.5 bg-neutral-100 border border-neutral-300 rounded-md text-neutral-800 text-xs font-bold focus:outline-none focus:border-[#530093] cursor-pointer"
                title="Select Month"
              >
                {availableMonths.map((m) => (
                  <option key={m.key} value={m.key}>
                    {m.label}
                  </option>
                ))}
              </select>
            )}

            {/* Export Excel Button */}
            {onExportCalendar && (
              <button
                onClick={() => onExportCalendar(activeContentType, currentMonthKey)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-[#530093] bg-[#530093]/10 hover:bg-[#530093]/20 rounded-md transition-colors cursor-pointer"
                title={`Export ${activeContentType} entries for selected month to Excel (.xlsx)`}
              >
                <Download className="w-3.5 h-3.5 text-[#530093]" />
                <span>Export Excel</span>
              </button>
            )}
          </div>
        </div>

        {/* Counter & Instruction hint */}
        <div className="flex items-center justify-between text-[11px] text-neutral-500 pt-1">
          <div>
            Showing <span className="font-semibold text-neutral-800 font-mono tabular-nums">{filteredItems.length}</span> of{' '}
            <span className="font-semibold text-neutral-800 font-mono tabular-nums">{items.length}</span> items for{' '}
            <span className="font-semibold text-[#530093]">{activeContentType}</span>
          </div>
          <div className="hidden sm:block text-neutral-400">
            Click any row to inspect keyword strategy and ICP details
          </div>
        </div>
      </div>

      {/* Main Clean 6-Column Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-neutral-50 text-neutral-600 font-semibold border-b border-neutral-200 uppercase tracking-wider text-[11px]">
              
              {/* 1. Content / Topic */}
              <th
                onClick={toggleSort}
                className="py-3 px-4 cursor-pointer hover:bg-neutral-100 min-w-[240px]"
              >
                <div className="flex items-center gap-1">
                  <span>Content / Topic</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>

              {/* 2. Primary Keyword */}
              <th className="py-3 px-4 min-w-[160px]">Primary Keyword</th>

              {/* 3. Primary Search Volume */}
              <th className="py-3 px-4 whitespace-nowrap min-w-[130px]">Primary Search Vol</th>

              {/* 4. Secondary Keywords */}
              <th className="py-3 px-4 min-w-[240px]">Secondary Keywords (10)</th>

              {/* 5. Secondary Search Volume */}
              <th className="py-3 px-4 min-w-[170px]">Secondary Search Vol</th>

              {/* 6. Region */}
              <th className="py-3 px-4 whitespace-nowrap w-[90px]">Region</th>

              {/* Trust Pillar */}
              <th className="py-3 px-4 whitespace-nowrap min-w-[120px]">Trust Pillar</th>

              {/* 7. Action */}
              <th className="py-3 px-4 whitespace-nowrap w-[100px]">Action</th>

              {/* 8. Status */}
              <th className="py-3 px-4 whitespace-nowrap w-[120px]">Status</th>

            </tr>
          </thead>

          <tbody className="divide-y divide-neutral-200">
            {filteredItems.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-12 text-center text-neutral-500">
                  <div className="max-w-sm mx-auto space-y-2">
                    <p className="text-sm font-semibold text-neutral-700">No content items found</p>
                    <p className="text-xs text-neutral-400">
                      No calendar records match the selected tab and filters.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredItems.map((item) => {
                const primaryKw = item.primaryKeyword || item.focusKeyword || '—';
                const primaryVol = item.primarySearchVolume || item.searchVolume;

                let secondaryKwText = '';
                let secondaryVolText = '';

                if (item.secondaryKeywordsWithVolume && item.secondaryKeywordsWithVolume.length > 0) {
                  secondaryKwText = item.secondaryKeywordsWithVolume.map((sk) => sk.keyword).join(', ');
                  secondaryVolText = item.secondaryKeywordsWithVolume.map((sk) => sk.searchVolume.toLocaleString()).join(', ');
                } else if (item.secondaryKeywords && item.secondaryKeywords.length > 0) {
                  secondaryKwText = item.secondaryKeywords.join(', ');
                  secondaryVolText = '—';
                }

                return (
                  <tr
                    key={item.id}
                    onClick={() => onSelectItem(item)}
                    className="hover:bg-neutral-50/80 cursor-pointer transition-colors group"
                  >
                    {/* 1. Content / Topic */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-neutral-900 group-hover:text-[#530093] transition-colors leading-snug">
                        {item.topic}
                      </div>
                      <div className="flex flex-wrap items-center gap-1 mt-1">
                        {activeContentType === 'All Content' && (
                          <span className="text-[10px] text-neutral-500 font-medium mr-1">
                            {item.contentType}
                          </span>
                        )}
                        {getItemStrategicObjectives(item).slice(0, 2).map((obj) => (
                          <span
                            key={obj}
                            className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                              selectedObjectives && selectedObjectives.includes(obj)
                                ? 'bg-purple-100 text-[#530093] border-purple-200'
                                : 'bg-neutral-100 text-neutral-600 border-neutral-200'
                            }`}
                          >
                            {obj}
                          </span>
                        ))}
                      </div>
                    </td>

                    {/* 3. Primary Keyword */}
                    <td className="py-3 px-4 font-mono text-neutral-800 text-[11.5px]">
                      {primaryKw}
                    </td>

                    {/* 4. Primary Search Volume */}
                    <td className="py-3 px-4 font-mono font-semibold text-[#530093] text-[11.5px] whitespace-nowrap">
                      {primaryVol ? primaryVol.toLocaleString() : '—'}
                    </td>

                    {/* 5. Secondary Keywords (10) */}
                    <td className="py-3 px-4 min-w-[240px] max-w-[320px]">
                      <div className="line-clamp-2 font-mono text-neutral-700 text-[11px]" title={secondaryKwText}>
                        {secondaryKwText || '—'}
                      </div>
                    </td>

                    {/* 6. Secondary Search Volume */}
                    <td className="py-3 px-4 min-w-[170px] max-w-[240px]">
                      <div className="line-clamp-2 font-mono text-neutral-600 text-[11px]" title={secondaryVolText}>
                        {secondaryVolText || '—'}
                      </div>
                    </td>

                    {/* 7. Region */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="inline-block text-[11px] font-semibold text-neutral-700">
                        {item.region === 'INDIA'
                          ? 'India'
                          : item.region === 'USA'
                          ? 'USA'
                          : item.region === 'MENA'
                          ? 'MENA'
                          : 'Overall'}
                      </span>
                    </td>

                    {/* Trust Pillar Badge */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      {(() => {
                        const pillar = getTrustPillarForItem(item);
                        return (
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10.5px] font-extrabold border ${
                              pillar === 'Media Trust'
                                ? 'bg-purple-50 text-[#530093] border-purple-200'
                                : pillar === 'Brand Trust'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}
                          >
                            <ShieldCheck className="w-3 h-3 shrink-0" />
                            <span>{pillar}</span>
                          </span>
                        );
                      })()}
                    </td>

                    {/* 8. Action */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase ${
                          item.contentAction === 'NEW'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : item.contentAction === 'REVAMP'
                            ? 'bg-[#530093]/10 text-[#530093] border border-[#530093]/20'
                            : item.contentAction === 'EXPAND'
                            ? 'bg-amber-50 text-amber-900 border border-[#FFCC29]'
                            : item.contentAction === 'MERGE'
                            ? 'bg-red-50 text-red-800 border border-red-200'
                            : 'bg-neutral-100 text-neutral-700 border border-neutral-200'
                        }`}
                      >
                        {item.contentAction}
                      </span>
                    </td>

                    {/* 9. Status */}
                    <td className="py-3 px-4 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <select
                        value={item.status}
                        onChange={(e) => onUpdateStatus(item.id, e.target.value as ContentStatus)}
                        className={`text-xs font-semibold rounded px-2 py-1 border transition-colors cursor-pointer focus:outline-none focus:border-[#530093] ${
                          item.status === 'Published'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : item.status === 'In Progress'
                            ? 'bg-amber-50 text-amber-800 border-amber-300'
                            : item.status === 'Needs Review'
                            ? 'bg-purple-50 text-[#530093] border-purple-300'
                            : 'bg-neutral-50 text-neutral-700 border-neutral-300'
                        }`}
                      >
                        <option value="Planned">Planned</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Needs Review">Needs Review</option>
                        <option value="Published">Published</option>
                      </select>
                    </td>

                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
};

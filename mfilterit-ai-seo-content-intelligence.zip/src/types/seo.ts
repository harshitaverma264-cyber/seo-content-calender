/**
 * mFilterIt SEO Content Intelligence System Types
 */

export type TrustPillar = 'Media Trust' | 'Brand Trust' | 'Financial Trust';

export type StrategicObjective =
  | 'Brand Awareness'
  | 'Website Traffic Increase'
  | 'Lead Generation'
  | 'Conversions'
  | 'Market Expansion';

export type ContentType =
  | 'Website Blog'
  | 'SEO / Guest Post'
  | 'Infographic'
  | 'Glossary';

export type ContentTypeFilter = 'All Content' | ContentType;

export type FunnelStage = 'TOFU' | 'MOFU' | 'BOFU';

export type ContentAction = 'NEW' | 'REVAMP' | 'EXPAND' | 'MERGE' | 'SUPPORTING' | 'OVERLAP';

export type Region = 'INDIA' | 'USA' | 'MENA' | 'OVERALL';

export type Priority = 'High' | 'Medium' | 'Low';

export type ContentStatus = 'Planned' | 'In Progress' | 'Published' | 'Needs Review';

export type PotentialLevel = 'High' | 'Medium' | 'Low';

export type mFilterItSolution =
  | 'Ad Fraud Detection'
  | 'Affiliate Monitoring / Affiliate Fraud Detection'
  | 'Brand Safety'
  | 'Brand Protection'
  | 'Creative Compliance'
  | 'Digital Shelf / Marketplace Monitoring';

export type IcpPersona =
  | 'CMO'
  | 'Marketing Head'
  | 'Performance Marketing Head'
  | 'Digital Marketing Head'
  | 'Media Buyer'
  | 'Affiliate Manager'
  | 'Affiliate Marketing Head'
  | 'Brand Protection Head'
  | 'Brand Safety Head'
  | 'E-commerce Head'
  | 'Advertising/Media Decision Maker';

export interface CannibalizationCheck {
  hasRisk: boolean;
  existingUrl?: string;
  existingTargetKeyword?: string;
  proposedKeyword: string;
  intentSimilarity: string;
  cannibalizationRisk: 'High' | 'Medium' | 'Low' | 'None';
  recommendedAction: string;
}

export interface KeywordWithVolume {
  keyword: string;
  searchVolume: number;
  volumeType: 'Estimated' | 'Verified';
  source?: string;
  lastUpdated?: string; // YYYY-MM-DD
}

export interface ContentItem {
  id: string;
  date: string; // YYYY-MM-DD
  contentType: ContentType;
  topic: string;
  primaryKeyword?: string;
  primarySearchVolume?: number;
  primaryVolumeType?: 'Estimated' | 'Verified';
  primarySource?: string;
  primaryLastUpdated?: string;
  searchVolume?: number;
  focusKeyword: string;
  secondaryKeywords?: string[];
  secondaryKeywordsWithVolume?: KeywordWithVolume[];
  tertiaryKeywords?: string[];
  competitorReferenceLinks?: string[];
  searchIntent?: 'Informational' | 'Commercial Investigation' | 'Transactional' | 'Navigational';
  funnelStage?: FunnelStage;
  region: Region;
  icpPersona?: IcpPersona;
  productMapping: mFilterItSolution;
  contentAction: ContentAction;
  priority: Priority;
  leadPotential: PotentialLevel;
  conversionPotential: PotentialLevel;
  leadRationale?: string;
  conversionRationale?: string;
  referenceLink?: string;
  status: ContentStatus;
  
  // SEO Architecture additions
  internalLinks?: string[];
  recommendedCta?: string;
  conversionDestination?: string;
  actionRationale?: string;
  cannibalization?: CannibalizationCheck;
  strategicObjectives?: StrategicObjective[];
  trustPillar?: TrustPillar;
}

export interface CannibalizationAlert {
  id: string;
  proposedTopic: string;
  proposedKeyword: string;
  existingUrl: string;
  existingKeyword: string;
  intentSimilarity: string;
  riskLevel: 'High' | 'Medium' | 'Low';
  recommendedAction: string;
  solution: mFilterItSolution;
}

export interface TopicCluster {
  id: string;
  clusterName: string;
  pillarTopic: string;
  pillarUrl: string;
  solution: mFilterItSolution;
  commercialLandingPage: string;
  primaryCta: string;
  targetKeywords?: string[];
  missingTopics?: {
    title: string;
    gapRationale: string;
    suggestedFunnel: FunnelStage;
    priority: Priority;
  }[];
  cannibalizationRules?: string[];
  supportingTopics: {
    title: string;
    contentType: ContentType;
    funnel: FunnelStage;
    status: ContentStatus;
    action: ContentAction;
  }[];
}

export interface MonthlyData {
  monthKey: string; // '2026-10'
  monthLabel: string; // 'October 2026'
  year: number;
  month: number; // 1-12
  isLocked?: boolean;
  items: ContentItem[];
  cannibalizationAlerts: CannibalizationAlert[];
  summaryNotes?: string;
}

export interface ConnectorStatus {
  id: string;
  name: string;
  status: 'Awaiting connection' | 'Connected' | 'Ready for Upload';
  description: string;
  dataNote: string;
}

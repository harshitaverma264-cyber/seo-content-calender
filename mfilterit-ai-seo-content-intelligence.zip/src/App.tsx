import React, { useState, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { CalendarTable } from './components/CalendarTable';
import { PriorityOpportunitiesSection } from './components/PriorityOpportunitiesSection';
import { ContentRefreshSection } from './components/ContentRefreshSection';
import { DataIntegrityModal } from './components/DataIntegrityModal';
import { ContentDetailModal } from './components/ContentDetailModal';
import { AddContentModal } from './components/AddContentModal';
import { GoogleSerpModal } from './components/GoogleSerpModal';
import { ExportFeedbackToast, ToastData } from './components/ExportFeedbackToast';
import { EditorialStyleGuideModal } from './components/EditorialStyleGuideModal';
import { exportMonthlyCalendarToExcel } from './utils/excelExport';
import { KeywordDataSourcesSection } from './components/KeywordDataSourcesSection';
import { KeywordIntelligenceView } from './components/KeywordIntelligenceView';
import { TopicClustersSection } from './components/TopicClustersSection';
import { SeasonalitySection } from './components/SeasonalitySection';
import { CompetitorContentGapView } from './components/CompetitorContentGapView';
import { KeywordGapView } from './components/KeywordGapView';
import { StrategicObjectivesBar } from './components/StrategicObjectivesBar';

import {
  MonthlyData,
  ContentTypeFilter,
  ContentItem,
  ContentStatus,
  ContentAction,
  StrategicObjective,
} from './types/seo';
import { isItemAlignedWithObjectives } from './utils/strategicObjectives';
import { INITIAL_MONTHLY_DATA } from './data/initialMonthlyData';
import { enrichContentItemWithRealKeywords } from './data/keywordDataRepository';
import { PERSISTENT_MASTER_SOURCES } from './data/persistentMasterSources';
import {
  MasterDataSourceInfo,
  LiveRankingWorkbookInfo,
  CombinedKeywordOpportunity,
} from './types/keywordIntelligence';
import {
  INITIAL_EMPTY_DATA_SOURCES,
  DEMO_MASTER_KEYWORDS,
  DEMO_LIVE_RANKINGS,
} from './data/demoKeywordData';
import { generateCombinedOpportunities } from './utils/fileParsers';
import { generateMonthDataFor } from './utils/futureMonthGenerator';
import { AppViewMode } from './components/Header';

export default function App() {
  // Navigation View Mode: 'calendar' | 'keywords' | 'sources'
  const [currentView, setCurrentView] = useState<AppViewMode>('calendar');

  // State for Editorial Style Guide Modal
  const [isEditorialGuideOpen, setIsEditorialGuideOpen] = useState<boolean>(false);

  // Top search query
  const [topSearchQuery, setTopSearchQuery] = useState<string>('');

  // Monthly Data store: preserves historical and future months separately without overwriting
  const [monthlyStore, setMonthlyStore] = useState<Record<string, MonthlyData>>(INITIAL_MONTHLY_DATA);
  const [currentMonthKey, setCurrentMonthKey] = useState<string>('2026-10');
  const [activeContentType, setActiveContentType] = useState<ContentTypeFilter>('All Content');

  // Real Keyword Data Sources Architecture (3 Master Sources + 1 Live Ranking Workbook)
  const [masterSources, setMasterSources] = useState<Record<'INDIA' | 'USA' | 'MENA', MasterDataSourceInfo>>(
    PERSISTENT_MASTER_SOURCES
  );
  const [liveWorkbook, setLiveWorkbook] = useState<LiveRankingWorkbookInfo>(
    INITIAL_EMPTY_DATA_SOURCES.liveRankingWorkbook
  );
  const [isDemoActive, setIsDemoActive] = useState<boolean>(false);
  const [selectedKeywordRegion, setSelectedKeywordRegion] = useState<'ALL' | 'INDIA' | 'USA' | 'MENA'>('ALL');

  // Selectable Strategic Objectives (Brand Awareness, Website Traffic Increase, Lead Generation, Conversions, Market Expansion)
  const [selectedObjectives, setSelectedObjectives] = useState<StrategicObjective[]>([
    'Brand Awareness',
    'Website Traffic Increase',
    'Lead Generation',
    'Conversions',
    'Market Expansion',
  ]);

  const handleToggleObjective = (obj: StrategicObjective) => {
    setSelectedObjectives((prev) =>
      prev.includes(obj) ? prev.filter((o) => o !== obj) : [...prev, obj]
    );
  };

  const handleSelectAllObjectives = () => {
    setSelectedObjectives([
      'Brand Awareness',
      'Website Traffic Increase',
      'Lead Generation',
      'Conversions',
      'Market Expansion',
    ]);
  };

  const handleClearObjectives = () => {
    setSelectedObjectives([]);
  };

  // Automatic Retrieval for Source 4 (SharePoint Live Ranking Workbook)
  useEffect(() => {
    let isMounted = true;
    async function loadLiveWorkbook() {
      try {
        const res = await fetch('/api/live-workbook');
        if (res.ok) {
          const data: LiveRankingWorkbookInfo = await res.json();
          if (isMounted && data && data.status === 'CONNECTED') {
            setLiveWorkbook(data);
          }
        }
      } catch (err) {
        console.warn('Unable to auto-retrieve live SharePoint workbook via API:', err);
      }
    }
    loadLiveWorkbook();
    return () => {
      isMounted = false;
    };
  }, []);

  // Modals & Inspection Drawers
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);
  const [isDataModalOpen, setIsDataModalOpen] = useState<boolean>(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);

  // Live Google SERP Grounding Search Modal
  const [isGoogleSerpOpen, setIsGoogleSerpOpen] = useState<boolean>(false);
  const [serpSearchKeyword, setSerpSearchKeyword] = useState<string>('');
  const [serpSearchRegion, setSerpSearchRegion] = useState<'INDIA' | 'USA' | 'MENA' | 'GLOBAL'>('INDIA');

  const handleOpenGoogleSerp = (kw: string, region: 'INDIA' | 'USA' | 'MENA' | 'GLOBAL' = 'INDIA') => {
    setSerpSearchKeyword(kw);
    setSerpSearchRegion(region);
    setIsGoogleSerpOpen(true);
  };

  const handleGoogleSerpSendToCalendar = (title: string, keyword: string, targetUrl?: string) => {
    let action: ContentAction = 'NEW';
    let rationale = `Identified via Live Google Search Grounding for keyword "${keyword}".`;
    const compLinks: string[] = [];

    if (targetUrl) {
      compLinks.push(targetUrl);
      if (targetUrl.includes('mfilterit')) {
        action = 'REVAMP';
        rationale = `Live Google SERP indicates mFilterIt ranks for "${keyword}". Action set to REVAMP to update content and capture top 3 position.`;
      } else if (targetUrl.includes('guide') || targetUrl.includes('blog') || targetUrl.includes('report')) {
        action = 'EXPAND';
        rationale = `Live Google SERP reveals high competitor coverage (${targetUrl}). Action set to EXPAND to build a broader framework.`;
      }
    }

    const newItem: ContentItem = {
      id: `serp-${Date.now()}`,
      date: `${currentMonthlyData.year}-${currentMonthlyData.month < 10 ? '0' : ''}${currentMonthlyData.month}-20`,
      contentType: 'Website Blog',
      topic: title,
      primaryKeyword: keyword,
      focusKeyword: keyword,
      competitorReferenceLinks: compLinks.length > 0 ? compLinks : undefined,
      searchVolume: 1200,
      primarySearchVolume: 1200,
      region: 'USA',
      productMapping: 'Ad Fraud Detection',
      icpPersona: 'Marketing Head',
      leadPotential: 'High',
      priority: 'High',
      conversionPotential: 'High',
      contentAction: action,
      leadRationale: rationale,
      status: 'Planned'
    };

    const enriched = enrichContentItemWithRealKeywords(newItem);

    setMonthlyStore((prev) => {
      const monthData = prev[currentMonthKey];
      if (!monthData) return prev;
      return {
        ...prev,
        [currentMonthKey]: {
          ...monthData,
          items: [enriched, ...monthData.items]
        }
      };
    });

    setToast({
      id: Date.now().toString(),
      message: `Scheduled "${title}" into ${currentMonthlyData.monthLabel} Content Calendar!`,
      type: 'success',
      rowCount: 1,
      monthLabel: currentMonthlyData.monthLabel,
      tab: 'Website Blog'
    });
  };

  // User feedback toast notifications (including tab-specific Excel exports)
  const [toast, setToast] = useState<ToastData | null>(null);

  // Available months list sorted chronologically
  const availableMonths = useMemo(() => {
    return Object.values(monthlyStore)
      .sort((a, b) => a.monthKey.localeCompare(b.monthKey))
      .map((m) => ({
        key: m.monthKey,
        label: m.monthLabel,
      }));
  }, [monthlyStore]);

  // Current active monthly data
  const currentMonthlyData = useMemo(() => {
    return (
      monthlyStore[currentMonthKey] ||
      monthlyStore['2026-10'] ||
      Object.values(monthlyStore)[0]
    );
  }, [monthlyStore, currentMonthKey]);

  // Counts by content type for the selected month
  const contentTypeCounts = useMemo(() => {
    const items = currentMonthlyData.items;
    const counts: Record<ContentTypeFilter, number> = {
      'All Content': items.length,
      'Website Blog': items.filter((i) => i.contentType === 'Website Blog').length,
      'SEO / Guest Post': items.filter((i) => i.contentType === 'SEO / Guest Post').length,
      'Infographic': items.filter((i) => i.contentType === 'Infographic').length,
      'Glossary': items.filter((i) => i.contentType === 'Glossary').length,
    };
    return counts;
  }, [currentMonthlyData]);

  // Filtered items based on top search bar
  const displayedCalendarItems = useMemo(() => {
    if (!topSearchQuery.trim()) return currentMonthlyData.items;
    const q = topSearchQuery.toLowerCase();
    return currentMonthlyData.items.filter(
      (item) =>
        item.topic.toLowerCase().includes(q) ||
        (item.primaryKeyword || item.focusKeyword || '').toLowerCase().includes(q) ||
        item.region.toLowerCase().includes(q) ||
        item.productMapping.toLowerCase().includes(q)
    );
  }, [currentMonthlyData.items, topSearchQuery]);

  // High priority count
  const priorityCount = useMemo(() => {
    return currentMonthlyData.items.filter(
      (i) => i.priority === 'High' || i.leadPotential === 'High'
    ).length;
  }, [currentMonthlyData.items]);

  // Combined Keyword Opportunities derived from Master Keywords + Live Ranking Workbook
  const combinedOpportunities = useMemo(() => {
    const masterMap: Record<'INDIA' | 'USA' | 'MENA', any> = {
      INDIA: masterSources.INDIA.records,
      USA: masterSources.USA.records,
      MENA: masterSources.MENA.records,
    };

    const liveMap: Record<'INDIA' | 'USA' | 'MENA', any> = {
      INDIA: liveWorkbook.tabs.INDIA.records,
      USA: liveWorkbook.tabs.USA.records,
      MENA: liveWorkbook.tabs.MENA.records,
    };

    return generateCombinedOpportunities(masterMap, liveMap, selectedKeywordRegion);
  }, [masterSources, liveWorkbook, selectedKeywordRegion]);

  // Update item status in the selected month
  const handleUpdateStatus = (itemId: string, newStatus: ContentStatus) => {
    setMonthlyStore((prev) => {
      const monthData = prev[currentMonthKey];
      if (!monthData) return prev;

      const updatedItems = monthData.items.map((item) =>
        item.id === itemId ? { ...item, status: newStatus } : item
      );

      return {
        ...prev,
        [currentMonthKey]: {
          ...monthData,
          items: updatedItems,
        },
      };
    });

    if (selectedItem && selectedItem.id === itemId) {
      setSelectedItem((prev) => (prev ? { ...prev, status: newStatus } : null));
    }
  };

  // Add new content item to current month
  const handleAddItem = (newItem: ContentItem) => {
    const enriched = enrichContentItemWithRealKeywords(newItem);
    setMonthlyStore((prev) => {
      const monthData = prev[currentMonthKey];
      if (!monthData) return prev;

      return {
        ...prev,
        [currentMonthKey]: {
          ...monthData,
          items: [enriched, ...monthData.items],
        },
      };
    });
  };

  // Convert keyword opportunity into a scheduled Monthly Calendar item
  const handleSendKeywordToCalendar = (opp: CombinedKeywordOpportunity) => {
    const scheduledDate = `${currentMonthlyData.year}-${currentMonthlyData.month < 10 ? '0' : ''}${currentMonthlyData.month}-20`;
    const newItem: ContentItem = {
      id: `kw-cal-${Date.now()}`,
      date: scheduledDate,
      contentType: 'Website Blog',
      topic: `${opp.keyword.charAt(0).toUpperCase() + opp.keyword.slice(1)}: Enterprise Guide & Best Practices`,
      primaryKeyword: opp.keyword,
      focusKeyword: opp.keyword,
      secondaryKeywords: [
        `${opp.keyword} best practices`,
        `${opp.productMapping.toLowerCase().split('/')[0].trim()} enterprise guide`,
      ],
      tertiaryKeywords: [
        `${opp.keyword} tools and techniques`,
        `${opp.region.toLowerCase()} ${opp.keyword}`,
      ],
      competitorReferenceLinks: opp.existingUrl && !opp.existingUrl.includes('mfilterit.com')
        ? [opp.existingUrl]
        : [],
      searchIntent: opp.searchIntent,
      funnelStage: opp.funnelStage,
      region: opp.region,
      icpPersona: opp.icpPersona,
      productMapping: opp.productMapping,
      contentAction: opp.recommendedAction,
      priority: opp.priority,
      leadPotential: opp.leadPotential,
      conversionPotential: opp.conversionPotential,
      leadRationale: opp.actionRationale,
      referenceLink: opp.existingUrl,
      status: 'Planned',
      recommendedCta: `Request Free ${opp.productMapping.split('/')[0]} Audit`,
      actionRationale: opp.actionRationale,
    };

    handleAddItem(newItem);
    setCurrentView('calendar');
  };

  // Tab-specific Excel export handler strictly adhering to Prompt requirements
  const handleExportCalendar = (
    targetType: ContentTypeFilter = activeContentType,
    monthKey?: string
  ) => {
    const selectedKey = monthKey || currentMonthKey;
    const monthData = monthlyStore[selectedKey] || currentMonthlyData;
    const result = exportMonthlyCalendarToExcel(monthData, targetType);
    if (result.success) {
      setToast({
        id: `toast-${Date.now()}`,
        type: 'success',
        tab: targetType,
        monthLabel: monthData.monthLabel,
        rowCount: result.rowCount || 0,
        filename: result.filename,
        message: result.message || `Successfully exported ${result.rowCount} records for ${targetType} in ${monthData.monthLabel}.`,
      });
    } else {
      setToast({
        id: `toast-${Date.now()}`,
        type: 'warning',
        tab: targetType,
        monthLabel: monthData.monthLabel,
        rowCount: 0,
        message: result.message || `No content planned for ${targetType} in ${monthData.monthLabel} to export.`,
      });
    }
  };

  const handleUpdateMasterSource = (region: 'INDIA' | 'USA' | 'MENA', source: MasterDataSourceInfo) => {
    setMasterSources((prev) => ({ ...prev, [region]: source }));
  };

  const handleUpdateLiveWorkbook = (workbook: LiveRankingWorkbookInfo) => {
    setLiveWorkbook(workbook);
  };

  // Toggle or load Demo Data
  const handleLoadDemoData = () => {
    if (isDemoActive) {
      setMasterSources(INITIAL_EMPTY_DATA_SOURCES.masterSources);
      setLiveWorkbook(INITIAL_EMPTY_DATA_SOURCES.liveRankingWorkbook);
      setIsDemoActive(false);
      return;
    }

    const now = 'Oct 5, 2026, 10:00 AM';

    setMasterSources({
      INDIA: {
        id: 'india-master',
        region: 'INDIA',
        name: 'India — All Keywords',
        fileName: 'mFilterIt_India_Master_Keywords_Demo.xlsx',
        status: 'CONNECTED',
        lastUpdated: now,
        rowCount: DEMO_MASTER_KEYWORDS.INDIA.length,
        keywordCount: DEMO_MASTER_KEYWORDS.INDIA.length,
        detectedColumns: ['Keyword', 'Search Volume', 'Keyword Difficulty', 'CPC', 'Search Intent', 'Region', 'Source'],
        validationWarnings: [],
        records: DEMO_MASTER_KEYWORDS.INDIA,
        isDemoData: true,
      },
      USA: {
        id: 'usa-master',
        region: 'USA',
        name: 'USA — All Keywords',
        fileName: 'mFilterIt_USA_Master_Keywords_Demo.xlsx',
        status: 'CONNECTED',
        lastUpdated: now,
        rowCount: DEMO_MASTER_KEYWORDS.USA.length,
        keywordCount: DEMO_MASTER_KEYWORDS.USA.length,
        detectedColumns: ['Keyword', 'Search Volume', 'Keyword Difficulty', 'CPC', 'Search Intent', 'Region', 'Source'],
        validationWarnings: [],
        records: DEMO_MASTER_KEYWORDS.USA,
        isDemoData: true,
      },
      MENA: {
        id: 'mena-master',
        region: 'MENA',
        name: 'MENA — All Keywords',
        fileName: 'mFilterIt_MENA_Master_Keywords_Demo.xlsx',
        status: 'CONNECTED',
        lastUpdated: now,
        rowCount: DEMO_MASTER_KEYWORDS.MENA.length,
        keywordCount: DEMO_MASTER_KEYWORDS.MENA.length,
        detectedColumns: ['Keyword', 'Search Volume', 'Keyword Difficulty', 'CPC', 'Search Intent', 'Region', 'Source'],
        validationWarnings: [],
        records: DEMO_MASTER_KEYWORDS.MENA,
        isDemoData: true,
      },
    });

    setLiveWorkbook({
      id: 'live-rankings-workbook',
      name: 'Live Ranking Workbook',
      fileName: 'Weekly_Keyword_Ranking_Sheet_Demo.xlsx',
      status: 'CONNECTED',
      lastUpdated: now,
      currentWeekLabel: 'Week 40 - 2026',
      tabs: {
        INDIA: {
          region: 'INDIA',
          tabName: 'India Live Rankings',
          rowCount: DEMO_LIVE_RANKINGS.INDIA.length,
          detectedColumns: ['Keyword', 'Search Volume', 'Competition', 'Friday, 25 September 2026'],
          validationWarnings: [],
          records: DEMO_LIVE_RANKINGS.INDIA,
        },
        USA: {
          region: 'USA',
          tabName: 'USA Live Rankings',
          rowCount: DEMO_LIVE_RANKINGS.USA.length,
          detectedColumns: ['Keyword', 'Search Volume', 'Competition', 'Friday, 25 September 2026'],
          validationWarnings: [],
          records: DEMO_LIVE_RANKINGS.USA,
        },
        MENA: {
          region: 'MENA',
          tabName: 'MENA Live Rankings',
          rowCount: DEMO_LIVE_RANKINGS.MENA.length,
          detectedColumns: ['Keyword', 'Search Volume', 'Competition', 'Friday, 25 September 2026'],
          validationWarnings: [],
          records: DEMO_LIVE_RANKINGS.MENA,
        },
      },
      validationWarnings: [],
      isDemoData: true,
    });

    setIsDemoActive(true);
  };

  // Plan next future month while strictly preserving historical records
  const handleGenerateNextMonth = () => {
    const sortedKeys = Object.keys(monthlyStore).sort();
    const lastKey = sortedKeys[sortedKeys.length - 1];
    const [yearStr, monthStr] = lastKey.split('-');
    let nextYear = parseInt(yearStr, 10);
    let nextMonth = parseInt(monthStr, 10) + 1;
    if (nextMonth > 12) {
      nextMonth = 1;
      nextYear += 1;
    }

    const newMonthData = generateMonthDataFor(nextYear, nextMonth);

    setMonthlyStore((prev) => ({
      ...prev,
      [newMonthData.monthKey]: newMonthData,
    }));

    setCurrentMonthKey(newMonthData.monthKey);

    setToast({
      id: `toast-${Date.now()}`,
      type: 'success',
      tab: activeContentType,
      monthLabel: newMonthData.monthLabel,
      rowCount: newMonthData.items.length,
      message: `Generated full 50-item SEO Content Plan for ${newMonthData.monthLabel}!`,
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#fbfafd] text-[#1E1E24]">
      
      {/* 1. FIXED LEFT SIDEBAR (Matching reference screenshot) */}
      <Sidebar
        activeContentType={activeContentType}
        onSelectContentType={setActiveContentType}
        contentTypeCounts={contentTypeCounts}
        currentView={currentView}
        onSelectView={setCurrentView}
      />

      {/* 2. MAIN WORKSPACE */}
      <div className="flex-1 flex flex-col h-screen overflow-y-auto">
        
        {/* Global Enterprise Header */}
        <Header
          currentMonthKey={currentMonthKey}
          availableMonths={availableMonths}
          onSelectMonth={setCurrentMonthKey}
          monthlyData={currentMonthlyData}
          activeContentType={activeContentType}
          currentView={currentView}
          onSelectView={setCurrentView}
          onOpenAddModal={() => setIsAddModalOpen(true)}
          onOpenDataModal={() => setIsDataModalOpen(true)}
          onGenerateNextMonth={handleGenerateNextMonth}
          onExportCalendar={(targetType) => handleExportCalendar(targetType || activeContentType, currentMonthKey)}
          onOpenGoogleSerp={handleOpenGoogleSerp}
        />

        {/* Dashboard Content Container */}
        <main className="flex-1 p-6 space-y-6 max-w-[1600px] w-full mx-auto">
          
          {/* VIEW 1: MAIN DASHBOARD & CONTENT CALENDAR (Matching Reference Screenshot) */}
          {currentView === 'calendar' && (
            <>
              {/* Selectable Strategic Objectives Bar */}
              <section aria-label="Strategic Objectives Priorities">
                <StrategicObjectivesBar
                  selectedObjectives={selectedObjectives}
                  onToggleObjective={handleToggleObjective}
                  onSelectAllObjectives={handleSelectAllObjectives}
                  onClearObjectives={handleClearObjectives}
                  monthlyItems={currentMonthlyData.items}
                />
              </section>

              {/* Main 6-Column Monthly Content Calendar Table (with Tab-Specific Excel Export) */}
              <section aria-label="Monthly Content Calendar Table">
                <CalendarTable
                  items={displayedCalendarItems}
                  activeContentType={activeContentType}
                  onSelectItem={setSelectedItem}
                  onUpdateStatus={handleUpdateStatus}
                  onExportCalendar={(tab, mKey) => handleExportCalendar(tab || activeContentType, mKey || currentMonthKey)}
                  currentMonthKey={currentMonthKey}
                  availableMonths={availableMonths}
                  onSelectMonth={setCurrentMonthKey}
                  onOpenGoogleSerp={handleOpenGoogleSerp}
                  selectedObjectives={selectedObjectives}
                />
              </section>

              {/* Priority Opportunities & Content Refresh Sections */}
              <section aria-label="Actionable Monthly Content Insights" className="space-y-6">
                <PriorityOpportunitiesSection
                  items={currentMonthlyData.items}
                  activeContentType={activeContentType}
                  onSelectItem={setSelectedItem}
                />
                {(activeContentType === 'All Content' || activeContentType === 'Website Blog') && (
                  <ContentRefreshSection
                    items={currentMonthlyData.items}
                    onSelectItem={setSelectedItem}
                  />
                )}
              </section>
            </>
          )}

          {/* VIEW 2: KEYWORD INTELLIGENCE & RANKINGS (Toggled via Research Button) */}
          {currentView === 'keywords' && (
            <section aria-label="Keyword Intelligence and Live SERP Analysis" className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
                <div>
                  <h2 className="text-lg font-bold text-neutral-900">
                    Keyword Intelligence & Live SERP Rankings
                  </h2>
                  <p className="text-xs text-neutral-500">
                    Cross-analysis of Master Keywords and Live Weekly Ranking Tracker.
                  </p>
                </div>
                <button
                  onClick={() => setCurrentView('calendar')}
                  className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-100 cursor-pointer"
                >
                  Back to Content Calendar
                </button>
              </div>

              <div className="mt-4">
                <KeywordIntelligenceView
                  opportunities={combinedOpportunities}
                  selectedRegion={selectedKeywordRegion}
                  onSelectRegion={setSelectedKeywordRegion}
                  onSendToCalendar={handleSendKeywordToCalendar}
                  isDemoActive={isDemoActive}
                  onOpenGoogleSerp={handleOpenGoogleSerp}
                />
              </div>
            </section>
          )}

          {/* VIEW 3: KEYWORD DATA SOURCES */}
          {currentView === 'sources' && (
            <section aria-label="Data Sources Ingestion and Validation">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
                <div>
                  <h2 className="text-lg font-bold text-neutral-900">
                    Data Sources &amp; Verification
                  </h2>
                  <p className="text-xs text-neutral-500">
                    Inspect active SharePoint workbook and master keyword sources.
                  </p>
                </div>
                <button
                  onClick={() => setCurrentView('calendar')}
                  className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-100 cursor-pointer"
                >
                  Back to Content Calendar
                </button>
              </div>

              <div className="mt-4">
                <KeywordDataSourcesSection
                  masterSources={masterSources}
                  liveWorkbook={liveWorkbook}
                  isDemoActive={isDemoActive}
                  onLoadDemoData={handleLoadDemoData}
                  onUpdateMasterSource={handleUpdateMasterSource}
                  onUpdateLiveWorkbook={handleUpdateLiveWorkbook}
                />
              </div>
            </section>
          )}

          {/* VIEW 4: TOPIC CLUSTERS */}
          {currentView === 'clusters' && (
            <section aria-label="Topical Authority Clusters">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
                <div>
                  <h2 className="text-lg font-bold text-neutral-900">
                    Topical Authority Clusters &amp; Linking Framework
                  </h2>
                  <p className="text-xs text-neutral-500">
                    Grouped core solution pillars, target keywords, missing topic gaps, and cannibalization rules.
                  </p>
                </div>
                <button
                  onClick={() => setCurrentView('calendar')}
                  className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-100 cursor-pointer"
                >
                  Back to Content Calendar
                </button>
              </div>

              <div className="mt-4">
                <TopicClustersSection />
              </div>
            </section>
          )}

          {/* VIEW 5: REGIONAL SEASONALITY & EVENT PLANNING */}
          {currentView === 'seasonality' && (
            <section aria-label="Regional Seasonality & Campaign Event Planning">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
                <div>
                  <h2 className="text-lg font-bold text-neutral-900">
                    Regional Seasonality &amp; Campaign Planning
                  </h2>
                  <p className="text-xs text-neutral-500">
                    Pre-event planning and ramp-up windows for India, USA, and MENA retail and holiday peaks.
                  </p>
                </div>
                <button
                  onClick={() => setCurrentView('calendar')}
                  className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-100 cursor-pointer"
                >
                  Back to Content Calendar
                </button>
              </div>

              <div className="mt-4">
                <SeasonalitySection
                  onOpenGoogleSerp={handleOpenGoogleSerp}
                  onScheduleSeasonalTopic={(topic, event) => {
                    const scheduledDate = `${currentMonthlyData.year}-${currentMonthlyData.month < 10 ? '0' : ''}${currentMonthlyData.month}-15`;
                    const newItem: ContentItem = {
                      id: `seasonal-${Date.now()}`,
                      date: scheduledDate,
                      contentType: topic.contentType,
                      topic: topic.title,
                      primaryKeyword: topic.keyword,
                      focusKeyword: topic.keyword,
                      region: event.region,
                      icpPersona: topic.targetPersona,
                      productMapping: topic.productMapping,
                      contentAction: topic.action,
                      searchIntent: topic.funnel === 'BOFU' ? 'Transactional' : topic.funnel === 'MOFU' ? 'Commercial Investigation' : 'Informational',
                      funnelStage: topic.funnel,
                      priority: 'High',
                      leadPotential: 'High',
                      conversionPotential: 'High',
                      leadRationale: `Pre-Event Campaign Ramp-up for ${event.eventName}: ${topic.rationale}`,
                      status: 'Planned',
                      recommendedCta: `Request Pre-Event ${topic.productMapping.split('/')[0]} Protection`,
                    };
                    handleAddItem(newItem);
                    setToast({
                      id: `toast-${Date.now()}`,
                      type: 'success',
                      tab: topic.contentType as any,
                      monthLabel: currentMonthlyData.monthLabel,
                      rowCount: 1,
                      message: `Scheduled "${topic.title}" into ${currentMonthlyData.monthLabel} Content Calendar!`,
                    });
                  }}
                />
              </div>
            </section>
          )}

          {/* VIEW 6: COMPETITOR CONTENT GAP STUDIO */}
          {currentView === 'competitor-gap' && (
            <section aria-label="Competitor Content Gap and Overlap Studio">
              <CompetitorContentGapView
                currentMonthLabel={currentMonthlyData.monthLabel}
                currentMonthlyItems={currentMonthlyData.items}
                onBackToCalendar={() => setCurrentView('calendar')}
                onSendToCalendar={(item) => {
                  handleAddItem(item);
                  setToast({
                    id: `toast-${Date.now()}`,
                    type: 'success',
                    tab: item.contentType,
                    monthLabel: currentMonthlyData.monthLabel,
                    rowCount: 1,
                    message: `Scheduled competitor gap "${item.topic}" into ${currentMonthlyData.monthLabel} Content Calendar!`,
                  });
                }}
              />
            </section>
          )}

          {/* VIEW 7: KEYWORD GAP STUDIO */}
          {currentView === 'keyword-gap' && (
            <section aria-label="Keyword Gap Intelligence">
              <KeywordGapView
                masterSources={masterSources}
                liveWorkbook={liveWorkbook}
                onOpenGoogleSerp={handleOpenGoogleSerp}
              />
            </section>
          )}

        </main>

      </div>

      {/* MODAL 1: Full Content Details & SEO Intelligence Brief Modal */}
      <ContentDetailModal
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
        onUpdateStatus={handleUpdateStatus}
      />

      {/* MODAL 2: Add New Content Opportunity Modal */}
      <AddContentModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddItem}
        defaultDate={`${currentMonthlyData.year}-${currentMonthlyData.month < 10 ? '0' : ''}${currentMonthlyData.month}-15`}
      />

      {/* MODAL 3: Data Integrity & Sources Inspector Drawer */}
      <DataIntegrityModal
        isOpen={isDataModalOpen}
        onClose={() => setIsDataModalOpen(false)}
      />

      {/* MODAL 4: Live Google Search SERP & Top 3 Blogs Results Modal */}
      <GoogleSerpModal
        isOpen={isGoogleSerpOpen}
        onClose={() => setIsGoogleSerpOpen(false)}
        initialKeyword={serpSearchKeyword}
        initialRegion={serpSearchRegion}
        onSendToCalendar={handleGoogleSerpSendToCalendar}
      />

      {/* MODAL 5: mFilterIt Internal Editorial Style Guide & Title Diagnostic Tester */}
      <EditorialStyleGuideModal
        isOpen={isEditorialGuideOpen}
        onClose={() => setIsEditorialGuideOpen(false)}
      />

      {/* TOAST: Tab-Specific Excel Export Feedback Toast */}
      {toast && (
        <ExportFeedbackToast
          toast={toast}
          onClose={() => setToast(null)}
        />
      )}

    </div>
  );
}
